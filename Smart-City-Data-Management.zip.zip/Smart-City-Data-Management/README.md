# Smart City Data Management and Analytics System

[![DBMS](https://img.shields.io/badge/Project-B.Tech%20DBMS%20Academic-blue)](file:///c:/Antigravity%20Agent/Smart-City-Data-Management)
[![Database](https://img.shields.io/badge/Database-PostgreSQL%2018-blue)](https://www.postgresql.org)
[![Backend](https://img.shields.io/badge/Backend-Python%20Flask-green)](https://flask.palletsprojects.com)
[![Frontend](https://img.shields.io/badge/Frontend-HTML5%20%7C%20CSS3%20%7C%20Chart.js-orange)](https://www.chartjs.org)

An academic Database Management System (DBMS) project integrating **Traffic Management** and **Waste Management** into a centralized, normalized PostgreSQL relational database with cross-domain area-wise analytics, automated triggers, database views, and deterministic decision-support scoring.

---

## 1. Overview
Managing civic infrastructure across independent departmental databases leads to data fragmentation, redundant records, and difficulties in obtaining holistic urban insights. The **Smart City Data Management and Analytics System** provides a unified relational database architecture focused on two core municipal services:
1. **Traffic Management**: Traffic throughput monitoring, congestion classification, signal management, and incident tracking.
2. **Waste Management**: Municipal bin monitoring, fill percentage meters, overflow risk alerts, and automated collection logging.

The system connects both domains through a centralized **Area** master entity, enabling municipal administrators to evaluate cross-domain performance using an **Area Efficiency Score (0–100)** and prioritize municipal interventions through a **Priority Areas Matrix**.

---

## 2. Problem Statement
> *"Smart cities generate large amounts of data from different urban services, but managing traffic and waste information separately can lead to data redundancy, inconsistent records, and difficulty in obtaining meaningful insights. The proposed system provides a centralized relational database for managing traffic and waste-management data and generates area-wise analytics to support efficient urban-service monitoring and decision-making."*

---

## 3. Objectives
- Design a 3NF normalized PostgreSQL schema with 8 relational tables, primary keys, foreign keys (`ON DELETE CASCADE`), and `CHECK` constraints.
- Implement automated PL/pgSQL database triggers (`trg_update_bin_after_collection`, `trg_sync_bin_status`) to maintain operational state synchronization at the database engine level.
- Build pre-compiled SQL views (`area_traffic_summary`, `area_waste_summary`, `area_efficiency_view`) and B-Tree indexes for fast analytical query execution.
- Implement an explainable, deterministic mathematical model for **Area Efficiency Score** and **Priority Area Identification**.
- Provide a clean, modern web interface with role-based access control (Admin & Operator), Chart.js data visualizations, and full CRUD workflows.

---

## 4. Features
- **Role-Based Authentication**: Secure password hashing with Werkzeug; Admin (full CRUD) and Operator (data entry & analytics) roles.
- **Executive Dashboard**: 8 KPI summary cards, 5 interactive Chart.js charts, and live incident/priority feeds.
- **Smart Waste Collection Scheduling** *(NEW FEATURE)*:
  - Recommends the optimal time window ("Collect Now", historical lower-traffic time e.g. "8:00 PM", "Schedule Soon", or "Regular Collection") for every bin based on fill level, priority, area traffic, and historical time patterns.
  - Interactive "Smart Collection Scheduler" table directly integrated into the Executive Dashboard and dedicated `/smart-scheduler` view.
  - Interactive bin inspector modal revealing bin details, area, fill %, congestion, priority, recommended time, and explainable reason.
- **Traffic-Aware Waste Collection Recommendation**:
  - Cross-domain decision support coupling waste urgency with real-time ward traffic congestion.
  - Deterministic 0–100 Priority Scoring formula (transparent and explainable, non-ML).
  - Sequence-ranked collection queue with human-readable action directives and decision reasons.
  - Automated fleet assignment matching available municipal vehicles by required payload capacity.
  - Dedicated `/collection-recommendations` dashboard with multi-criteria filtering, Chart.js visualizations, single-bin diagnostic inspection, and one-click CSV export.
- **Traffic Management Module**:
  - Filterable sensor records table (by Area, Congestion Level, Date).
  - Add, edit, and delete traffic logs with strict constraint validation.
  - Active traffic incident log with status lifecycle management.
- **Waste Management Module**:
  - Live waste container table with color-coded fill level progress meters.
  - Dynamic container status updates synchronized via database triggers.
  - Municipal fleet collection trip logger with driver failure attribution and automated container emptying.
- **Cross-Domain Analytics Module**:
  - Detailed breakdown of Traffic Score, Waste Score, and Overall Efficiency Score.
  - Automated Priority Areas Matrix with primary issue diagnosis.
  - Peak traffic hour analysis using `EXTRACT(HOUR FROM ...)`.
  - One-click CSV export of analytical reports.
- **City Areas Directory**: Ward demographic records, infrastructure summaries, and zone mappings.

---

## 5. Novelty (Project-Level Decision Support Features)
1. **Centralized Traffic + Waste Database**: Eliminates departmental silos by integrating both domains into one relational database.
2. **Area-Based Cross-Domain Analytics**: Direct comparison of traffic volume and waste accumulation within the same geographical ward.
3. **Area Efficiency Score**: A deterministic mathematical formula (0–100) combining vehicular congestion and municipal sanitation performance.
4. **Priority Area Identification**: Multi-criteria automated classification flagging wards with heavy congestion, full bins, or missed collections for administrative intervention.
5. **Traffic-Aware Waste Collection Recommendation**: Operational bridge linking sanitation urgency and road traffic to optimize dispatch timing, avoid high-congestion clearance delays, and automatically recommend available fleet vehicles without black-box ML.
6. **Smart Waste Collection Scheduling**: Dynamic time-window recommender using historical sensor traffic patterns by time of day to determine exactly *when* each bin should be collected ("Collect Now", next lower-traffic window, "Schedule Soon", or "Regular Collection").

---

## 6. Technology Stack
- **Database**: PostgreSQL 18.4 (Primary Data Store, Views, Triggers, Indexes)
- **Database Driver**: `psycopg2-binary` (Connection pooling & Parameterized queries)
- **Backend Framework**: Python 3.13 / Flask (Modular Blueprints, Session Authentication)
- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **Data Visualization**: Chart.js 4.x
- **Icons & Typography**: FontAwesome 6, Google Fonts (Inter)

---

## 7. Architecture

```
Frontend (HTML5 / CSS3 / JavaScript / Chart.js)
                      ↕ (REST Forms & JSON API)
Flask Backend Application (app.py, routes, auth, db pool)
                      ↕ (Parameterized SQL via psycopg2)
PostgreSQL Database Server (smartcity_db)
  ├── 8 Tables (areas, users, traffic_signals, traffic_records,
  │             traffic_incidents, waste_bins, collection_vehicles,
  │             collection_records)
  ├── Triggers (trg_update_bin_after_collection, trg_sync_bin_status)
  ├── Analytical Views (area_traffic_summary, area_waste_summary,
  │                     area_efficiency_view,
  │                     traffic_aware_collection_recommendation)
  └── B-Tree Indexes on high-frequency query columns
```

---

## 8. Database Schema (3NF)

```
[USERS] ──── (Role Authentication)
   │
[AREAS] ───┬── (1:N) ──> [TRAFFIC_SIGNALS] ── (1:N) ──> [TRAFFIC_RECORDS]
           ├── (1:N) ──> [TRAFFIC_INCIDENTS]
           └── (1:N) ──> [WASTE_BINS] ─────── (1:N) ──> [COLLECTION_RECORDS]
                                                               │ (N:1)
                                                     [COLLECTION_VEHICLES]
```

### Relational Schema Summary:
- **`areas`** (<ins>area_id</ins>, area_name, zone, population, description, created_at)
- **`users`** (<ins>user_id</ins>, name, username, password_hash, role, created_at)
- **`traffic_signals`** (<ins>signal_id</ins>, *area_id*, signal_name, location, status, created_at)
- **`traffic_records`** (<ins>traffic_id</ins>, *area_id*, *signal_id*, vehicle_count, congestion_level, recorded_date, recorded_time, created_at)
- **`traffic_incidents`** (<ins>incident_id</ins>, *area_id*, incident_type, severity, description, incident_date, status, created_at)
- **`waste_bins`** (<ins>bin_id</ins>, *area_id*, bin_location, capacity, current_level, status, last_collected, created_at)
- **`collection_vehicles`** (<ins>vehicle_id</ins>, vehicle_number, vehicle_type, capacity, status, created_at)
- **`collection_records`** (<ins>collection_id</ins>, *bin_id*, *vehicle_id*, driver_name, collected_quantity, collection_date, collection_status, failure_reason, created_at)

---

## 9. Folder Structure

```
Smart-City-Data-Management/
├── README.md
├── requirements.txt
├── .env.example
├── source-code/
│   ├── backend/
│   │   ├── app.py                  # Main Flask application factory
│   │   ├── config.py               # Database & session configuration
│   │   ├── db.py                   # PostgreSQL connection & query execution helper
│   │   ├── auth.py                 # Password hashing & session auth decorators
│   │   ├── routes_auth.py          # Login and logout routes
│   │   ├── routes_dashboard.py     # KPI summary & Chart.js API routes
│   │   ├── routes_traffic.py       # Traffic records & incidents CRUD routes
│   │   ├── routes_waste.py         # Waste bins & collection operations CRUD routes
│   │   ├── routes_analytics.py     # Cross-domain analytics & CSV export routes
│   │   ├── routes_areas.py         # City area directory routes
│   │   ├── routes_collection_recommendations.py # Traffic-aware collection decision support routes
│   │   ├── routes_smart_scheduler.py # Smart Waste Collection Scheduling routes & API
│   │   ├── init_db.py              # CLI database setup script
│   │   └── tests/
│   │       └── test_system.py      # Automated 19-test database & API test suite
│   ├── database/
│   │   ├── schema.sql              # DDL schema, constraints, views, indexes
│   │   ├── triggers.sql            # Automated business logic triggers
│   │   ├── data.sql                # Realistic sample datasets
│   │   ├── queries.sql             # Analytical queries (including Queries 11 & 12)
│   │   ├── traffic_aware_collection.sql # Dedicated recommendation view DDL
│   │   └── smart_collection_schedule.sql # Smart Collection Schedule view DDL
│   └── frontend/
│       ├── static/
│       │   ├── css/style.css       # Master stylesheet (with sequence & priority badges)
│       │   └── js/
│       │       ├── main.js         # Modal & alert handlers
│       │       ├── dashboard.js    # Chart.js visualization engine
│       │       ├── traffic.js      # Dynamic signal filtering & edit modals
│       │       ├── waste.js        # Fill meter & collection logging handlers
│       │       └── recommendations.js # Dynamic Chart.js charts & bin inspector modal
│       └── templates/
│           ├── base.html           # Master layout template (with Decision Support nav)
│           ├── login.html          # Authentication page with demo helpers
│           ├── dashboard.html      # KPI overview, 5 charts & Smart Collection Scheduler
│           ├── collection_recommendations.html # Full traffic-aware recommendations dashboard
│           ├── smart_scheduler.html # Dedicated Smart Collection Scheduler view
│           ├── traffic.html        # Traffic CRUD & incident logs
│           ├── waste.html          # Waste bins & collection logs
│           ├── analytics.html      # Cross-domain scoring & priority matrix
│           ├── areas.html          # City area directory
│           ├── 404.html            # Not found error page
│           └── 500.html            # Server error page
├── dataset/
│   ├── traffic_data.csv            # Exported traffic dataset
│   └── waste_data.csv              # Exported waste dataset
├── documentation/
│   ├── literature-review.md        # 8+ scholarly papers with Literature Matrix
│   ├── gap-analysis.md             # Multi-dimensional research gap analysis
│   ├── project-report.md           # Full academic project report
│   ├── er-diagram.png              # High-resolution ER diagram
│   └── database-schema.png         # Relational schema architecture graphic
└── results/
    ├── traffic_analytics_report.csv
    ├── waste_analytics_report.csv
    ├── area_efficiency_report.csv
    ├── priority_areas_summary.csv
    ├── traffic_aware_collection_report.csv
    ├── smart_collection_schedule_report.csv
    └── query_execution_benchmarks.txt
```
    └── query_execution_benchmarks.txt
```

---

## 10. Installation

### Prerequisites
- Python 3.10+
- PostgreSQL 14+ (tested on PostgreSQL 18.4)
- Git (optional)

### Setup Steps
1. Clone or extract the project repository:
   ```bash
   cd Smart-City-Data-Management
   ```

2. Install Python dependencies:
   ```bash
   pip install -r requirements.txt
   ```

---

## 11. Database Setup

1. Open PostgreSQL command line or pgAdmin:
   ```bash
   psql -U postgres
   ```

2. Create the project database:
   ```sql
   CREATE DATABASE smartcity_db;
   ```

3. Load the schema, triggers, and sample data using `init_db.py` or `psql`:
   ```bash
   python source-code/backend/init_db.py
   ```
   *Alternatively via psql:*
   ```bash
   psql -U postgres -d smartcity_db -f source-code/database/schema.sql
   psql -U postgres -d smartcity_db -f source-code/database/triggers.sql
   psql -U postgres -d smartcity_db -f source-code/database/data.sql
   ```

---

## 12. Running the Application

1. Start the Flask application server:
   ```bash
   cd source-code/backend
   python app.py
   ```

2. Open your web browser and navigate to:
   ```
   http://127.0.0.1:5000
   ```

3. To execute the automated test suite:
   ```bash
   python tests/test_system.py
   ```

---

## 13. Sample Login Credentials

| Role | Username | Password | Permissions |
|---|---|---|---|
| **System Administrator** | `admin` | `admin123` | Full CRUD across all tables, register areas, view analytics |
| **Municipal Operator** | `operator` | `operator123` | Traffic/waste data entry, status updates, view analytics |

*(Passwords are securely hashed using Scrypt/PBKDF2 in the database)*.

---

## 14. Screenshots

The application interface includes:
- **Executive Dashboard**: [Dashboard Overview](documentation/database-schema.png)
- **ER Diagram**: [ER Model Diagram](documentation/er-diagram.png)

---

## 15. Analytics & Area Efficiency Score Formula

### Deterministic Mathematical Model:
- **Traffic Score ($S_{\text{traffic}}$)**:
  $$S_{\text{traffic}} = 100 - \left[ 60 \times \frac{\text{High/Critical Records}}{\text{Total Records}} + 40 \times \frac{\text{Avg Vehicles in Area}}{\text{Max Avg Vehicles in City}} \right]$$

- **Waste Score ($S_{\text{waste}}$)**:
  $$S_{\text{waste}} = 40\% \times \text{Collection Efficiency} + 40\% \times (100 - \text{Fill Rate}) + 20\% \times (100 - \text{Overflow Rate})$$

- **Overall Area Efficiency Score**:
  $$\text{Overall Score} = \frac{S_{\text{traffic}} + S_{\text{waste}}}{2}$$

### Category Classification:
- **80–100**: *Excellent* (Green)
- **60–79**: *Good* (Blue)
- **40–59**: *Needs Attention* (Yellow/Orange)
- **0–39**: *Critical* (Red)

---

## 16. Traffic-Aware Waste Collection Recommendation Logic

### Concept & Rationale
Rather than treating vehicular traffic and solid waste collection as disconnected silos, the **Traffic-Aware Waste Collection Recommendation** engine connects latest area traffic conditions with waste urgency metrics. It operates as an explainable **Decision-Support Module** using a deterministic mathematical scoring formula.

### Deterministic Priority Scoring Model (0–100)
For every municipal waste bin, the system calculates a normalized priority score:

$$\text{Priority Score} = \min\left(100.0, \; S_{\text{fill}} + S_{\text{status}} + S_{\text{stale}} + S_{\text{traffic}} + S_{\text{col}}\right)$$

Where:
1. **Waste Fill Level Urgency ($S_{\text{fill}}$, Max 40 pts)**:
   $$S_{\text{fill}} = 40.0 \times \left(\frac{\text{current\_level}}{\text{capacity}}\right)$$
2. **Container Criticality State ($S_{\text{status}}$, Max 15 pts)**:
   $$S_{\text{status}} = \begin{cases} 15.0 & \text{if status} = \text{'Overflow Risk'} \\ 10.0 & \text{if status} = \text{'Full'} \\ 0.0 & \text{otherwise} \end{cases}$$
3. **Staleness / Collection Interval ($S_{\text{stale}}$, Max 10 pts)**:
   $$S_{\text{stale}} = \begin{cases} 10.0 & \text{if uncollected for} > 48\text{ hrs (or never collected)} \\ 5.0 & \text{if uncollected for} 24\text{–}48\text{ hrs} \\ 0.0 & \text{otherwise} \end{cases}$$
4. **Traffic Congestion Penalty ($S_{\text{traffic}}$, Max 20 pts)**:
   Reflects the scheduling difficulty and urgency multiplier of the bin's host area based on the latest traffic record:
   $$S_{\text{traffic}} = \begin{cases} 20.0 & \text{if latest congestion} = \text{'Critical'} \\ 15.0 & \text{if latest congestion} = \text{'High'} \\ 8.0 & \text{if latest congestion} = \text{'Medium'} \\ 0.0 & \text{if latest congestion} = \text{'Low'} \end{cases}$$
5. **Collection Incident Urgency ($S_{\text{col}}$, Max 15 pts)**:
   $$S_{\text{col}} = \begin{cases} 15.0 & \text{if latest collection status} = \text{'Failed'} \\ 10.0 & \text{if latest collection status} = \text{'Pending'} \\ 0.0 & \text{otherwise} \end{cases}$$

### Priority Level Classification
- **90–100**: **CRITICAL** (Requires urgent action or scheduled immediate intervention)
- **70–89**: **HIGH** (High urgency container requiring prioritized scheduling)
- **40–69**: **MEDIUM** (Routine collection during regular operating shift)
- **0–39**: **LOW** (Adequate capacity; continue monitoring)

### Traffic-Aware Action Directives & Decision Reasoning
The engine couples fill level with area congestion to generate human-readable operational guidelines:
- **High Waste ($\ge 85\%$) + Low/Medium Traffic**:
  - *Action*: `"Collect Immediately — Favorable Traffic Window"`
  - *Reason*: `"Critical waste fill with low traffic congestion; optimal for rapid truck clearance."`
- **High Waste ($\ge 85\%$) + High/Critical Traffic**:
  - *Action*: `"Critical Priority — Schedule for Off-Peak Window"`
  - *Reason*: `"Urgent waste level but severe road congestion; dispatch during early morning/off-peak to prevent gridlock."`
- **Moderate Waste ($50\%\text{–}84\%$) + Critical Traffic**:
  - *Action*: `"Defer Route — Traffic Gridlock"`
  - *Reason*: `"Moderate waste fill but critical traffic delays; prioritize lower-congestion corridors first."`
- **Moderate Waste ($50\%\text{–}84\%$) + Low/Medium Traffic**:
  - *Action*: `"Collect During Routine Shift"`
  - *Reason*: `"Sufficient road capacity for routine scheduled clearance."`
- **Low Waste ($< 50\%$)**:
  - *Action*: `"Monitor Container Fill Level"`
  - *Reason*: `"Container has ample remaining capacity; collection not urgently required."`

### Fleet Vehicle Assignment Logic
- Strictly evaluates fleet vehicles with `status = 'Available'`.
- Matches the nearest capacity-fit vehicle (`capacity >= current_level`) from `collection_vehicles`.
- Unavailable vehicles (`'On Route'`, `'Maintenance'`) are excluded.

### Decision-Support Boundaries
> [!NOTE]
> This feature is an explainable **Decision-Support System** (DSS). It does **not** employ Machine Learning or black-box neural networks, nor does it claim to solve NP-hard Vehicle Routing Problems (VRP). It provides deterministic, audit-proof recommendations directly within the relational database layer.

---

## 17. Smart Waste Collection Scheduling Logic

### Concept & Motivation
While priority scoring determines *which* bins should be collected first, municipal dispatchers also need to know **when** a container should be collected to avoid traffic congestion bottlenecks. The **Smart Waste Collection Scheduler** answers:
> *"Given the current waste condition and traffic condition, when should this bin preferably be collected?"*

### Simple 4-Rule Decision Logic
The system evaluates the bin's fill level, container status, corridor traffic, and historical lower-traffic periods:
1. **High Waste Level ($\ge 70\%$ or Overflow Risk) + Low/Medium Traffic**:
   - **Recommended Time**: `"Collect Now"`
   - **Reason**: `"High waste level with low current traffic. Immediate collection is recommended."`
2. **High Waste Level ($\ge 70\%$ or Overflow Risk) + High/Critical Traffic**:
   - **Recommended Time**: Historical lower-traffic time period for that ward (e.g., `"4:15 PM"`, `"12:00 PM"`, `"8:00 PM"`).
   - **Reason**: `"High waste level with high current traffic. Collection is recommended during the next lower-traffic period."`
3. **Medium Waste Level ($40\%\text{–}69\%$)**:
   - **Recommended Time**: `"Schedule Soon"`
   - **Reason**: `"Medium waste level with manageable traffic. Scheduled collection recommended soon."`
4. **Low Waste Level ($< 40\%$)**:
   - **Recommended Time**: `"Regular Collection"`
   - **Reason**: `"Low waste level with ample remaining capacity. Recommended for regular collection."`

### Database Implementation
Implemented via the analytical SQL view `smart_collection_schedule_view` querying:
- `waste_bins` & `areas`
- `traffic_aware_collection_recommendation`
- Historical `traffic_records` using `DISTINCT ON (area_id) ... ORDER BY congestion_level ASC, vehicle_count ASC`

### User Interface & Modals
- Displayed in the Executive Dashboard under **"Smart Collection Scheduler"**:
  `| Bin | Area | Fill Level | Traffic | Priority | Recommended Time | Action |`
- Clicking any bin code or the **Schedule** button triggers a responsive inspector modal displaying bin details, area, fill %, traffic condition, priority, recommended time, and the explainable decision reason.
- Dedicated page accessible at `/smart-scheduler` with REST API endpoints at `/api/smart-scheduler` and `/api/smart-scheduler/<bin_id>`.

---

## 18. Future Scope
- Integration with GIS Spatial extensions (PostGIS) for polygon mapping.
- Citizen mobile reporting portal with geotagged photo uploads.
- Dynamic vehicle dispatch route optimization linked with live congestion feeds.

---

## 19. Team / Authors
- **Project Type**: B.Tech Database Management System (DBMS) Academic Capstone Project
- **Domain Focus**: Smart City Urban Analytics (Traffic & Solid Waste Management)
- **Academic Year**: 2025–2026
