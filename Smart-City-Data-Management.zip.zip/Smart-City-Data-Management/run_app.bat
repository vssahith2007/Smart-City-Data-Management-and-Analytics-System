@echo off
title Smart City Data Management and Analytics System - Flask Server
echo ====================================================================
echo Starting Smart City DBMS Web Application...
echo ====================================================================
cd /d "%~dp0source-code\backend"
"C:\Users\vssah\New folder\python.exe" app.py
pause
