-- ====================================================================
-- Smart City Data Management and Analytics System
-- PostgreSQL Database Schema (schema.sql)
-- Normalized to 3NF with Primary Keys, Foreign Keys, & Constraints
-- ====================================================================

-- Drop existing views if any
DROP VIEW IF EXISTS area_efficiency_view CASCADE;
DROP VIEW IF EXISTS area_waste_summary CASCADE;
DROP VIEW IF EXISTS area_traffic_summary CASCADE;

-- Drop existing tables if any (in reverse dependency order)
DROP TABLE IF EXISTS collection_records CASCADE;
DROP TABLE IF EXISTS collection_vehicles CASCADE;
DROP TABLE IF EXISTS waste_bins CASCADE;
DROP TABLE IF EXISTS traffic_incidents CASCADE;
DROP TABLE IF EXISTS traffic_records CASCADE;
DROP TABLE IF EXISTS traffic_signals CASCADE;
DROP TABLE IF EXISTS users CASCADE;
DROP TABLE IF EXISTS areas CASCADE;

-- --------------------------------------------------------------------
-- 1. AREA TABLE (Master Entity for Cross-Domain Analytics)
-- --------------------------------------------------------------------
CREATE TABLE areas (
    area_id SERIAL PRIMARY KEY,
    area_name VARCHAR(100) UNIQUE NOT NULL,
    zone VARCHAR(50) NOT NULL,
    population INT NOT NULL CHECK (population >= 0),
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- --------------------------------------------------------------------
-- 2. USER TABLE (Role-Based Authentication & Access Control)
-- --------------------------------------------------------------------
CREATE TABLE users (
    user_id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL CHECK (role IN ('Admin', 'Operator')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- --------------------------------------------------------------------
-- 3. TRAFFIC_SIGNAL TABLE (Traffic Control Infrastructure)
-- --------------------------------------------------------------------
CREATE TABLE traffic_signals (
    signal_id SERIAL PRIMARY KEY,
    area_id INT NOT NULL REFERENCES areas(area_id) ON DELETE CASCADE,
    signal_name VARCHAR(100) NOT NULL,
    location VARCHAR(150) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'Active' CHECK (status IN ('Active', 'Inactive', 'Maintenance')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- --------------------------------------------------------------------
-- 4. TRAFFIC_RECORD TABLE (Time-Series Congestion & Density Data)
-- --------------------------------------------------------------------
CREATE TABLE traffic_records (
    traffic_id SERIAL PRIMARY KEY,
    area_id INT NOT NULL REFERENCES areas(area_id) ON DELETE CASCADE,
    signal_id INT NOT NULL REFERENCES traffic_signals(signal_id) ON DELETE CASCADE,
    vehicle_count INT NOT NULL CHECK (vehicle_count >= 0),
    congestion_level VARCHAR(20) NOT NULL CHECK (congestion_level IN ('Low', 'Medium', 'High', 'Critical')),
    recorded_date DATE NOT NULL,
    recorded_time TIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- --------------------------------------------------------------------
-- 5. TRAFFIC_INCIDENT TABLE (Accidents, Roadworks, & Bottlenecks)
-- --------------------------------------------------------------------
CREATE TABLE traffic_incidents (
    incident_id SERIAL PRIMARY KEY,
    area_id INT NOT NULL REFERENCES areas(area_id) ON DELETE CASCADE,
    incident_type VARCHAR(50) NOT NULL CHECK (incident_type IN ('Accident', 'Roadwork', 'Vehicle Breakdown', 'Signal Failure', 'Other')),
    severity VARCHAR(20) NOT NULL CHECK (severity IN ('Minor', 'Moderate', 'Major', 'Critical')),
    description TEXT,
    incident_date DATE NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'Reported' CHECK (status IN ('Reported', 'Investigating', 'Resolved')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- --------------------------------------------------------------------
-- 6. WASTE_BIN TABLE (Smart Waste Collection Points)
-- --------------------------------------------------------------------
CREATE TABLE waste_bins (
    bin_id SERIAL PRIMARY KEY,
    area_id INT NOT NULL REFERENCES areas(area_id) ON DELETE CASCADE,
    bin_location VARCHAR(150) NOT NULL,
    capacity NUMERIC(8,2) NOT NULL CHECK (capacity > 0),
    current_level NUMERIC(8,2) NOT NULL CHECK (current_level >= 0 AND current_level <= capacity),
    status VARCHAR(30) NOT NULL DEFAULT 'Normal' CHECK (status IN ('Normal', 'Full', 'Overflow Risk', 'Under Maintenance')),
    last_collected TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- --------------------------------------------------------------------
-- 7. COLLECTION_VEHICLE TABLE (Municipal Sanitation Fleet)
-- --------------------------------------------------------------------
CREATE TABLE collection_vehicles (
    vehicle_id SERIAL PRIMARY KEY,
    vehicle_number VARCHAR(20) UNIQUE NOT NULL,
    vehicle_type VARCHAR(50) NOT NULL CHECK (vehicle_type IN ('Compactor Truck', 'Tipper Truck', 'Mini Truck', 'Dumper Placer')),
    capacity NUMERIC(10,2) NOT NULL CHECK (capacity > 0),
    current_load NUMERIC(10,2) NOT NULL DEFAULT 0.00 CHECK (current_load >= 0 AND current_load <= capacity),
    status VARCHAR(20) NOT NULL DEFAULT 'Available' CHECK (status IN ('Available', 'On Route', 'Maintenance')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- --------------------------------------------------------------------
-- 8. COLLECTION_RECORD TABLE (Waste Collection Operational Logs)
-- --------------------------------------------------------------------
CREATE TABLE collection_records (
    collection_id SERIAL PRIMARY KEY,
    bin_id INT NOT NULL REFERENCES waste_bins(bin_id) ON DELETE CASCADE,
    vehicle_id INT NOT NULL REFERENCES collection_vehicles(vehicle_id) ON DELETE CASCADE,
    driver_name VARCHAR(100) DEFAULT 'Municipal Fleet Driver',
    collected_quantity NUMERIC(8,2) NOT NULL CHECK (collected_quantity >= 0),
    collection_date DATE NOT NULL,
    collection_status VARCHAR(20) NOT NULL DEFAULT 'Completed' CHECK (collection_status IN ('Completed', 'Pending', 'Failed', 'Scheduled')),
    failure_reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- --------------------------------------------------------------------
-- 9. WASTE_DISPOSAL TABLE (Municipal Disposal & Landfill Unload History)
-- --------------------------------------------------------------------
CREATE TABLE waste_disposals (
    disposal_id SERIAL PRIMARY KEY,
    vehicle_id INT NOT NULL REFERENCES collection_vehicles(vehicle_id) ON DELETE CASCADE,
    disposed_quantity NUMERIC(10,2) NOT NULL CHECK (disposed_quantity >= 0),
    facility_name VARCHAR(150) NOT NULL DEFAULT 'Central Waste Processing & Recycling Facility',
    disposal_date DATE NOT NULL DEFAULT CURRENT_DATE,
    disposal_time TIME NOT NULL DEFAULT CURRENT_TIME,
    operator_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ====================================================================
-- PERFORMANCE INDEXES
-- ====================================================================
CREATE INDEX idx_traffic_records_area ON traffic_records(area_id);
CREATE INDEX idx_traffic_records_date ON traffic_records(recorded_date);
CREATE INDEX idx_traffic_records_congestion ON traffic_records(congestion_level);
CREATE INDEX idx_traffic_incidents_area ON traffic_incidents(area_id);
CREATE INDEX idx_waste_bins_area ON waste_bins(area_id);
CREATE INDEX idx_waste_bins_status ON waste_bins(status);
CREATE INDEX idx_collection_records_bin ON collection_records(bin_id);
CREATE INDEX idx_collection_records_date ON collection_records(collection_date);
CREATE INDEX idx_collection_records_status ON collection_records(collection_status);

-- ====================================================================
-- ANALYTICAL VIEWS
-- ====================================================================

-- 1. Area Traffic Summary View
CREATE OR REPLACE VIEW area_traffic_summary AS
SELECT 
    a.area_id,
    a.area_name,
    a.zone,
    a.population,
    COUNT(tr.traffic_id) AS total_traffic_records,
    COALESCE(SUM(tr.vehicle_count), 0) AS total_vehicles,
    COALESCE(ROUND(AVG(tr.vehicle_count), 2), 0) AS avg_vehicle_count,
    COUNT(CASE WHEN tr.congestion_level = 'Low' THEN 1 END) AS low_congestion_count,
    COUNT(CASE WHEN tr.congestion_level = 'Medium' THEN 1 END) AS medium_congestion_count,
    COUNT(CASE WHEN tr.congestion_level = 'High' THEN 1 END) AS high_congestion_count,
    COUNT(CASE WHEN tr.congestion_level = 'Critical' THEN 1 END) AS critical_congestion_count,
    COUNT(DISTINCT ts.signal_id) AS total_signals,
    COUNT(DISTINCT ti.incident_id) AS total_incidents
FROM areas a
LEFT JOIN traffic_signals ts ON a.area_id = ts.area_id
LEFT JOIN traffic_records tr ON a.area_id = tr.area_id
LEFT JOIN traffic_incidents ti ON a.area_id = ti.area_id
GROUP BY a.area_id, a.area_name, a.zone, a.population;

-- 2. Area Waste Summary View
CREATE OR REPLACE VIEW area_waste_summary AS
SELECT 
    a.area_id,
    a.area_name,
    a.zone,
    COUNT(wb.bin_id) AS total_bins,
    COALESCE(SUM(wb.capacity), 0) AS total_bin_capacity,
    COALESCE(SUM(wb.current_level), 0) AS total_current_waste,
    CASE 
        WHEN COALESCE(SUM(wb.capacity), 0) > 0 
        THEN ROUND((SUM(wb.current_level) / SUM(wb.capacity)) * 100, 2)
        ELSE 0.00 
    END AS avg_fill_percentage,
    COUNT(CASE WHEN wb.status IN ('Full', 'Overflow Risk') THEN 1 END) AS overflow_risk_bins,
    COUNT(cr.collection_id) AS total_collections,
    COUNT(CASE WHEN cr.collection_status = 'Completed' THEN 1 END) AS completed_collections,
    COUNT(CASE WHEN cr.collection_status IN ('Pending', 'Failed') THEN 1 END) AS pending_collections,
    CASE 
        WHEN COUNT(cr.collection_id) > 0 
        THEN ROUND((COUNT(CASE WHEN cr.collection_status = 'Completed' THEN 1 END)::NUMERIC / COUNT(cr.collection_id)) * 100, 2)
        ELSE 100.00 
    END AS collection_efficiency
FROM areas a
LEFT JOIN waste_bins wb ON a.area_id = wb.area_id
LEFT JOIN collection_records cr ON wb.bin_id = cr.bin_id
GROUP BY a.area_id, a.area_name, a.zone;

-- 3. Area Efficiency Score & Cross-Domain View
CREATE OR REPLACE VIEW area_efficiency_view AS
WITH max_traffic AS (
    SELECT COALESCE(MAX(avg_vehicle_count), 1) AS max_avg_vehicles
    FROM area_traffic_summary
)
SELECT 
    t.area_id,
    t.area_name,
    t.zone,
    t.population,
    t.total_traffic_records,
    t.total_vehicles,
    t.avg_vehicle_count,
    t.high_congestion_count + t.critical_congestion_count AS heavy_congestion_count,
    w.total_bins,
    w.total_current_waste,
    w.avg_fill_percentage,
    w.overflow_risk_bins,
    w.collection_efficiency,
    w.pending_collections,
    
    -- Traffic Score (0 to 100)
    GREATEST(0, LEAST(100, ROUND(
        100 - (
            (CASE WHEN t.total_traffic_records > 0 
                  THEN ((t.high_congestion_count + t.critical_congestion_count)::NUMERIC / t.total_traffic_records) * 60 
                  ELSE 0 END) +
            ((t.avg_vehicle_count / mt.max_avg_vehicles) * 40)
        )
    ))) AS traffic_score,

    -- Waste Score (0 to 100)
    GREATEST(0, LEAST(100, ROUND(
        (w.collection_efficiency * 0.40) +
        ((100 - LEAST(100, w.avg_fill_percentage)) * 0.40) +
        (CASE WHEN w.total_bins > 0 
              THEN (100 - ((w.overflow_risk_bins::NUMERIC / w.total_bins) * 100)) * 0.20 
              ELSE 20 END)
    ))) AS waste_score,

    -- Overall Area Efficiency Score (Average)
    GREATEST(0, LEAST(100, ROUND(
        (
            GREATEST(0, LEAST(100, ROUND(
                100 - (
                    (CASE WHEN t.total_traffic_records > 0 
                          THEN ((t.high_congestion_count + t.critical_congestion_count)::NUMERIC / t.total_traffic_records) * 60 
                          ELSE 0 END) +
                    ((t.avg_vehicle_count / mt.max_avg_vehicles) * 40)
                )
            ))) +
            GREATEST(0, LEAST(100, ROUND(
                (w.collection_efficiency * 0.40) +
                ((100 - LEAST(100, w.avg_fill_percentage)) * 0.40) +
                (CASE WHEN w.total_bins > 0 
                      THEN (100 - ((w.overflow_risk_bins::NUMERIC / w.total_bins) * 100)) * 0.20 
                      ELSE 20 END)
            )))
        ) / 2.0
    ))) AS overall_score,

    -- Categorization
    CASE 
        WHEN GREATEST(0, LEAST(100, ROUND(
            (
                GREATEST(0, LEAST(100, ROUND(
                    100 - (
                        (CASE WHEN t.total_traffic_records > 0 
                              THEN ((t.high_congestion_count + t.critical_congestion_count)::NUMERIC / t.total_traffic_records) * 60 
                              ELSE 0 END) +
                        ((t.avg_vehicle_count / mt.max_avg_vehicles) * 40)
                    )
                ))) +
                GREATEST(0, LEAST(100, ROUND(
                    (w.collection_efficiency * 0.40) +
                    ((100 - LEAST(100, w.avg_fill_percentage)) * 0.40) +
                    (CASE WHEN w.total_bins > 0 
                          THEN (100 - ((w.overflow_risk_bins::NUMERIC / w.total_bins) * 100)) * 0.20 
                          ELSE 20 END)
                )))
            ) / 2.0
        ))) >= 80 THEN 'Excellent'
        WHEN GREATEST(0, LEAST(100, ROUND(
            (
                GREATEST(0, LEAST(100, ROUND(
                    100 - (
                        (CASE WHEN t.total_traffic_records > 0 
                              THEN ((t.high_congestion_count + t.critical_congestion_count)::NUMERIC / t.total_traffic_records) * 60 
                              ELSE 0 END) +
                        ((t.avg_vehicle_count / mt.max_avg_vehicles) * 40)
                    )
                ))) +
                GREATEST(0, LEAST(100, ROUND(
                    (w.collection_efficiency * 0.40) +
                    ((100 - LEAST(100, w.avg_fill_percentage)) * 0.40) +
                    (CASE WHEN w.total_bins > 0 
                          THEN (100 - ((w.overflow_risk_bins::NUMERIC / w.total_bins) * 100)) * 0.20 
                          ELSE 20 END)
                )))
            ) / 2.0
        ))) >= 60 THEN 'Good'
        WHEN GREATEST(0, LEAST(100, ROUND(
            (
                GREATEST(0, LEAST(100, ROUND(
                    100 - (
                        (CASE WHEN t.total_traffic_records > 0 
                              THEN ((t.high_congestion_count + t.critical_congestion_count)::NUMERIC / t.total_traffic_records) * 60 
                              ELSE 0 END) +
                        ((t.avg_vehicle_count / mt.max_avg_vehicles) * 40)
                    )
                ))) +
                GREATEST(0, LEAST(100, ROUND(
                    (w.collection_efficiency * 0.40) +
                    ((100 - LEAST(100, w.avg_fill_percentage)) * 0.40) +
                    (CASE WHEN w.total_bins > 0 
                          THEN (100 - ((w.overflow_risk_bins::NUMERIC / w.total_bins) * 100)) * 0.20 
                          ELSE 20 END)
                )))
            ) / 2.0
        ))) >= 40 THEN 'Needs Attention'
        ELSE 'Critical'
    END AS efficiency_category

FROM area_traffic_summary t
JOIN area_waste_summary w ON t.area_id = w.area_id
CROSS JOIN max_traffic mt;

-- ====================================================================
-- 4. TRAFFIC-AWARE WASTE COLLECTION RECOMMENDATION VIEW
-- Decision-Support View connecting Traffic Congestion, Waste Urgency,
-- Prior Collection Attempts, and Available Fleet Assignment.
-- ====================================================================
DROP VIEW IF EXISTS traffic_aware_collection_recommendation;

CREATE OR REPLACE VIEW traffic_aware_collection_recommendation AS
WITH latest_traffic AS (
    SELECT DISTINCT ON (area_id)
        area_id,
        vehicle_count,
        congestion_level,
        recorded_date,
        recorded_time
    FROM traffic_records
    ORDER BY area_id, recorded_date DESC, recorded_time DESC, traffic_id DESC
),
latest_collection AS (
    SELECT DISTINCT ON (bin_id)
        bin_id,
        collection_id,
        collection_status,
        collection_date,
        failure_reason,
        driver_name
    FROM collection_records
    ORDER BY bin_id, collection_date DESC, collection_id DESC
),
scored_bins AS (
    SELECT 
        wb.bin_id,
        wb.area_id,
        a.area_name,
        a.zone,
        wb.bin_location,
        wb.capacity,
        wb.current_level,
        ROUND((wb.current_level / NULLIF(wb.capacity, 0)) * 100, 1) AS fill_percentage,
        wb.status AS bin_status,
        wb.last_collected,
        COALESCE(lt.congestion_level, 'Medium') AS traffic_congestion,
        COALESCE(lt.vehicle_count, 0) AS vehicle_count,
        lt.recorded_time AS traffic_recorded_time,
        COALESCE(lc.collection_status, 'Completed') AS last_collection_status,
        lc.failure_reason AS last_failure_reason,
        lc.driver_name AS last_driver_name,
        -- Waste Collection Priority Score (0 to 100)
        GREATEST(0, LEAST(100, ROUND(
            -- Waste Urgency (0 to 50)
            ((wb.current_level / NULLIF(wb.capacity, 0)) * 40.0) +
            (CASE WHEN wb.status IN ('Full', 'Overflow Risk') OR (wb.current_level / NULLIF(wb.capacity, 0)) >= 0.80 THEN 5 ELSE 0 END) +
            (CASE WHEN wb.last_collected IS NULL OR (CURRENT_TIMESTAMP - wb.last_collected) > INTERVAL '2 days' THEN 5 ELSE 0 END) +
            -- Traffic Condition (0 to 30)
            (CASE COALESCE(lt.congestion_level, 'Medium')
                WHEN 'Critical' THEN 30
                WHEN 'High' THEN 22
                WHEN 'Medium' THEN 14
                WHEN 'Low' THEN 6
                ELSE 14 END) +
            -- Collection Condition (0 to 20)
            (CASE COALESCE(lc.collection_status, 'Completed')
                WHEN 'Failed' THEN 20
                WHEN 'Pending' THEN 14
                WHEN 'Scheduled' THEN 8
                ELSE 2 END)
        ))) AS priority_score,
        -- Traffic Clearance Weight for Sequence Dispatchability
        CASE COALESCE(lt.congestion_level, 'Medium')
            WHEN 'Low' THEN 20
            WHEN 'Medium' THEN 10
            WHEN 'High' THEN -5
            WHEN 'Critical' THEN -15
            ELSE 0
        END AS traffic_clearance_bonus
    FROM waste_bins wb
    JOIN areas a ON wb.area_id = a.area_id
    LEFT JOIN latest_traffic lt ON wb.area_id = lt.area_id
    LEFT JOIN latest_collection lc ON wb.bin_id = lc.bin_id
)
SELECT 
    sb.bin_id,
    sb.area_id,
    sb.area_name,
    sb.zone,
    sb.bin_location,
    sb.capacity,
    sb.current_level,
    sb.fill_percentage,
    sb.bin_status,
    sb.last_collected,
    sb.traffic_congestion,
    sb.vehicle_count,
    sb.traffic_recorded_time,
    sb.last_collection_status,
    sb.last_failure_reason,
    sb.last_driver_name,
    sb.priority_score,
    
    -- Priority Classification
    CASE 
        WHEN sb.priority_score >= 90 THEN 'Critical'
        WHEN sb.priority_score >= 70 THEN 'High'
        WHEN sb.priority_score >= 40 THEN 'Medium'
        ELSE 'Low'
    END AS priority_level,

    -- Recommended Action
    CASE 
        WHEN sb.last_collection_status = 'Failed' THEN 
            'Priority Re-attempt (Previously Failed Trip)'
        WHEN sb.fill_percentage >= 85 AND sb.traffic_congestion = 'Low' THEN 
            'Collect Immediately (Optimal Traffic Window)'
        WHEN sb.fill_percentage >= 85 AND sb.traffic_congestion = 'Medium' THEN 
            'Collect Soon (Active Route)'
        WHEN sb.fill_percentage >= 85 AND sb.traffic_congestion IN ('High', 'Critical') THEN 
            'Critical Urgency - Schedule Off-Peak Window'
        WHEN sb.fill_percentage >= 70 AND sb.traffic_congestion = 'Low' THEN 
            'Collect Soon (Favorable Conditions)'
        WHEN sb.fill_percentage >= 70 AND sb.traffic_congestion = 'Medium' THEN 
            'Standard Scheduled Route'
        WHEN sb.fill_percentage >= 70 AND sb.traffic_congestion IN ('High', 'Critical') THEN 
            'Delay Collection / Await Traffic Clearance'
        WHEN sb.fill_percentage < 70 AND sb.traffic_congestion IN ('High', 'Critical') THEN 
            'Defer Route / Monitor Fill Level'
        ELSE 
            'Routine Monitoring / Safe Capacity'
    END AS recommended_action,

    -- Recommendation Reason
    CASE 
        WHEN sb.last_collection_status = 'Failed' THEN 
            'Previous collection attempt failed (' || COALESCE(sb.last_failure_reason, 'driver reported obstacle') || '). Immediate supervisory dispatch recommended.'
        WHEN sb.fill_percentage >= 85 AND sb.traffic_congestion = 'Low' THEN 
            'Critical waste accumulation combined with free-flowing traffic. Immediate dispatch yields zero travel delay.'
        WHEN sb.fill_percentage >= 85 AND sb.traffic_congestion = 'Medium' THEN 
            'High container capacity with moderate transit flow. Suitable for immediate regular routing.'
        WHEN sb.fill_percentage >= 85 AND sb.traffic_congestion IN ('High', 'Critical') THEN 
            'Severe waste overflow hazard, but heavy corridor congestion will stall heavy collection vehicles. Dispatch during early morning/evening off-peak window.'
        WHEN sb.fill_percentage >= 70 AND sb.traffic_congestion = 'Low' THEN 
            'Substantial waste volume with clear roadways. Emptying now prevents overflow during upcoming peak periods.'
        WHEN sb.fill_percentage >= 70 AND sb.traffic_congestion = 'Medium' THEN 
            'Moderate fill with steady traffic movement. Assigned to standard municipal collection cycle.'
        WHEN sb.fill_percentage >= 70 AND sb.traffic_congestion IN ('High', 'Critical') THEN 
            'Notable waste accumulation; however, heavy congestion creates gridlock risk. Defer truck entry until intersection clears.'
        WHEN sb.fill_percentage < 70 AND sb.traffic_congestion IN ('High', 'Critical') THEN 
            'Container is below critical threshold. Avoid routing heavy trucks into active traffic bottlenecks.'
        ELSE 
            'Container is within safe operating capacity with low-to-medium traffic. Continue standard monitoring.'
    END AS recommendation_reason,

    -- Preferred Collection Sequence Order
    ROW_NUMBER() OVER (
        ORDER BY 
            (sb.priority_score + sb.traffic_clearance_bonus) DESC, 
            sb.priority_score DESC, 
            sb.bin_id ASC
    ) AS recommended_sequence,

    -- Vehicle Assignment (Matching Best Available Vehicle)
    rec_veh.vehicle_id,
    rec_veh.vehicle_number,
    rec_veh.vehicle_type,
    rec_veh.capacity AS vehicle_capacity

FROM scored_bins sb
LEFT JOIN LATERAL (
    SELECT cv.vehicle_id, cv.vehicle_number, cv.vehicle_type, cv.capacity
    FROM collection_vehicles cv
    WHERE cv.status = 'Available'
      AND cv.capacity >= sb.current_level
    ORDER BY 
        CASE 
            WHEN sb.current_level >= 1500 THEN 
                CASE cv.vehicle_type WHEN 'Compactor Truck' THEN 1 WHEN 'Tipper Truck' THEN 2 ELSE 3 END
            WHEN sb.current_level >= 1000 THEN 
                CASE cv.vehicle_type WHEN 'Tipper Truck' THEN 1 WHEN 'Compactor Truck' THEN 2 ELSE 3 END
            ELSE 
                CASE cv.vehicle_type WHEN 'Mini Truck' THEN 1 WHEN 'Tipper Truck' THEN 2 ELSE 3 END
        END ASC,
        cv.capacity ASC
    LIMIT 1
) rec_veh ON true;

-- ====================================================================
-- 5. SMART WASTE COLLECTION SCHEDULING VIEW
-- Recommends optimal collection time (Collect Now, Lower-Traffic Time,
-- Schedule Soon, Regular Collection) based on fill %, priority, and
-- historical traffic patterns by time.
-- ====================================================================
CREATE OR REPLACE VIEW smart_collection_schedule_view AS
WITH area_lower_traffic AS (
    SELECT DISTINCT ON (tr.area_id)
        tr.area_id,
        tr.recorded_time,
        tr.congestion_level,
        tr.vehicle_count
    FROM traffic_records tr
    ORDER BY tr.area_id,
        CASE tr.congestion_level
            WHEN 'Low' THEN 1
            WHEN 'Medium' THEN 2
            WHEN 'High' THEN 3
            WHEN 'Critical' THEN 4
            ELSE 5
        END ASC,
        tr.vehicle_count ASC
)
SELECT 
    r.bin_id,
    'B' || r.bin_id AS bin_code,
    r.bin_location,
    r.area_id,
    r.area_name,
    r.zone,
    r.capacity,
    r.current_level,
    r.fill_percentage,
    r.bin_status,
    r.traffic_congestion,
    r.vehicle_count AS traffic_vehicle_count,
    r.traffic_recorded_time,
    r.priority_score,
    r.priority_level,
    TO_CHAR(alt.recorded_time, 'FMHH12:MI AM') AS lower_traffic_time,
    alt.congestion_level AS lower_traffic_congestion,
    alt.vehicle_count AS lower_traffic_vehicle_count,
    CASE
        WHEN (r.fill_percentage >= 70.0 OR r.bin_status IN ('Full', 'Overflow Risk')) 
             AND r.traffic_congestion IN ('Low', 'Medium')
            THEN 'Collect Now'
        WHEN (r.fill_percentage >= 70.0 OR r.bin_status IN ('Full', 'Overflow Risk')) 
             AND r.traffic_congestion IN ('High', 'Critical')
            THEN COALESCE(TO_CHAR(alt.recorded_time, 'FMHH12:MI AM'), 'Off-Peak Window')
        WHEN r.fill_percentage >= 40.0
            THEN 'Schedule Soon'
        ELSE 'Regular Collection'
    END AS recommended_time,
    CASE
        WHEN (r.fill_percentage >= 70.0 OR r.bin_status IN ('Full', 'Overflow Risk')) 
             AND r.traffic_congestion IN ('Low', 'Medium')
            THEN 'High waste level with low current traffic. Immediate collection is recommended.'
        WHEN (r.fill_percentage >= 70.0 OR r.bin_status IN ('Full', 'Overflow Risk')) 
             AND r.traffic_congestion IN ('High', 'Critical')
            THEN 'High waste level with high current traffic. Collection is recommended during the next lower-traffic period.'
        WHEN r.fill_percentage >= 40.0
            THEN 'Medium waste level with manageable traffic. Scheduled collection recommended soon.'
        ELSE 'Low waste level with ample remaining capacity. Recommended for regular collection.'
    END AS recommendation_reason,
    r.recommended_sequence
FROM traffic_aware_collection_recommendation r
LEFT JOIN area_lower_traffic alt ON r.area_id = alt.area_id
ORDER BY r.recommended_sequence ASC, r.bin_id ASC;


