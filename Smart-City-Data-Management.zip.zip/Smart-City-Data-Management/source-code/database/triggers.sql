-- ====================================================================
-- Smart City Data Management and Analytics System
-- PostgreSQL Database Triggers (triggers.sql)
-- Meaningful business rules enforcing data integrity & operational workflows
-- ====================================================================

-- --------------------------------------------------------------------
-- TRIGGER 1: Automated Waste Bin Reduction & Vehicle Load Management
-- Business logic: When a collection is completed:
-- 1. Validates that vehicle load + collected_quantity does not exceed capacity.
-- 2. Increments the assigned vehicle's current_load by collected_quantity.
-- 3. Reduces the waste bin's current_level by collected_quantity.
--    Full collection: current_level becomes 0.
--    Partial collection: current_level reduced by collected_quantity.
-- 4. Records last_collected timestamp.
-- 5. Prevents double-counting on redundant updates.
-- --------------------------------------------------------------------

CREATE OR REPLACE FUNCTION func_update_bin_after_collection()
RETURNS TRIGGER AS $$
DECLARE
    v_veh RECORD;
BEGIN
    -- Only execute when status is Completed AND (either a new record or transitioning from non-Completed to Completed)
    IF NEW.collection_status = 'Completed' AND (TG_OP = 'INSERT' OR (TG_OP = 'UPDATE' AND OLD.collection_status != 'Completed')) THEN
        
        -- If quantity was collected, update vehicle current_load with capacity enforcement
        IF NEW.collected_quantity > 0 THEN
            SELECT vehicle_id, capacity, current_load, vehicle_number
            INTO v_veh
            FROM collection_vehicles
            WHERE vehicle_id = NEW.vehicle_id;

            IF FOUND THEN
                IF (v_veh.current_load + NEW.collected_quantity) > v_veh.capacity THEN
                    RAISE EXCEPTION 'Collection quantity exceeds vehicle capacity: Vehicle % has remaining capacity %, attempted %',
                        v_veh.vehicle_number, (v_veh.capacity - v_veh.current_load), NEW.collected_quantity;
                END IF;

                UPDATE collection_vehicles
                SET current_load = current_load + NEW.collected_quantity
                WHERE vehicle_id = NEW.vehicle_id;
            END IF;
        END IF;

        -- Reduce waste in the corresponding bin by collected_quantity (partial or full)
        UPDATE waste_bins
        SET current_level = GREATEST(0.00, current_level - NEW.collected_quantity),
            last_collected = CURRENT_TIMESTAMP
        WHERE bin_id = NEW.bin_id;

    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_update_bin_after_collection ON collection_records;

CREATE TRIGGER trg_update_bin_after_collection
AFTER INSERT OR UPDATE OF collection_status ON collection_records
FOR EACH ROW
EXECUTE FUNCTION func_update_bin_after_collection();

-- --------------------------------------------------------------------
-- TRIGGER 2: Revert Vehicle Load on Collection Deletion
-- Business logic: When a completed collection record is deleted,
-- decrement the assigned vehicle's current_load so fleet loads remain accurate.
-- --------------------------------------------------------------------

CREATE OR REPLACE FUNCTION func_revert_collection_load()
RETURNS TRIGGER AS $$
BEGIN
    IF OLD.collection_status = 'Completed' AND OLD.collected_quantity > 0 THEN
        UPDATE collection_vehicles
        SET current_load = GREATEST(0.00, current_load - OLD.collected_quantity)
        WHERE vehicle_id = OLD.vehicle_id;
    END IF;
    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_revert_collection_load ON collection_records;

CREATE TRIGGER trg_revert_collection_load
AFTER DELETE ON collection_records
FOR EACH ROW
EXECUTE FUNCTION func_revert_collection_load();

-- --------------------------------------------------------------------
-- TRIGGER 3: Automated Waste Bin Status Threshold Sync
-- Business logic: When a bin's current_level is updated, dynamically flag
-- status as 'Full' (100%), 'Overflow Risk' (>= 80%), or 'Normal' (< 80%)
-- unless the bin is explicitly marked 'Under Maintenance'.
-- --------------------------------------------------------------------

CREATE OR REPLACE FUNCTION func_sync_bin_status()
RETURNS TRIGGER AS $$
BEGIN
    -- Do not override status if bin is marked Under Maintenance
    IF NEW.status = 'Under Maintenance' THEN
        RETURN NEW;
    END IF;

    IF NEW.capacity > 0 THEN
        IF NEW.current_level >= NEW.capacity THEN
            NEW.status := 'Full';
        ELSIF (NEW.current_level / NEW.capacity) >= 0.80 THEN
            NEW.status := 'Overflow Risk';
        ELSE
            NEW.status := 'Normal';
        END IF;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_sync_bin_status ON waste_bins;

CREATE TRIGGER trg_sync_bin_status
BEFORE INSERT OR UPDATE OF current_level, capacity ON waste_bins
FOR EACH ROW
EXECUTE FUNCTION func_sync_bin_status();
