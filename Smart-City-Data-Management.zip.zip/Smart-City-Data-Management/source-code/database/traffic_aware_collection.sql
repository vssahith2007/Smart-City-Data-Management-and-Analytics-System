-- ====================================================================
-- SMART CITY DATA MANAGEMENT AND ANALYTICS SYSTEM
-- TRAFFIC-AWARE WASTE COLLECTION RECOMMENDATION VIEW & DECISION-SUPPORT DDL
-- ====================================================================

DROP VIEW IF EXISTS traffic_aware_collection_recommendation;

CREATE OR REPLACE VIEW traffic_aware_collection_recommendation AS
WITH latest_traffic AS (
    SELECT DISTINCT ON (area_id)
        area_id,
        vehicle_count,
        congestion_level,
        recorded_date,
        recorded_time
    FROM traffic_records
    ORDER BY area_id, recorded_date DESC, recorded_time DESC, traffic_id DESC
),
latest_collection AS (
    SELECT DISTINCT ON (bin_id)
        bin_id,
        collection_id,
        collection_status,
        collection_date,
        failure_reason,
        driver_name
    FROM collection_records
    ORDER BY bin_id, collection_date DESC, collection_id DESC
),
scored_bins AS (
    SELECT 
        wb.bin_id,
        wb.area_id,
        a.area_name,
        a.zone,
        wb.bin_location,
        wb.capacity,
        wb.current_level,
        ROUND((wb.current_level / NULLIF(wb.capacity, 0)) * 100, 1) AS fill_percentage,
        wb.status AS bin_status,
        wb.last_collected,
        COALESCE(lt.congestion_level, 'Medium') AS traffic_congestion,
        COALESCE(lt.vehicle_count, 0) AS vehicle_count,
        lt.recorded_time AS traffic_recorded_time,
        COALESCE(lc.collection_status, 'Completed') AS last_collection_status,
        lc.failure_reason AS last_failure_reason,
        lc.driver_name AS last_driver_name,
        -- Waste Collection Priority Score (0 to 100)
        GREATEST(0, LEAST(100, ROUND(
            -- Waste Urgency (0 to 50)
            ((wb.current_level / NULLIF(wb.capacity, 0)) * 40.0) +
            (CASE WHEN wb.status IN ('Full', 'Overflow Risk') OR (wb.current_level / NULLIF(wb.capacity, 0)) >= 0.80 THEN 5 ELSE 0 END) +
            (CASE WHEN wb.last_collected IS NULL OR (CURRENT_TIMESTAMP - wb.last_collected) > INTERVAL '2 days' THEN 5 ELSE 0 END) +
            -- Traffic Condition (0 to 30)
            (CASE COALESCE(lt.congestion_level, 'Medium')
                WHEN 'Critical' THEN 30
                WHEN 'High' THEN 22
                WHEN 'Medium' THEN 14
                WHEN 'Low' THEN 6
                ELSE 14 END) +
            -- Collection Condition (0 to 20)
            (CASE COALESCE(lc.collection_status, 'Completed')
                WHEN 'Failed' THEN 20
                WHEN 'Pending' THEN 14
                WHEN 'Scheduled' THEN 8
                ELSE 2 END)
        ))) AS priority_score,
        -- Traffic Clearance Weight for Sequence Dispatchability
        CASE COALESCE(lt.congestion_level, 'Medium')
            WHEN 'Low' THEN 20
            WHEN 'Medium' THEN 10
            WHEN 'High' THEN -5
            WHEN 'Critical' THEN -15
            ELSE 0
        END AS traffic_clearance_bonus
    FROM waste_bins wb
    JOIN areas a ON wb.area_id = a.area_id
    LEFT JOIN latest_traffic lt ON wb.area_id = lt.area_id
    LEFT JOIN latest_collection lc ON wb.bin_id = lc.bin_id
)
SELECT 
    sb.bin_id,
    sb.area_id,
    sb.area_name,
    sb.zone,
    sb.bin_location,
    sb.capacity,
    sb.current_level,
    sb.fill_percentage,
    sb.bin_status,
    sb.last_collected,
    sb.traffic_congestion,
    sb.vehicle_count,
    sb.traffic_recorded_time,
    sb.last_collection_status,
    sb.last_failure_reason,
    sb.last_driver_name,
    sb.priority_score,
    
    -- Priority Classification
    CASE 
        WHEN sb.priority_score >= 90 THEN 'Critical'
        WHEN sb.priority_score >= 70 THEN 'High'
        WHEN sb.priority_score >= 40 THEN 'Medium'
        ELSE 'Low'
    END AS priority_level,

    -- Recommended Action
    CASE 
        WHEN sb.last_collection_status = 'Failed' THEN 
            'Priority Re-attempt (Previously Failed Trip)'
        WHEN sb.fill_percentage >= 85 AND sb.traffic_congestion = 'Low' THEN 
            'Collect Immediately (Optimal Traffic Window)'
        WHEN sb.fill_percentage >= 85 AND sb.traffic_congestion = 'Medium' THEN 
            'Collect Soon (Active Route)'
        WHEN sb.fill_percentage >= 85 AND sb.traffic_congestion IN ('High', 'Critical') THEN 
            'Critical Urgency - Schedule Off-Peak Window'
        WHEN sb.fill_percentage >= 70 AND sb.traffic_congestion = 'Low' THEN 
            'Collect Soon (Favorable Conditions)'
        WHEN sb.fill_percentage >= 70 AND sb.traffic_congestion = 'Medium' THEN 
            'Standard Scheduled Route'
        WHEN sb.fill_percentage >= 70 AND sb.traffic_congestion IN ('High', 'Critical') THEN 
            'Delay Collection / Await Traffic Clearance'
        WHEN sb.fill_percentage < 70 AND sb.traffic_congestion IN ('High', 'Critical') THEN 
            'Defer Route / Monitor Fill Level'
        ELSE 
            'Routine Monitoring / Safe Capacity'
    END AS recommended_action,

    -- Recommendation Reason
    CASE 
        WHEN sb.last_collection_status = 'Failed' THEN 
            'Previous collection attempt failed (' || COALESCE(sb.last_failure_reason, 'driver reported obstacle') || '). Immediate supervisory dispatch recommended.'
        WHEN sb.fill_percentage >= 85 AND sb.traffic_congestion = 'Low' THEN 
            'Critical waste accumulation combined with free-flowing traffic. Immediate dispatch yields zero travel delay.'
        WHEN sb.fill_percentage >= 85 AND sb.traffic_congestion = 'Medium' THEN 
            'High container capacity with moderate transit flow. Suitable for immediate regular routing.'
        WHEN sb.fill_percentage >= 85 AND sb.traffic_congestion IN ('High', 'Critical') THEN 
            'Severe waste overflow hazard, but heavy corridor congestion will stall heavy collection vehicles. Dispatch during early morning/evening off-peak window.'
        WHEN sb.fill_percentage >= 70 AND sb.traffic_congestion = 'Low' THEN 
            'Substantial waste volume with clear roadways. Emptying now prevents overflow during upcoming peak periods.'
        WHEN sb.fill_percentage >= 70 AND sb.traffic_congestion = 'Medium' THEN 
            'Moderate fill with steady traffic movement. Assigned to standard municipal collection cycle.'
        WHEN sb.fill_percentage >= 70 AND sb.traffic_congestion IN ('High', 'Critical') THEN 
            'Notable waste accumulation; however, heavy congestion creates gridlock risk. Defer truck entry until intersection clears.'
        WHEN sb.fill_percentage < 70 AND sb.traffic_congestion IN ('High', 'Critical') THEN 
            'Container is below critical threshold. Avoid routing heavy trucks into active traffic bottlenecks.'
        ELSE 
            'Container is within safe operating capacity with low-to-medium traffic. Continue standard monitoring.'
    END AS recommendation_reason,

    -- Preferred Collection Sequence Order
    ROW_NUMBER() OVER (
        ORDER BY 
            (sb.priority_score + sb.traffic_clearance_bonus) DESC, 
            sb.priority_score DESC, 
            sb.bin_id ASC
    ) AS recommended_sequence,

    -- Vehicle Assignment (Matching Best Available Vehicle)
    rec_veh.vehicle_id,
    rec_veh.vehicle_number,
    rec_veh.vehicle_type,
    rec_veh.capacity AS vehicle_capacity

FROM scored_bins sb
LEFT JOIN LATERAL (
    SELECT cv.vehicle_id, cv.vehicle_number, cv.vehicle_type, cv.capacity
    FROM collection_vehicles cv
    WHERE cv.status = 'Available'
      AND cv.capacity >= sb.current_level
    ORDER BY 
        CASE 
            WHEN sb.current_level >= 1500 THEN 
                CASE cv.vehicle_type WHEN 'Compactor Truck' THEN 1 WHEN 'Tipper Truck' THEN 2 ELSE 3 END
            WHEN sb.current_level >= 1000 THEN 
                CASE cv.vehicle_type WHEN 'Tipper Truck' THEN 1 WHEN 'Compactor Truck' THEN 2 ELSE 3 END
            ELSE 
                CASE cv.vehicle_type WHEN 'Mini Truck' THEN 1 WHEN 'Tipper Truck' THEN 2 ELSE 3 END
        END ASC,
        cv.capacity ASC
    LIMIT 1
) rec_veh ON true;
