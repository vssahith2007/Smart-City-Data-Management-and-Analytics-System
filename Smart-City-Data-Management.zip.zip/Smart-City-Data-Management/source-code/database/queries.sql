-- ====================================================================
-- Smart City Data Management and Analytics System
-- PostgreSQL Analytical Queries (queries.sql)
-- Demonstrating JOINs, GROUP BY, HAVING, Subqueries, Aggregate Functions,
-- ORDER BY, Views, and Multi-Domain Analytics.
-- ====================================================================

-- --------------------------------------------------------------------
-- QUERY 1: Highest Traffic Area by Total and Average Vehicle Volume
-- Identifies top areas experiencing maximum cumulative traffic.
-- --------------------------------------------------------------------
SELECT 
    a.area_id,
    a.area_name,
    a.zone,
    COUNT(tr.traffic_id) AS total_recordings,
    SUM(tr.vehicle_count) AS total_vehicles,
    ROUND(AVG(tr.vehicle_count), 2) AS avg_vehicle_volume,
    MAX(tr.vehicle_count) AS peak_single_recording
FROM areas a
JOIN traffic_records tr ON a.area_id = tr.area_id
GROUP BY a.area_id, a.area_name, a.zone
ORDER BY total_vehicles DESC;

-- --------------------------------------------------------------------
-- QUERY 2: Average Traffic Volume by Area and Zone
-- Compares average vehicle throughput across different city zones.
-- --------------------------------------------------------------------
SELECT 
    a.zone,
    a.area_name,
    COUNT(DISTINCT ts.signal_id) AS monitored_signals,
    COALESCE(ROUND(AVG(tr.vehicle_count), 2), 0) AS avg_vehicles_per_slot,
    COALESCE(MIN(tr.vehicle_count), 0) AS min_volume,
    COALESCE(MAX(tr.vehicle_count), 0) AS max_volume
FROM areas a
LEFT JOIN traffic_signals ts ON a.area_id = ts.area_id
LEFT JOIN traffic_records tr ON a.area_id = tr.area_id
GROUP BY a.zone, a.area_name
ORDER BY a.zone, avg_vehicles_per_slot DESC;

-- --------------------------------------------------------------------
-- QUERY 3: Peak Traffic Time & Hourly Distribution
-- Determines peak traffic hours by extracting hour part from timestamp.
-- --------------------------------------------------------------------
SELECT 
    EXTRACT(HOUR FROM tr.recorded_time) AS hour_of_day,
    CASE 
        WHEN EXTRACT(HOUR FROM tr.recorded_time) BETWEEN 6 AND 11 THEN 'Morning Rush (06:00 - 11:59)'
        WHEN EXTRACT(HOUR FROM tr.recorded_time) BETWEEN 12 AND 16 THEN 'Afternoon Window (12:00 - 16:59)'
        WHEN EXTRACT(HOUR FROM tr.recorded_time) BETWEEN 17 AND 21 THEN 'Evening Peak (17:00 - 21:59)'
        ELSE 'Night Off-Peak (22:00 - 05:59)'
    END AS time_window,
    COUNT(tr.traffic_id) AS record_count,
    SUM(tr.vehicle_count) AS cumulative_vehicles,
    ROUND(AVG(tr.vehicle_count), 2) AS avg_hourly_vehicles,
    COUNT(CASE WHEN tr.congestion_level = 'Critical' THEN 1 END) AS critical_events
FROM traffic_records tr
GROUP BY EXTRACT(HOUR FROM tr.recorded_time), time_window
ORDER BY cumulative_vehicles DESC;

-- --------------------------------------------------------------------
-- QUERY 4: City-Wide Congestion Level Distribution
-- Summarizes proportions of Low, Medium, High, and Critical recordings.
-- --------------------------------------------------------------------
SELECT 
    tr.congestion_level,
    COUNT(tr.traffic_id) AS total_occurrences,
    ROUND((COUNT(tr.traffic_id)::NUMERIC / (SELECT COUNT(*) FROM traffic_records)) * 100, 2) AS percentage_share,
    SUM(tr.vehicle_count) AS total_vehicles_in_level,
    ROUND(AVG(tr.vehicle_count), 2) AS avg_vehicles_in_level
FROM traffic_records tr
GROUP BY tr.congestion_level
ORDER BY 
    CASE tr.congestion_level
        WHEN 'Critical' THEN 1
        WHEN 'High' THEN 2
        WHEN 'Medium' THEN 3
        WHEN 'Low' THEN 4
    END;

-- --------------------------------------------------------------------
-- QUERY 5: Areas with Highest Waste Accumulation and Capacity Pressure
-- Calculates fill percentage and total current waste per area.
-- --------------------------------------------------------------------
SELECT 
    a.area_id,
    a.area_name,
    a.zone,
    COUNT(wb.bin_id) AS total_bins,
    SUM(wb.capacity) AS total_capacity_liters,
    SUM(wb.current_level) AS current_waste_liters,
    ROUND((SUM(wb.current_level) / NULLIF(SUM(wb.capacity), 0)) * 100, 2) AS overall_fill_percentage,
    COUNT(CASE WHEN wb.current_level / wb.capacity >= 0.80 THEN 1 END) AS urgent_bins
FROM areas a
JOIN waste_bins wb ON a.area_id = wb.area_id
GROUP BY a.area_id, a.area_name, a.zone
HAVING SUM(wb.current_level) > 0
ORDER BY overall_fill_percentage DESC;

-- --------------------------------------------------------------------
-- QUERY 6: Bins at Overflow Risk Requiring Immediate Dispatch
-- Identifies individual bins with current fill level >= 80% of capacity.
-- --------------------------------------------------------------------
SELECT 
    wb.bin_id,
    a.area_name,
    wb.bin_location,
    wb.capacity,
    wb.current_level,
    ROUND((wb.current_level / wb.capacity) * 100, 2) AS fill_percentage,
    wb.status,
    wb.last_collected,
    AGE(CURRENT_TIMESTAMP, wb.last_collected) AS time_since_last_collection
FROM waste_bins wb
JOIN areas a ON wb.area_id = a.area_id
WHERE (wb.current_level / wb.capacity) >= 0.80 OR wb.status IN ('Full', 'Overflow Risk')
ORDER BY fill_percentage DESC;

-- --------------------------------------------------------------------
-- QUERY 7: Municipal Fleet Collection Efficiency Rate
-- Analyzes collection operations and completion rate per vehicle & area.
-- --------------------------------------------------------------------
SELECT 
    cv.vehicle_number,
    cv.vehicle_type,
    cv.status AS vehicle_status,
    COUNT(cr.collection_id) AS total_assigned_trips,
    COUNT(CASE WHEN cr.collection_status = 'Completed' THEN 1 END) AS completed_trips,
    COUNT(CASE WHEN cr.collection_status IN ('Pending', 'Failed') THEN 1 END) AS missed_or_pending_trips,
    COALESCE(SUM(CASE WHEN cr.collection_status = 'Completed' THEN cr.collected_quantity ELSE 0 END), 0) AS total_quantity_collected,
    ROUND((COUNT(CASE WHEN cr.collection_status = 'Completed' THEN 1 END)::NUMERIC / NULLIF(COUNT(cr.collection_id), 0)) * 100, 2) AS vehicle_efficiency_rate
FROM collection_vehicles cv
LEFT JOIN collection_records cr ON cv.vehicle_id = cr.vehicle_id
GROUP BY cv.vehicle_id, cv.vehicle_number, cv.vehicle_type, cv.status
ORDER BY total_quantity_collected DESC;

-- --------------------------------------------------------------------
-- QUERY 8: Pending, Failed, and Scheduled Waste Collection Operations
-- Highlights missed collections that require immediate fleet re-routing.
-- --------------------------------------------------------------------
SELECT 
    cr.collection_id,
    a.area_name,
    wb.bin_location,
    wb.current_level,
    wb.capacity,
    cv.vehicle_number,
    cr.collection_date,
    cr.collection_status
FROM collection_records cr
JOIN waste_bins wb ON cr.bin_id = wb.bin_id
JOIN areas a ON wb.area_id = a.area_id
LEFT JOIN collection_vehicles cv ON cr.vehicle_id = cv.vehicle_id
WHERE cr.collection_status IN ('Pending', 'Failed', 'Scheduled')
ORDER BY cr.collection_date DESC, wb.current_level DESC;

-- --------------------------------------------------------------------
-- QUERY 9: Area Efficiency Score Calculation (Cross-Domain View Query)
-- Transparent mathematical score evaluating traffic and waste synergy.
-- --------------------------------------------------------------------
SELECT 
    area_id,
    area_name,
    zone,
    population,
    total_vehicles,
    avg_vehicle_count,
    heavy_congestion_count,
    traffic_score,
    total_bins,
    avg_fill_percentage,
    overflow_risk_bins,
    collection_efficiency,
    waste_score,
    overall_score,
    efficiency_category
FROM area_efficiency_view
ORDER BY overall_score ASC;

-- --------------------------------------------------------------------
-- QUERY 10: Priority Area Identification (Multi-Criteria Decision Support)
-- Classifies areas needing administrative intervention based on traffic
-- bottlenecks, waste overflow, uncollected bins, or low overall scores.
-- --------------------------------------------------------------------
SELECT 
    e.area_id,
    e.area_name,
    e.zone,
    e.overall_score,
    e.efficiency_category,
    CASE 
        WHEN e.heavy_congestion_count >= 3 AND e.overflow_risk_bins >= 2 THEN 'Critical Traffic Bottlenecks + High Waste Overflow'
        WHEN e.heavy_congestion_count >= 3 THEN 'Severe Traffic Congestion'
        WHEN e.overflow_risk_bins >= 2 THEN 'Multiple Waste Bins at Overflow Risk'
        WHEN e.pending_collections > 0 THEN 'Delayed / Failed Municipal Waste Collections'
        WHEN e.overall_score < 50 THEN 'Low Cross-Domain Efficiency Score'
        ELSE 'Normal Urban Operations'
    END AS primary_concern,
    CASE 
        WHEN e.overall_score < 40 OR (e.heavy_congestion_count >= 3 AND e.overflow_risk_bins >= 2) THEN 'High Priority'
        WHEN e.overall_score < 60 OR e.overflow_risk_bins >= 1 OR e.heavy_congestion_count >= 2 THEN 'Moderate Priority'
        ELSE 'Low Priority'
    END AS priority_level
FROM area_efficiency_view e
ORDER BY 
    CASE 
        WHEN e.overall_score < 40 OR (e.heavy_congestion_count >= 3 AND e.overflow_risk_bins >= 2) THEN 1
        WHEN e.overall_score < 60 OR e.overflow_risk_bins >= 1 OR e.heavy_congestion_count >= 2 THEN 2
        ELSE 3
    END,
    e.overall_score ASC;

-- --------------------------------------------------------------------
-- QUERY 11: Traffic-Aware Waste Collection Priority & Vehicle Assignment
-- Combines waste fill urgency, corridor traffic congestion, and fleet availability.
-- --------------------------------------------------------------------
SELECT 
    recommended_sequence AS seq_order,
    bin_id,
    area_name,
    bin_location,
    fill_percentage,
    traffic_congestion,
    last_collection_status,
    priority_score,
    priority_level,
    vehicle_number AS recommended_vehicle,
    vehicle_type,
    recommended_action,
    recommendation_reason
FROM traffic_aware_collection_recommendation
ORDER BY recommended_sequence ASC;

-- --------------------------------------------------------------------
-- QUERY 12: Smart Waste Collection Scheduling by Time & Traffic History
-- Evaluates current fill %, priority, area traffic, and historical lower-traffic periods
-- to recommend the optimal collection time window.
-- --------------------------------------------------------------------
SELECT 
    bin_code,
    area_name,
    fill_percentage || '%' AS fill_level,
    traffic_congestion AS current_traffic,
    priority_level AS priority,
    recommended_time,
    recommendation_reason
FROM smart_collection_schedule_view
ORDER BY recommended_sequence ASC, bin_id ASC;


