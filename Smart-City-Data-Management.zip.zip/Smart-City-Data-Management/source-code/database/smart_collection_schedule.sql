-- ====================================================================
-- Smart City Data Management and Analytics System
-- Feature: SMART WASTE COLLECTION SCHEDULING (smart_collection_schedule.sql)
-- Recommends suitable collection time considering:
--   1. Current waste / fill level
--   2. Waste priority
--   3. Traffic condition of the area
--   4. Existing traffic history by time (lower-traffic period)
-- ====================================================================

CREATE OR REPLACE VIEW smart_collection_schedule_view AS
WITH area_lower_traffic AS (
    -- Identify the lowest congestion time recorded for each area from historical records
    SELECT DISTINCT ON (tr.area_id)
        tr.area_id,
        tr.recorded_time,
        tr.congestion_level,
        tr.vehicle_count
    FROM traffic_records tr
    ORDER BY tr.area_id,
        CASE tr.congestion_level
            WHEN 'Low' THEN 1
            WHEN 'Medium' THEN 2
            WHEN 'High' THEN 3
            WHEN 'Critical' THEN 4
            ELSE 5
        END ASC,
        tr.vehicle_count ASC
)
SELECT 
    r.bin_id,
    'B' || r.bin_id AS bin_code,
    r.bin_location,
    r.area_id,
    r.area_name,
    r.zone,
    r.capacity,
    r.current_level,
    r.fill_percentage,
    r.bin_status,
    r.traffic_congestion,
    r.vehicle_count AS traffic_vehicle_count,
    r.traffic_recorded_time,
    r.priority_score,
    r.priority_level,
    TO_CHAR(alt.recorded_time, 'FMHH12:MI AM') AS lower_traffic_time,
    alt.congestion_level AS lower_traffic_congestion,
    alt.vehicle_count AS lower_traffic_vehicle_count,
    
    -- ================================================================
    -- SIMPLE SCHEDULING LOGIC:
    -- 1. High waste + low traffic      -> "Collect Now"
    -- 2. High waste + high traffic     -> Next lower-traffic period
    -- 3. Medium waste                  -> "Schedule Soon"
    -- 4. Low waste                     -> "Regular Collection"
    -- ================================================================
    CASE
        -- Rule 1: High waste level AND Low traffic -> "Collect Now"
        WHEN (r.fill_percentage >= 70.0 OR r.bin_status IN ('Full', 'Overflow Risk')) 
             AND r.traffic_congestion = 'Low'
            THEN 'Collect Now'

        -- Rule 2: High waste level AND High traffic -> Next lower-traffic period
        WHEN (r.fill_percentage >= 70.0 OR r.bin_status IN ('Full', 'Overflow Risk')) 
             AND r.traffic_congestion IN ('High', 'Critical')
            THEN COALESCE(TO_CHAR(alt.recorded_time, 'FMHH12:MI AM'), 'Off-Peak Window')

        -- High waste AND Medium traffic -> Favorable window to collect now
        WHEN (r.fill_percentage >= 70.0 OR r.bin_status IN ('Full', 'Overflow Risk')) 
             AND r.traffic_congestion = 'Medium'
            THEN 'Collect Now'

        -- Rule 3: Medium waste level -> "Schedule Soon"
        WHEN r.fill_percentage >= 40.0
            THEN 'Schedule Soon'

        -- Rule 4: Low waste level -> "Regular Collection"
        ELSE 'Regular Collection'
    END AS recommended_time,
    
    -- EXPLAINABLE REASON
    CASE
        -- Rule 1 Reason
        WHEN (r.fill_percentage >= 70.0 OR r.bin_status IN ('Full', 'Overflow Risk')) 
             AND r.traffic_congestion IN ('Low', 'Medium')
            THEN 'High waste level with low current traffic. Immediate collection is recommended.'

        -- Rule 2 Reason (Matches specification)
        WHEN (r.fill_percentage >= 70.0 OR r.bin_status IN ('Full', 'Overflow Risk')) 
             AND r.traffic_congestion IN ('High', 'Critical')
            THEN 'High waste level with high current traffic. Collection is recommended during the next lower-traffic period.'

        -- Rule 3 Reason
        WHEN r.fill_percentage >= 40.0
            THEN 'Medium waste level with manageable traffic. Scheduled collection recommended soon.'

        -- Rule 4 Reason
        ELSE 'Low waste level with ample remaining capacity. Recommended for regular collection.'
    END AS recommendation_reason,

    r.recommended_sequence
FROM traffic_aware_collection_recommendation r
LEFT JOIN area_lower_traffic alt ON r.area_id = alt.area_id
ORDER BY r.priority_score DESC, r.bin_id ASC;
