-- ====================================================================
-- Smart City Data Management and Analytics System
-- PostgreSQL Sample Dataset (data.sql)
-- 10 Areas, 12 Signals, 50+ Traffic Records, 14 Incidents, 25 Bins, 6 Vehicles, 40 Collections
-- ====================================================================

-- --------------------------------------------------------------------
-- 1. USERS (Admin & Operator with hashed passwords)
-- admin / admin123  &  operator / operator123
-- --------------------------------------------------------------------
INSERT INTO users (name, username, password_hash, role) VALUES
('System Administrator', 'admin', 'scrypt:32768:8:1$DXPBx2TIFwNHU7Yd$51d18358dd107e008aa2e12d845051354e58fee6560e5bd527819d9f8bfab9dc3f50faef896a5505ffd6c4a76e946af3c95dcdb0afa78479744209a6f144ba79', 'Admin'),
('Municipal Operator', 'operator', 'scrypt:32768:8:1$4bWC3OKKWssCJ8Zw$5614b1353b1009a0d34221d01b9cc35524aa39d237ad7a52855ab491411c0723e4a78989aea1d56de6e4d412b5d10b762fd450ee1095d0e0f50c89db97ac7e78', 'Operator');

-- --------------------------------------------------------------------
-- 2. AREAS (10 Distinct City Zones with Population & Profiles)
-- --------------------------------------------------------------------
INSERT INTO areas (area_name, zone, population, description) VALUES
('Central Zone', 'Zone-1 (Central)', 145000, 'Commercial and civic administrative core with heavy daily transit and civic offices.'),
('Market Area', 'Zone-1 (Central)', 112000, 'Dense retail market, street vending corridors, and pedestrian congestion hubs.'),
('University Road', 'Zone-2 (North)', 85000, 'Educational institutions, student hostels, and peak hourly commuter movements.'),
('Bus Stand', 'Zone-1 (Central)', 98000, 'Major intercity bus terminal with continuous commercial traffic and high litter load.'),
('Industrial Area', 'Zone-3 (East)', 64000, 'Heavy manufacturing plants, freight transport movement, and industrial waste yards.'),
('Residential Zone', 'Zone-4 (South)', 130000, 'Suburban residential housing societies, local schools, and community parks.'),
('Railway Area', 'Zone-1 (Central)', 105000, 'Railway junction surroundings, transit hub, hotels, and round-the-clock traffic.'),
('Main Road', 'Zone-2 (North)', 120000, 'Primary arterial transit corridor connecting northern suburbs to the city center.'),
('Green Park', 'Zone-4 (South)', 72000, 'Eco-sensitive residential sector with parks, walking tracks, and organized collection.'),
('Old Town', 'Zone-5 (West)', 95000, 'Heritage old city with narrow lanes, high population density, and legacy waste points.');

-- --------------------------------------------------------------------
-- 3. TRAFFIC SIGNALS (12 Key Junction Signals across the 10 Areas)
-- --------------------------------------------------------------------
INSERT INTO traffic_signals (area_id, signal_name, location, status) VALUES
(1, 'Central Square Junction Signal', 'Intersection of Mahatma Gandhi Marg and Vikas Path', 'Active'),
(1, 'Civic Center Signal', 'Near Municipal Corporation Gate', 'Active'),
(2, 'Market Main Crossing Signal', 'Crossroad near Main Bazaar & Cloth Market', 'Active'),
(3, 'University North Gate Signal', 'University Main Gate / College Road', 'Active'),
(4, 'Bus Terminal Exit Signal', 'Bus Stand Outgate Road / NH Link', 'Active'),
(5, 'Industrial Bypass Signal', 'Industrial Sector Phase-1 Crossing', 'Maintenance'),
(6, 'Residential Sector 4 Crossing', 'Sector 4 & 5 Link Road', 'Active'),
(7, 'Station Circle Signal', 'Railway Station Roundabout', 'Active'),
(8, 'Main Road Expressway Flyover Signal', 'Flyover Incline at Link Way', 'Active'),
(8, 'Main Road Sector-2 Cross', 'Sector-2 Signal Junction', 'Active'),
(9, 'Green Park West Signal', 'Park Avenue and Lake Road Corner', 'Active'),
(10, 'Heritage Gate Signal', 'Old Town Fort Gate Crossing', 'Inactive');

-- --------------------------------------------------------------------
-- 4. TRAFFIC RECORDS (50+ Representative Records across Days and Hours)
-- --------------------------------------------------------------------
INSERT INTO traffic_records (area_id, signal_id, vehicle_count, congestion_level, recorded_date, recorded_time) VALUES
-- Central Zone (High to Medium)
(1, 1, 1420, 'High', '2026-08-15', '09:00:00'),
(1, 1, 1680, 'Critical', '2026-08-15', '18:30:00'),
(1, 2, 890, 'Medium', '2026-08-16', '11:15:00'),
(1, 1, 1510, 'High', '2026-08-17', '09:30:00'),
(1, 2, 720, 'Medium', '2026-08-18', '14:00:00'),
(1, 1, 1750, 'Critical', '2026-08-19', '19:00:00'),

-- Market Area (Very High / Critical)
(2, 3, 1850, 'Critical', '2026-08-15', '11:00:00'),
(2, 3, 2100, 'Critical', '2026-08-15', '19:30:00'),
(2, 3, 1640, 'High', '2026-08-16', '12:00:00'),
(2, 3, 1920, 'Critical', '2026-08-17', '18:45:00'),
(2, 3, 1580, 'High', '2026-08-18', '16:15:00'),
(2, 3, 2250, 'Critical', '2026-08-19', '20:00:00'),

-- University Road (Peak morning/afternoon, otherwise moderate)
(3, 4, 1150, 'Medium', '2026-08-15', '08:30:00'),
(3, 4, 1340, 'High', '2026-08-15', '16:45:00'),
(3, 4, 620, 'Low', '2026-08-16', '12:30:00'),
(3, 4, 1280, 'High', '2026-08-17', '09:00:00'),
(3, 4, 540, 'Low', '2026-08-18', '21:00:00'),
(3, 4, 1190, 'Medium', '2026-08-19', '17:15:00'),

-- Bus Stand (Consistently High)
(4, 5, 1620, 'High', '2026-08-15', '07:30:00'),
(4, 5, 1780, 'Critical', '2026-08-15', '17:00:00'),
(4, 5, 1450, 'High', '2026-08-16', '10:00:00'),
(4, 5, 1820, 'Critical', '2026-08-17', '19:15:00'),
(4, 5, 1390, 'High', '2026-08-18', '13:00:00'),
(4, 5, 1690, 'Critical', '2026-08-19', '18:00:00'),

-- Industrial Area (Heavy trucks, moderate volume)
(5, 6, 850, 'Medium', '2026-08-15', '08:00:00'),
(5, 6, 940, 'Medium', '2026-08-16', '14:30:00'),
(5, 6, 1120, 'High', '2026-08-17', '17:30:00'),
(5, 6, 420, 'Low', '2026-08-18', '22:00:00'),
(5, 6, 880, 'Medium', '2026-08-19', '11:00:00'),

-- Residential Zone (Low to Moderate)
(6, 7, 510, 'Low', '2026-08-15', '08:00:00'),
(6, 7, 430, 'Low', '2026-08-16', '13:00:00'),
(6, 7, 680, 'Medium', '2026-08-17', '18:30:00'),
(6, 7, 390, 'Low', '2026-08-18', '11:00:00'),
(6, 7, 640, 'Medium', '2026-08-19', '19:00:00'),

-- Railway Area (High traffic day and night)
(7, 8, 1550, 'High', '2026-08-15', '06:00:00'),
(7, 8, 1720, 'Critical', '2026-08-15', '21:30:00'),
(7, 8, 1480, 'High', '2026-08-16', '15:00:00'),
(7, 8, 1690, 'Critical', '2026-08-17', '20:15:00'),
(7, 8, 1310, 'Medium', '2026-08-18', '11:30:00'),
(7, 8, 1810, 'Critical', '2026-08-19', '22:00:00'),

-- Main Road (Fast transit, peak congestion)
(8, 9, 1650, 'High', '2026-08-15', '09:00:00'),
(8, 10, 1420, 'High', '2026-08-15', '18:00:00'),
(8, 9, 980, 'Medium', '2026-08-16', '12:00:00'),
(8, 10, 1790, 'Critical', '2026-08-17', '18:30:00'),
(8, 9, 1350, 'Medium', '2026-08-18', '09:30:00'),
(8, 10, 1520, 'High', '2026-08-19', '17:45:00'),

-- Green Park (Very Low Congestion)
(9, 11, 280, 'Low', '2026-08-15', '07:00:00'),
(9, 11, 340, 'Low', '2026-08-16', '17:00:00'),
(9, 11, 410, 'Low', '2026-08-17', '08:30:00'),
(9, 11, 310, 'Low', '2026-08-18', '18:00:00'),
(9, 11, 460, 'Low', '2026-08-19', '19:30:00'),

-- Old Town (Moderate to High due to narrow bottleneck streets)
(10, 12, 920, 'Medium', '2026-08-15', '10:30:00'),
(10, 12, 1380, 'High', '2026-08-16', '17:15:00'),
(10, 12, 1460, 'High', '2026-08-17', '19:00:00'),
(10, 12, 870, 'Medium', '2026-08-18', '12:00:00'),
(10, 12, 1540, 'Critical', '2026-08-19', '20:30:00');

-- --------------------------------------------------------------------
-- 5. TRAFFIC INCIDENTS (14 Incident Logs)
-- --------------------------------------------------------------------
INSERT INTO traffic_incidents (area_id, incident_type, severity, description, incident_date, status) VALUES
(1, 'Accident', 'Moderate', 'Minor two-wheeler collision at Central Square, traffic diverted to Vikas Path.', '2026-08-15', 'Resolved'),
(1, 'Signal Failure', 'Major', 'Power outage caused Central Square signal blackout for 45 mins.', '2026-08-18', 'Resolved'),
(2, 'Other', 'Critical', 'Street vendor unauthorized encroachment blocking main commercial lane.', '2026-08-17', 'Investigating'),
(2, 'Vehicle Breakdown', 'Moderate', 'Delivery tempo broke down near Cloth Market junction causing 1 km queue.', '2026-08-19', 'Resolved'),
(3, 'Roadwork', 'Minor', 'Pothole repair work in front of North Gate causing single-lane operation.', '2026-08-16', 'Resolved'),
(4, 'Accident', 'Major', 'Intercity bus side-swiped stationary van near outgate NH link.', '2026-08-15', 'Resolved'),
(4, 'Vehicle Breakdown', 'Moderate', 'Tourist coach broken down at Bus Stand entry choke point.', '2026-08-19', 'Investigating'),
(5, 'Roadwork', 'Moderate', 'Culvert replacement near Phase-1 industrial bypass.', '2026-08-17', 'Reported'),
(6, 'Other', 'Minor', 'Tree branch fallen on Sector-4 service lane during morning storm.', '2026-08-16', 'Resolved'),
(7, 'Signal Failure', 'Major', 'Roundabout timer malfunction causing gridlock near platform exit.', '2026-08-17', 'Resolved'),
(7, 'Accident', 'Critical', 'Auto-rickshaw collision with tempo at Railway circle junction.', '2026-08-19', 'Investigating'),
(8, 'Roadwork', 'Major', 'Flyover expansion joint retrofitting restricting transit to single lane.', '2026-08-18', 'Reported'),
(9, 'Other', 'Minor', 'Speed breaker repainting and reflector installation.', '2026-08-15', 'Resolved'),
(10, 'Vehicle Breakdown', 'Major', 'Goods carrier stuck in narrow heritage archway lane, complete blockage.', '2026-08-19', 'Reported');

-- --------------------------------------------------------------------
-- 6. WASTE BINS (25 Bins with Locations, Capacity, Fill Levels & Status)
-- --------------------------------------------------------------------
INSERT INTO waste_bins (area_id, bin_location, capacity, current_level, status, last_collected) VALUES
-- Central Zone (3 bins)
(1, 'Central Square North Corner', 1000.00, 320.00, 'Normal', '2026-08-19 06:30:00'),
(1, 'Civic Center Public Gate', 1200.00, 480.00, 'Normal', '2026-08-19 07:00:00'),
(1, 'Gandhi Marg Transit Stop', 800.00, 680.00, 'Overflow Risk', '2026-08-18 16:00:00'),

-- Market Area (3 bins - heavily loaded)
(2, 'Cloth Market Central Lane', 1500.00, 1420.00, 'Overflow Risk', '2026-08-17 18:00:00'),
(2, 'Vegetable Mandi West Gate', 2000.00, 1950.00, 'Full', '2026-08-17 19:30:00'),
(2, 'Fish & Poultry Market Corner', 1200.00, 1150.00, 'Overflow Risk', '2026-08-18 08:00:00'),

-- University Road (2 bins)
(3, 'North Gate Canteen Area', 1000.00, 420.00, 'Normal', '2026-08-19 08:00:00'),
(3, 'Hostel Block 3 Entry', 1000.00, 310.00, 'Normal', '2026-08-19 08:30:00'),

-- Bus Stand (3 bins - high load)
(4, 'Bus Terminal Platform 1-4', 1500.00, 1380.00, 'Overflow Risk', '2026-08-18 10:00:00'),
(4, 'Intercity Ticket Booking Concourse', 1200.00, 1120.00, 'Overflow Risk', '2026-08-18 11:30:00'),
(4, 'Bus Workshop Exit Gate', 1500.00, 650.00, 'Normal', '2026-08-19 05:30:00'),

-- Industrial Area (3 bins)
(5, 'Phase-1 Main Boulevard', 2500.00, 950.00, 'Normal', '2026-08-18 14:00:00'),
(5, 'Chemical Complex Waste Corner', 2000.00, 1750.00, 'Overflow Risk', '2026-08-17 11:00:00'),
(5, 'Heavy Engineering Yard', 3000.00, 1200.00, 'Normal', '2026-08-18 15:30:00'),

-- Residential Zone (3 bins)
(6, 'Sector 4 Community Center', 1000.00, 280.00, 'Normal', '2026-08-19 09:00:00'),
(6, 'Sector 5 Primary School Corner', 800.00, 210.00, 'Normal', '2026-08-19 09:30:00'),
(6, 'Sector 6 Shopping Arcade', 1000.00, 390.00, 'Normal', '2026-08-19 10:00:00'),

-- Railway Area (3 bins)
(7, 'Station Main Porch Concourse', 1500.00, 1390.00, 'Overflow Risk', '2026-08-18 09:00:00'),
(7, 'Parcel Office Freight Lane', 2000.00, 1650.00, 'Overflow Risk', '2026-08-17 17:00:00'),
(7, 'Auto Stand & Parking Yard', 1000.00, 450.00, 'Normal', '2026-08-19 06:00:00'),

-- Main Road (2 bins)
(8, 'Sector-2 Flyover Underpass', 1200.00, 420.00, 'Normal', '2026-08-19 07:15:00'),
(8, 'Main Road Petrol Station Cross', 1000.00, 350.00, 'Normal', '2026-08-19 07:45:00'),

-- Green Park (2 bins)
(9, 'Lake Promenade East', 800.00, 120.00, 'Normal', '2026-08-19 06:15:00'),
(9, 'Botanical Garden Main Gate', 800.00, 160.00, 'Normal', '2026-08-19 06:45:00'),

-- Old Town (2 bins)
(10, 'Heritage Clock Tower Square', 1200.00, 1100.00, 'Overflow Risk', '2026-08-18 08:30:00'),
(10, 'Old Town Temple Street Corner', 1000.00, 940.00, 'Overflow Risk', '2026-08-17 16:30:00');

-- --------------------------------------------------------------------
-- 7. COLLECTION VEHICLES (6 Municipal Fleet Units)
-- --------------------------------------------------------------------
INSERT INTO collection_vehicles (vehicle_number, vehicle_type, capacity, status) VALUES
('MH-12-CT-1001', 'Compactor Truck', 8000.00, 'Available'),
('MH-12-CT-1002', 'Compactor Truck', 8000.00, 'On Route'),
('MH-12-TT-2001', 'Tipper Truck', 5000.00, 'Available'),
('MH-12-TT-2002', 'Tipper Truck', 5000.00, 'On Route'),
('MH-12-MT-3001', 'Mini Truck', 2500.00, 'Available'),
('MH-12-DP-4001', 'Dumper Placer', 6000.00, 'Maintenance');

-- --------------------------------------------------------------------
-- 8. COLLECTION RECORDS (40 Operational Collection Logs)
-- --------------------------------------------------------------------
INSERT INTO collection_records (bin_id, vehicle_id, collected_quantity, collection_date, collection_status, failure_reason) VALUES
-- Central Zone Collections (Bins 1, 2, 3)
(1, 1, 750.00, '2026-08-17', 'Completed', NULL),
(2, 1, 920.00, '2026-08-17', 'Completed', NULL),
(3, 1, 680.00, '2026-08-17', 'Completed', NULL),
(1, 2, 800.00, '2026-08-19', 'Completed', NULL),
(2, 2, 950.00, '2026-08-19', 'Completed', NULL),

-- Market Area Collections (Bins 4, 5, 6) - with some pending/failed due to narrow lanes
(4, 1, 1350.00, '2026-08-16', 'Completed', NULL),
(5, 3, 1800.00, '2026-08-16', 'Completed', NULL),
(6, 5, 1100.00, '2026-08-16', 'Completed', NULL),
(4, 1, 0.00, '2026-08-18', 'Failed', 'Narrow market lane blocked by illegally parked delivery tempo. Truck unable to maneuver to bin clearance point; reroute requested.'),
(5, 3, 0.00, '2026-08-18', 'Pending', NULL),
(6, 5, 1050.00, '2026-08-18', 'Completed', NULL),
(4, 1, 0.00, '2026-08-19', 'Scheduled', NULL),

-- University Road (Bins 7, 8)
(7, 5, 780.00, '2026-08-17', 'Completed', NULL),
(8, 5, 720.00, '2026-08-17', 'Completed', NULL),
(7, 5, 820.00, '2026-08-19', 'Completed', NULL),
(8, 5, 760.00, '2026-08-19', 'Completed', NULL),

-- Bus Stand (Bins 9, 10, 11)
(9, 3, 1400.00, '2026-08-16', 'Completed', NULL),
(10, 3, 1150.00, '2026-08-16', 'Completed', NULL),
(11, 3, 1300.00, '2026-08-16', 'Completed', NULL),
(9, 3, 0.00, '2026-08-18', 'Pending', NULL),
(10, 3, 0.00, '2026-08-18', 'Pending', NULL),
(11, 3, 1250.00, '2026-08-19', 'Completed', NULL),

-- Industrial Area (Bins 12, 13, 14)
(12, 1, 2200.00, '2026-08-16', 'Completed', NULL),
(13, 1, 1850.00, '2026-08-16', 'Completed', NULL),
(14, 1, 2600.00, '2026-08-16', 'Completed', NULL),
(12, 2, 2100.00, '2026-08-18', 'Completed', NULL),
(13, 2, 0.00, '2026-08-18', 'Failed', 'Hydraulic lifter arm valve pressure leak occurred during container hoist. Vehicle aborted pickup and returned to depot for emergency repairs.'),
(14, 2, 2400.00, '2026-08-18', 'Completed', NULL),

-- Residential Zone (Bins 15, 16, 17)
(15, 5, 680.00, '2026-08-17', 'Completed', NULL),
(16, 5, 590.00, '2026-08-17', 'Completed', NULL),
(17, 5, 710.00, '2026-08-17', 'Completed', NULL),
(15, 5, 700.00, '2026-08-19', 'Completed', NULL),
(16, 5, 620.00, '2026-08-19', 'Completed', NULL),
(17, 5, 730.00, '2026-08-19', 'Completed', NULL),

-- Railway Area (Bins 18, 19, 20)
(18, 3, 1350.00, '2026-08-16', 'Completed', NULL),
(19, 3, 1700.00, '2026-08-16', 'Completed', NULL),
(20, 3, 850.00, '2026-08-16', 'Completed', NULL),
(18, 3, 0.00, '2026-08-18', 'Pending', NULL),
(19, 3, 0.00, '2026-08-18', 'Pending', NULL),
(20, 3, 890.00, '2026-08-19', 'Completed', NULL),

-- Main Road (Bins 21, 22)
(21, 1, 950.00, '2026-08-17', 'Completed', NULL),
(22, 1, 880.00, '2026-08-17', 'Completed', NULL),
(21, 2, 980.00, '2026-08-19', 'Completed', NULL),
(22, 2, 910.00, '2026-08-19', 'Completed', NULL),

-- Green Park (Bins 23, 24)
(23, 5, 520.00, '2026-08-17', 'Completed', NULL),
(24, 5, 560.00, '2026-08-17', 'Completed', NULL),
(23, 5, 540.00, '2026-08-19', 'Completed', NULL),
(24, 5, 580.00, '2026-08-19', 'Completed', NULL),

-- Old Town (Bins 25, 26)
(25, 5, 950.00, '2026-08-16', 'Completed', NULL),
(25, 5, 0.00, '2026-08-18', 'Failed', 'Heritage gate street festival and dense pedestrian crowd completely blocked lane. Traffic marshals diverted heavy vehicle away.');

-- --------------------------------------------------------------------
-- 9. POST-COLLECTION LIVE ACCUMULATION UPDATE
-- Simulates waste accumulation since last collection cycle for real-time monitoring
-- --------------------------------------------------------------------
UPDATE waste_bins SET current_level = 680.00 WHERE bin_id = 3;  -- Gandhi Marg (85% - Overflow Risk)
UPDATE waste_bins SET current_level = 1420.00 WHERE bin_id = 4; -- Cloth Market (94% - Overflow Risk)
UPDATE waste_bins SET current_level = 1950.00 WHERE bin_id = 5; -- Vegetable Mandi (97% - Overflow Risk)
UPDATE waste_bins SET current_level = 1150.00 WHERE bin_id = 6; -- Fish Market (95% - Overflow Risk)
UPDATE waste_bins SET current_level = 1380.00 WHERE bin_id = 9; -- Bus Terminal (92% - Overflow Risk)
UPDATE waste_bins SET current_level = 1120.00 WHERE bin_id = 10; -- Concourse (93% - Overflow Risk)
UPDATE waste_bins SET current_level = 1750.00 WHERE bin_id = 13; -- Chemical Complex (87% - Overflow Risk)
UPDATE waste_bins SET current_level = 1390.00 WHERE bin_id = 18; -- Station Porch (92% - Overflow Risk)
UPDATE waste_bins SET current_level = 1650.00 WHERE bin_id = 19; -- Parcel Office (82% - Overflow Risk)
UPDATE waste_bins SET current_level = 1100.00 WHERE bin_id = 25; -- Clock Tower (91% - Overflow Risk)
UPDATE waste_bins SET current_level = 940.00 WHERE bin_id = 26;  -- Temple Street (94% - Overflow Risk)
UPDATE waste_bins SET current_level = 320.00 WHERE bin_id = 1;  -- Central Sq (32% - Normal)
UPDATE waste_bins SET current_level = 480.00 WHERE bin_id = 2;  -- Civic Center (40% - Normal)
UPDATE waste_bins SET current_level = 420.00 WHERE bin_id = 7;  -- Canteen (42% - Normal)
UPDATE waste_bins SET current_level = 310.00 WHERE bin_id = 8;  -- Hostel (31% - Normal)
UPDATE waste_bins SET current_level = 650.00 WHERE bin_id = 11; -- Workshop (43% - Normal)
UPDATE waste_bins SET current_level = 950.00 WHERE bin_id = 12; -- Phase-1 Blvd (38% - Normal)
UPDATE waste_bins SET current_level = 1200.00 WHERE bin_id = 14; -- Heavy Eng (40% - Normal)
UPDATE waste_bins SET current_level = 280.00 WHERE bin_id = 15; -- Sector 4 (28% - Normal)
UPDATE waste_bins SET current_level = 210.00 WHERE bin_id = 16; -- Sector 5 (26% - Normal)
UPDATE waste_bins SET current_level = 390.00 WHERE bin_id = 17; -- Sector 6 (39% - Normal)
UPDATE waste_bins SET current_level = 450.00 WHERE bin_id = 20; -- Auto Stand (45% - Normal)
UPDATE waste_bins SET current_level = 420.00 WHERE bin_id = 21; -- Flyover Underpass (35% - Normal)
UPDATE waste_bins SET current_level = 350.00 WHERE bin_id = 22; -- Petrol Station (35% - Normal)
UPDATE waste_bins SET current_level = 120.00 WHERE bin_id = 23; -- Lake Promenade (15% - Normal)
UPDATE waste_bins SET current_level = 160.00 WHERE bin_id = 24; -- Botanical Garden (20% - Normal)

