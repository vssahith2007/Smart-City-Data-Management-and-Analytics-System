// Dashboard Chart.js Visualizations

document.addEventListener('DOMContentLoaded', function () {
    fetch('/api/dashboard-charts')
        .then(response => response.json())
        .then(data => {
            renderTrafficChart(data.traffic_by_area);
            renderCongestionChart(data.congestion_dist);
            renderWasteChart(data.waste_by_area);
            renderCollectionChart(data.collection_status);
            renderEfficiencyChart(data.area_efficiency);
        })
        .catch(err => console.error('Error fetching dashboard chart data:', err));
});

function renderTrafficChart(trafficData) {
    const ctx = document.getElementById('trafficAreaChart');
    if (!ctx) return;

    const labels = trafficData.map(d => d.area_name);
    const counts = trafficData.map(d => d.total_vehicles);

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Total Vehicles Recorded',
                data: counts,
                backgroundColor: 'rgba(59, 130, 246, 0.75)',
                borderColor: '#2563eb',
                borderWidth: 1.5,
                borderRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `${context.parsed.y.toLocaleString()} vehicles`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: { color: '#f1f5f9' },
                    ticks: {
                        callback: function(val) { return val >= 1000 ? (val/1000) + 'k' : val; }
                    }
                },
                x: {
                    grid: { display: false },
                    ticks: { maxRotation: 45, minRotation: 20, font: { size: 11 } }
                }
            }
        }
    });
}

function renderCongestionChart(congestionData) {
    const ctx = document.getElementById('congestionDistChart');
    if (!ctx) return;

    const colorMap = {
        'Low': '#10b981',
        'Medium': '#3b82f6',
        'High': '#f59e0b',
        'Critical': '#ef4444'
    };

    const labels = congestionData.map(d => d.congestion_level);
    const counts = congestionData.map(d => d.count);
    const colors = labels.map(l => colorMap[l] || '#94a3b8');

    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                data: counts,
                backgroundColor: colors,
                borderWidth: 2,
                borderColor: '#ffffff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                    labels: { boxWidth: 14, font: { size: 12 } }
                }
            },
            cutout: '65%'
        }
    });
}

function renderWasteChart(wasteData) {
    const ctx = document.getElementById('wasteAreaChart');
    if (!ctx) return;

    const labels = wasteData.map(d => d.area_name);
    const fillPercent = wasteData.map(d => d.fill_percentage);

    const barColors = fillPercent.map(p => {
        if (p >= 80) return 'rgba(239, 68, 68, 0.8)';
        if (p >= 50) return 'rgba(245, 158, 11, 0.8)';
        return 'rgba(13, 148, 136, 0.8)';
    });

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Average Bin Fill %',
                data: fillPercent,
                backgroundColor: barColors,
                borderRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) { return `${context.parsed.y}% Avg Fill`; }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    grid: { color: '#f1f5f9' },
                    ticks: { callback: function(val) { return val + '%'; } }
                },
                x: {
                    grid: { display: false },
                    ticks: { maxRotation: 45, minRotation: 20, font: { size: 11 } }
                }
            }
        }
    });
}

function renderCollectionChart(colData) {
    const ctx = document.getElementById('collectionStatusChart');
    if (!ctx) return;

    const colorMap = {
        'Completed': '#10b981',
        'Pending': '#f59e0b',
        'Failed': '#ef4444',
        'Scheduled': '#0ea5e9'
    };

    const labels = colData.map(d => d.collection_status);
    const counts = colData.map(d => d.count);
    const colors = labels.map(l => colorMap[l] || '#94a3b8');

    new Chart(ctx, {
        type: 'pie',
        data: {
            labels: labels,
            datasets: [{
                data: counts,
                backgroundColor: colors,
                borderColor: '#ffffff',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                    labels: { boxWidth: 14, font: { size: 12 } }
                }
            }
        }
    });
}

function renderEfficiencyChart(effData) {
    const ctx = document.getElementById('areaEfficiencyChart');
    if (!ctx) return;

    const labels = effData.map(d => d.area_name);
    const scores = effData.map(d => d.overall_score);

    const colors = scores.map(s => {
        if (s >= 80) return 'rgba(16, 185, 129, 0.85)';
        if (s >= 60) return 'rgba(59, 130, 246, 0.85)';
        if (s >= 40) return 'rgba(245, 158, 11, 0.85)';
        return 'rgba(239, 68, 68, 0.85)';
    });

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Area Efficiency Score (0–100)',
                data: scores,
                backgroundColor: colors,
                borderRadius: 6
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const item = effData[context.dataIndex];
                            return `Score: ${context.parsed.x}/100 (${item.efficiency_category}) | Traffic: ${item.traffic_score} | Waste: ${item.waste_score}`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    beginAtZero: true,
                    max: 100,
                    grid: { color: '#f1f5f9' },
                    ticks: { callback: function(val) { return val + '/100'; } }
                },
                y: {
                    grid: { display: false }
                }
            }
        }
    });
}
