// Waste Module Scripts

function openUpdateLevelModal(binId, areaName, location, capacity, currentLevel) {
    const form = document.getElementById('updateLevelForm');
    form.action = `/waste/bin/update-level/${binId}`;

    document.getElementById('updateLevelBinDetails').innerHTML = 
        `<strong>Bin #${binId}:</strong> ${areaName} &bull; ${location} <br><strong>Capacity:</strong> ${capacity} Liters`;
    document.getElementById('new_current_level').value = currentLevel;
    document.getElementById('new_current_level').max = capacity;

    openModal('updateLevelModal');
}

function openQuickCollectModal(binId, areaName, currentLevel) {
    const binSelect = document.getElementById('col_bin_id');
    if (binSelect) {
        binSelect.value = binId;
    }
    const qtyInput = document.getElementById('collected_quantity');
    const targetQty = currentLevel > 0 ? currentLevel : 500;
    if (qtyInput) {
        qtyInput.value = targetQty;
    }
    const dateInput = document.getElementById('collection_date');
    if (dateInput) {
        dateInput.value = new Date().toISOString().split('T')[0];
    }

    // Auto-select first available vehicle with adequate remaining capacity
    const vehSelect = document.getElementById('col_vehicle_id');
    if (vehSelect) {
        for (let i = 0; i < vehSelect.options.length; i++) {
            const opt = vehSelect.options[i];
            if (!opt.disabled && opt.value) {
                const remaining = parseFloat(opt.getAttribute('data-remaining') || '0');
                if (remaining >= targetQty) {
                    vehSelect.value = opt.value;
                    break;
                }
            }
        }
    }

    openModal('logCollectionModal');
}

function openEditCollectionStatusModal(collectionId, binLocation, areaName, vehicleNumber, driverName, status, failureReason) {
    const form = document.getElementById('editCollectionStatusForm');
    form.action = `/waste/collection/update-status/${collectionId}`;

    document.getElementById('editCollectionDetails').innerHTML = 
        `<strong>Trip #${collectionId}:</strong> ${areaName} &bull; ${binLocation} <br><strong>Vehicle:</strong> ${vehicleNumber} &bull; <strong>Driver:</strong> ${driverName || 'Fleet Driver'}`;
    document.getElementById('modal_driver_name').value = driverName || 'Municipal Fleet Driver';
    document.getElementById('modal_collection_status').value = status;
    document.getElementById('modal_failure_reason').value = failureReason || '';

    openModal('editCollectionStatusModal');
}

function openDumpVehicleModal(vehicleId, vehicleNumber, currentLoad, capacity) {
    const form = document.getElementById('dumpVehicleForm');
    if (!form) return;
    form.action = `/waste/vehicle/dump/${vehicleId}`;

    const details = document.getElementById('dumpVehicleDetails');
    if (details) {
        details.innerHTML = 
            `<strong>Vehicle Plate:</strong> <span class="vehicle-plate">${vehicleNumber}</span><br>` +
            `<strong>Unloading Quantity:</strong> <span class="badge badge-warning" style="font-size: 0.95rem;">${currentLoad} kg</span> ` +
            `of ${capacity} kg Maximum Capacity`;
    }

    openModal('dumpVehicleModal');
}

function toggleFailureReasonBox(statusValue, containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;
    const textarea = container.querySelector('textarea');
    if (statusValue === 'Failed' && textarea) {
        textarea.focus();
    }
}
