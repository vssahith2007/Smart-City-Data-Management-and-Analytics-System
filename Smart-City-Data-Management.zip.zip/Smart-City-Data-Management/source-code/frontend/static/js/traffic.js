// Traffic Module Scripts

function filterSignalsByArea(areaId, signalSelectId, selectedSignalId = null) {
    const signalSelect = document.getElementById(signalSelectId);
    if (!signalSelect) return;

    // Retain previous value if not passed
    const previousVal = selectedSignalId !== null ? String(selectedSignalId) : (signalSelect.value || '');
    
    // Clear existing options completely to avoid browser style.display bugs on <option>
    signalSelect.innerHTML = '';

    const defaultOpt = document.createElement('option');
    defaultOpt.value = '';
    defaultOpt.textContent = '-- Select Signal Junction --';
    signalSelect.appendChild(defaultOpt);

    let list = (typeof ALL_TRAFFIC_SIGNALS !== 'undefined' && Array.isArray(ALL_TRAFFIC_SIGNALS)) ? ALL_TRAFFIC_SIGNALS : [];
    
    if (list.length === 0) {
        return;
    }

    let matchedSignals = [];
    if (areaId) {
        matchedSignals = list.filter(s => String(s.area_id) === String(areaId));
    } else {
        matchedSignals = list;
    }

    if (matchedSignals.length === 0) {
        const noneOpt = document.createElement('option');
        noneOpt.value = '';
        noneOpt.disabled = true;
        noneOpt.textContent = 'No signal junctions found for this area';
        signalSelect.appendChild(noneOpt);
        signalSelect.value = '';
        return;
    }

    matchedSignals.forEach(sig => {
        const opt = document.createElement('option');
        opt.value = String(sig.signal_id);
        opt.setAttribute('data-area', String(sig.area_id));
        
        let label = sig.signal_name;
        if (!areaId) {
            label += ` (${sig.area_name})`;
        }
        if (sig.status && sig.status !== 'Active') {
            label += ` [${sig.status}]`;
        }
        opt.textContent = label;
        signalSelect.appendChild(opt);
    });

    // Auto-selection:
    if (previousVal && matchedSignals.some(s => String(s.signal_id) === String(previousVal))) {
        signalSelect.value = String(previousVal);
    } else if (areaId && matchedSignals.length === 1) {
        // If an area is chosen and has exactly 1 junction, auto-select it
        signalSelect.value = String(matchedSignals[0].signal_id);
    } else {
        signalSelect.value = '';
    }
}

function syncAreaFromSignal(signalSelect, areaSelectId) {
    if (!signalSelect) return;
    const areaSelect = document.getElementById(areaSelectId);
    if (!areaSelect) return;

    const sigId = signalSelect.value;
    if (!sigId) return;

    let list = (typeof ALL_TRAFFIC_SIGNALS !== 'undefined' && Array.isArray(ALL_TRAFFIC_SIGNALS)) ? ALL_TRAFFIC_SIGNALS : [];
    const found = list.find(s => String(s.signal_id) === String(sigId));
    if (found) {
        if (String(areaSelect.value) !== String(found.area_id)) {
            areaSelect.value = String(found.area_id);
            // Re-filter so only junctions in that area are listed, preserving the chosen junction
            filterSignalsByArea(found.area_id, signalSelect.id, found.signal_id);
        }
    }
}

function openAddTrafficModal() {
    const areaSelect = document.getElementById('add_area_id');
    if (areaSelect) areaSelect.value = '';
    filterSignalsByArea('', 'add_signal_id');

    // Pre-populate today's date and current time if empty
    const dateInput = document.getElementById('add_recorded_date');
    const timeInput = document.getElementById('add_recorded_time');
    const now = new Date();
    if (dateInput && !dateInput.value) {
        dateInput.value = now.toISOString().split('T')[0];
    }
    if (timeInput && !timeInput.value) {
        const hours = String(now.getHours()).padStart(2, '0');
        const mins = String(now.getMinutes()).padStart(2, '0');
        const secs = String(now.getSeconds()).padStart(2, '0');
        timeInput.value = `${hours}:${mins}:${secs}`;
    }

    openModal('addTrafficModal');
}

function openEditTrafficModal(trafficId, areaId, signalId, count, congestion, date, time) {
    const form = document.getElementById('editTrafficForm');
    form.action = `/traffic/edit/${trafficId}`;

    const areaSelect = document.getElementById('edit_area_id');
    if (areaSelect) areaSelect.value = String(areaId);

    filterSignalsByArea(areaId, 'edit_signal_id', signalId);
    
    const signalSelect = document.getElementById('edit_signal_id');
    if (signalSelect) signalSelect.value = String(signalId);

    document.getElementById('edit_vehicle_count').value = count;
    document.getElementById('edit_congestion_level').value = congestion;
    document.getElementById('edit_recorded_date').value = date;
    document.getElementById('edit_recorded_time').value = time;

    openModal('editTrafficModal');
}

// Initialise signal lists on DOM ready
document.addEventListener('DOMContentLoaded', function() {
    filterSignalsByArea('', 'add_signal_id');
});
