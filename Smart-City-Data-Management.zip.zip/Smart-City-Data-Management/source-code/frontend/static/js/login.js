// Smart City Login Experience Scripts

document.addEventListener('DOMContentLoaded', function () {
    const loginForm = document.getElementById('loginForm');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const togglePasswordBtn = document.getElementById('togglePasswordBtn');
    const togglePwIcon = document.getElementById('togglePwIcon');
    const submitBtn = document.getElementById('submitBtn');

    // Password Visibility Toggle
    if (togglePasswordBtn && passwordInput && togglePwIcon) {
        togglePasswordBtn.addEventListener('click', function () {
            const isPassword = passwordInput.getAttribute('type') === 'password';
            if (isPassword) {
                passwordInput.setAttribute('type', 'text');
                togglePwIcon.classList.remove('fa-eye');
                togglePwIcon.classList.add('fa-eye-slash');
                togglePasswordBtn.setAttribute('aria-label', 'Hide password');
                togglePasswordBtn.setAttribute('title', 'Hide password');
            } else {
                passwordInput.setAttribute('type', 'password');
                togglePwIcon.classList.remove('fa-eye-slash');
                togglePwIcon.classList.add('fa-eye');
                togglePasswordBtn.setAttribute('aria-label', 'Show password');
                togglePasswordBtn.setAttribute('title', 'Show password');
            }
        });
    }

    // Form Submit Loading State
    if (loginForm && submitBtn) {
        loginForm.addEventListener('submit', function (e) {
            if (loginForm.checkValidity()) {
                submitBtn.classList.add('loading');
                submitBtn.setAttribute('disabled', 'disabled');
            }
        });
    }
});

// Quick-fill Demo Credentials Helper with Visual Confirmation
function fillCreds(u, p) {
    const userField = document.getElementById('username');
    const passField = document.getElementById('password');

    if (!userField || !passField) return;

    userField.value = u;
    passField.value = p;

    // Trigger visual highlight pulse
    userField.classList.remove('input-highlight-pulse');
    passField.classList.remove('input-highlight-pulse');

    // Force reflow
    void userField.offsetWidth;
    void passField.offsetWidth;

    userField.classList.add('input-highlight-pulse');
    passField.classList.add('input-highlight-pulse');

    // Move focus smoothly to submit button
    const submitBtn = document.getElementById('submitBtn');
    if (submitBtn) {
        submitBtn.focus();
    }
}
