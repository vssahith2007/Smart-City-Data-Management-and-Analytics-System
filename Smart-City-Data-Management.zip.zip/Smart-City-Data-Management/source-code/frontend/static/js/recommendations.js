// Traffic-Aware Waste Collection Recommendation Scripts

document.addEventListener('DOMContentLoaded', function() {
    initRecommendationCharts();
});

function initRecommendationCharts() {
    fetch('/api/collection-recommendations')
        .then(response => response.json())
        .then(data => {
            if (data.status !== 'success') return;

            // 1. Priority Distribution Doughnut Chart
            const pCtx = document.getElementById('priorityDistChart');
            if (pCtx) {
                const pCounts = data.priority_counts || {};
                new Chart(pCtx.getContext('2d'), {
                    type: 'doughnut',
                    data: {
                        labels: ['Critical (90-100)', 'High (70-89)', 'Medium (40-69)', 'Low (0-39)'],
                        datasets: [{
                            data: [
                                pCounts['Critical'] || 0,
                                pCounts['High'] || 0,
                                pCounts['Medium'] || 0,
                                pCounts['Low'] || 0
                            ],
                            backgroundColor: ['#ef4444', '#f59e0b', '#3b82f6', '#10b981'],
                            borderWidth: 2,
                            borderColor: '#ffffff'
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { position: 'bottom' }
                        }
                    }
                });
            }

            // 2. Traffic Breakdown Bar Chart
            const tCtx = document.getElementById('trafficSynergyChart');
            if (tCtx) {
                const tDist = data.traffic_dist || {};
                new Chart(tCtx.getContext('2d'), {
                    type: 'bar',
                    data: {
                        labels: ['Low Traffic', 'Medium Traffic', 'High Congestion', 'Critical Congestion'],
                        datasets: [{
                            label: 'Bins Under Corridor Condition',
                            data: [
                                tDist['Low'] || 0,
                                tDist['Medium'] || 0,
                                tDist['High'] || 0,
                                tDist['Critical'] || 0
                            ],
                            backgroundColor: ['#10b981', '#0ea5e9', '#f59e0b', '#ef4444'],
                            borderRadius: 6
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { display: false }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: { stepSize: 2 }
                            }
                        }
                    }
                });
            }
        })
        .catch(err => console.error('Error fetching recommendation chart analytics:', err));
}

function openRecommendationDetailModal(binId) {
    const modalBody = document.getElementById('modalDetailBody');
    modalBody.innerHTML = `
        <div class="text-center p-4">
            <i class="fa-solid fa-spinner fa-spin fa-2x text-primary"></i>
            <p class="mt-2 text-muted">Retrieving decision attributes for Bin #${binId}...</p>
        </div>
    `;
    openModal('recommendationDetailModal');

    fetch(`/api/collection-recommendations/${binId}`)
        .then(response => response.json())
        .then(result => {
            if (result.status !== 'success') {
                modalBody.innerHTML = `<div class="alert alert-danger">${result.message || 'Error loading details'}</div>`;
                return;
            }

            const d = result.data;
            const priorityBadgeClass = 
                d.priority_level === 'Critical' ? 'danger' :
                d.priority_level === 'High' ? 'warning' :
                d.priority_level === 'Medium' ? 'info' : 'secondary';

            const trafficBadgeClass = 
                d.traffic_congestion === 'Critical' ? 'danger' :
                d.traffic_congestion === 'High' ? 'warning' :
                d.traffic_congestion === 'Medium' ? 'info' : 'success';

            modalBody.innerHTML = `
                <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 1rem; margin-bottom: 1rem;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <h4 style="margin: 0; font-size: 1.1rem; color: #1e293b;">
                                <i class="fa-solid fa-trash-can text-primary"></i> Container #${d.bin_id} &bull; ${d.area_name}
                            </h4>
                            <small class="text-muted">${d.bin_location} (${d.zone})</small>
                        </div>
                        <div style="text-align: right;">
                            <span class="badge badge-${priorityBadgeClass}" style="font-size: 0.85rem;">
                                ${d.priority_level} (Score: ${d.priority_score}/100)
                            </span><br>
                            <small class="text-muted">Dispatch Sequence: <strong>#${d.recommended_sequence}</strong></small>
                        </div>
                    </div>
                </div>

                <div class="grid-2-col" style="gap: 1rem; margin-bottom: 1rem;">
                    <!-- Waste Urgency Column -->
                    <div style="background-color: #fafbfc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 0.85rem;">
                        <h5 style="margin-top: 0; margin-bottom: 0.5rem; font-size: 0.88rem; color: #334155;">
                            <i class="fa-solid fa-trash-arrow-up text-warning"></i> Waste Accumulation Urgency
                        </h5>
                        <div class="progress-bar-container mb-2">
                            <div class="fill-meter-progress fill-${d.fill_percentage >= 85 ? 'critical' : d.fill_percentage >= 70 ? 'warning' : 'normal'}" 
                                 style="width: ${Math.min(d.fill_percentage, 100)}%;"></div>
                        </div>
                        <ul style="list-style: none; padding: 0; margin: 0; font-size: 0.8rem; line-height: 1.6;">
                            <li><strong>Current Volume:</strong> ${d.current_level} / ${d.capacity} Liters (<strong>${d.fill_percentage}%</strong>)</li>
                            <li><strong>Container Status:</strong> <span class="badge badge-${d.bin_status === 'Normal' ? 'success' : 'danger'}">${d.bin_status}</span></li>
                            <li><strong>Last Collected:</strong> ${d.last_collected || 'Initial deployment'}</li>
                        </ul>
                    </div>

                    <!-- Corridor Traffic Column -->
                    <div style="background-color: #fafbfc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 0.85rem;">
                        <h5 style="margin-top: 0; margin-bottom: 0.5rem; font-size: 0.88rem; color: #334155;">
                            <i class="fa-solid fa-traffic-light text-primary"></i> Ward Corridor Traffic Condition
                        </h5>
                        <ul style="list-style: none; padding: 0; margin: 0; font-size: 0.8rem; line-height: 1.6;">
                            <li><strong>Corridor Congestion:</strong> <span class="badge badge-${trafficBadgeClass}"><i class="fa-solid fa-car"></i> ${d.traffic_congestion}</span></li>
                            <li><strong>Latest Vehicle Throughput:</strong> ${d.vehicle_count} vehicles</li>
                            <li><strong>Sensor Reading Time:</strong> ${d.traffic_recorded_time || 'Latest Cycle'}</li>
                            <li><strong>Traffic Clearance Impact:</strong> ${d.traffic_congestion === 'Low' ? '<span class="text-success">+20 (Rapid Access)</span>' : d.traffic_congestion === 'Medium' ? '<span class="text-info">+10 (Moderate Access)</span>' : '<span class="text-danger">-15 (Corridor Bottleneck)</span>'}</li>
                        </ul>
                    </div>
                </div>

                <!-- Prior Collection & Fleet Assignment Row -->
                <div class="grid-2-col" style="gap: 1rem; margin-bottom: 1rem;">
                    <!-- Prior Collection Record -->
                    <div style="background-color: #fafbfc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 0.85rem;">
                        <h5 style="margin-top: 0; margin-bottom: 0.5rem; font-size: 0.88rem; color: #334155;">
                            <i class="fa-solid fa-clipboard-check text-info"></i> Recent Trip History
                        </h5>
                        <ul style="list-style: none; padding: 0; margin: 0; font-size: 0.8rem; line-height: 1.6;">
                            <li><strong>Status:</strong> <span class="status-pill status-${d.last_collection_status.toLowerCase()}">${d.last_collection_status}</span></li>
                            <li><strong>Assigned Driver:</strong> ${d.last_driver_name || 'Fleet Driver'}</li>
                            ${d.last_failure_reason ? `
                            <li style="margin-top: 0.35rem; color: #991b1b; background-color: #fef2f2; padding: 0.35rem 0.5rem; border-radius: 4px; border: 1px solid #fecaca;">
                                <strong>Driver Obstacle Note:</strong> "${d.last_failure_reason}"
                            </li>` : ''}
                        </ul>
                    </div>

                    <!-- Recommended Fleet Vehicle -->
                    <div style="background-color: #fafbfc; border: 1px solid #e2e8f0; border-radius: 6px; padding: 0.85rem;">
                        <h5 style="margin-top: 0; margin-bottom: 0.5rem; font-size: 0.88rem; color: #334155;">
                            <i class="fa-solid fa-truck-pickup text-success"></i> Assigned Available Fleet Unit
                        </h5>
                        ${d.vehicle_number ? `
                        <ul style="list-style: none; padding: 0; margin: 0; font-size: 0.8rem; line-height: 1.6;">
                            <li><strong>Vehicle Plate:</strong> <span class="vehicle-plate">${d.vehicle_number}</span></li>
                            <li><strong>Vehicle Type:</strong> ${d.vehicle_type}</li>
                            <li><strong>Payload Capacity:</strong> ${d.vehicle_capacity} Liters</li>
                            <li><strong>Availability Check:</strong> <span class="text-success"><i class="fa-solid fa-circle-check"></i> Active & Available</span></li>
                        </ul>` : `
                        <p class="text-danger" style="font-size: 0.8rem; margin: 0;">
                            <i class="fa-solid fa-triangle-exclamation"></i> No available municipal vehicle meets capacity criteria. Fleet dispatch required.
                        </p>`}
                    </div>
                </div>

                <!-- Transparent Decision Support Action & Reason -->
                <div style="background-color: #eff6ff; border: 1px solid #bfdbfe; border-radius: 6px; padding: 0.85rem;">
                    <div style="display: flex; gap: 0.5rem; align-items: flex-start;">
                        <i class="fa-solid fa-lightbulb text-primary" style="font-size: 1.2rem; margin-top: 2px;"></i>
                        <div>
                            <strong style="color: #1e3a8a; display: block; margin-bottom: 0.25rem;">
                                Action Directive: ${d.recommended_action}
                            </strong>
                            <p style="margin: 0; font-size: 0.82rem; color: #1e40af; line-height: 1.45;">
                                <strong>Decision Reason:</strong> ${d.recommendation_reason}
                            </p>
                        </div>
                    </div>
                </div>
            `;
        })
        .catch(err => {
            modalBody.innerHTML = `<div class="alert alert-danger">Network error: ${err}</div>`;
        });
}
