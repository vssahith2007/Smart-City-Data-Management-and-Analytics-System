from flask import Blueprint, render_template, jsonify, request, flash, redirect, url_for
from auth import login_required
from db import query_db, execute_db

smart_scheduler_bp = Blueprint('smart_scheduler', __name__)

def serialize_schedule_row(row):
    """Serialize PostgreSQL Decimal, Date, and Time objects to JSON-friendly primitives."""
    if not row:
        return {}
    d = dict(row)
    for k, v in d.items():
        if hasattr(v, 'isoformat'):
            d[k] = str(v)
        elif hasattr(v, 'as_tuple'):  # Decimal
            d[k] = float(v)
    return d

@smart_scheduler_bp.route('/smart-scheduler')
@login_required
def index():
    """Smart Collection Scheduler overview page."""
    schedules = query_db("""
        SELECT 
            bin_id, bin_code, bin_location, area_id, area_name, zone,
            capacity, current_level, fill_percentage, bin_status,
            traffic_congestion, traffic_vehicle_count, traffic_recorded_time,
            priority_score, priority_level, lower_traffic_time,
            recommended_time, recommendation_reason, recommended_sequence
        FROM smart_collection_schedule_view
        ORDER BY recommended_sequence ASC, bin_id ASC;
    """)
    
    kpis = {
        'total_bins': len(schedules),
        'collect_now': sum(1 for s in schedules if s['recommended_time'] == 'Collect Now'),
        'lower_traffic_scheduled': sum(1 for s in schedules if s['recommended_time'] not in ('Collect Now', 'Schedule Soon', 'Regular Collection')),
        'schedule_soon': sum(1 for s in schedules if s['recommended_time'] == 'Schedule Soon'),
        'regular_collection': sum(1 for s in schedules if s['recommended_time'] == 'Regular Collection')
    }
    
    return render_template(
        'smart_scheduler.html',
        schedules=schedules,
        kpis=kpis
    )

@smart_scheduler_bp.route('/api/smart-scheduler')
@login_required
def api_schedules():
    """Returns JSON array of all smart collection schedule recommendations."""
    rows = query_db("""
        SELECT 
            bin_id, bin_code, bin_location, area_id, area_name, zone,
            capacity, current_level, fill_percentage, bin_status,
            traffic_congestion, traffic_vehicle_count, traffic_recorded_time,
            priority_score, priority_level, lower_traffic_time,
            recommended_time, recommendation_reason, recommended_sequence
        FROM smart_collection_schedule_view
        ORDER BY recommended_sequence ASC, bin_id ASC;
    """)
    return jsonify({
        'status': 'success',
        'count': len(rows),
        'data': [serialize_schedule_row(r) for r in rows]
    })

@smart_scheduler_bp.route('/api/smart-scheduler/<int:bin_id>')
@login_required
def api_single_bin(bin_id):
    """Returns detailed scheduling metadata for a specific waste bin."""
    row = query_db("""
        SELECT 
            bin_id, bin_code, bin_location, area_id, area_name, zone,
            capacity, current_level, fill_percentage, bin_status,
            traffic_congestion, traffic_vehicle_count, traffic_recorded_time,
            priority_score, priority_level, lower_traffic_time,
            recommended_time, recommendation_reason, recommended_sequence
        FROM smart_collection_schedule_view
        WHERE bin_id = %s;
    """, (bin_id,), one=True)
    
    if not row:
        return jsonify({'status': 'error', 'message': f'Bin ID {bin_id} not found.'}), 404
        
    return jsonify({
        'status': 'success',
        'bin': serialize_schedule_row(row)
    })

@smart_scheduler_bp.route('/api/smart-scheduler/confirm', methods=['POST'])
@login_required
def api_confirm_schedule():
    """Allows municipal operators or admins to confirm a scheduled collection."""
    data = request.get_json() or request.form
    bin_id = data.get('bin_id')
    scheduled_time = data.get('scheduled_time', 'Recommended Time')
    
    if not bin_id:
        return jsonify({'status': 'error', 'message': 'bin_id is required.'}), 400
        
    bin_row = query_db("SELECT bin_id, bin_location FROM waste_bins WHERE bin_id = %s", (bin_id,), one=True)
    if not bin_row:
        return jsonify({'status': 'error', 'message': f'Bin {bin_id} not found.'}), 404
        
    return jsonify({
        'status': 'success',
        'message': f'Collection for Bin B{bin_id} ({bin_row["bin_location"]}) successfully scheduled at {scheduled_time}.'
    })
