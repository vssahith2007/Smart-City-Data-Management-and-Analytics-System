import csv
from io import StringIO
from flask import Blueprint, render_template, request, jsonify, Response, flash, redirect, url_for
from auth import login_required
from db import query_db

recommendations_bp = Blueprint('recommendations', __name__)

@recommendations_bp.route('/collection-recommendations', methods=['GET'])
@login_required
def index():
    area_filter = request.args.get('area_id', '')
    priority_filter = request.args.get('priority_level', '')
    traffic_filter = request.args.get('traffic_congestion', '')
    action_filter = request.args.get('action', '')
    vehicle_filter = request.args.get('vehicle_id', '')

    base_query = """
        SELECT 
            bin_id, area_id, area_name, zone, bin_location,
            capacity, current_level, fill_percentage, bin_status,
            last_collected, traffic_congestion, vehicle_count,
            traffic_recorded_time, last_collection_status,
            last_failure_reason, last_driver_name, priority_score,
            priority_level, recommended_action, recommendation_reason,
            recommended_sequence, vehicle_id, vehicle_number,
            vehicle_type, vehicle_capacity
        FROM traffic_aware_collection_recommendation
        WHERE 1=1
    """
    params = []

    if area_filter:
        base_query += " AND area_id = %s"
        params.append(area_filter)
    if priority_filter:
        base_query += " AND priority_level = %s"
        params.append(priority_filter)
    if traffic_filter:
        base_query += " AND traffic_congestion = %s"
        params.append(traffic_filter)
    if action_filter:
        base_query += " AND recommended_action ILIKE %s"
        params.append(f"%{action_filter}%")
    if vehicle_filter:
        base_query += " AND vehicle_id = %s"
        params.append(vehicle_filter)

    base_query += " ORDER BY recommended_sequence ASC"
    recommendations = query_db(base_query, params)

    # Master summary stats for KPI cards
    summary_stats = query_db("""
        SELECT 
            COUNT(*) AS total_bins,
            COUNT(CASE WHEN priority_level = 'Critical' THEN 1 END) AS critical_count,
            COUNT(CASE WHEN priority_level = 'High' THEN 1 END) AS high_count,
            COUNT(CASE WHEN priority_level = 'Medium' THEN 1 END) AS medium_count,
            COUNT(CASE WHEN priority_level = 'Low' THEN 1 END) AS low_count,
            COUNT(CASE WHEN fill_percentage >= 80 OR bin_status IN ('Full', 'Overflow Risk') THEN 1 END) AS overflow_risk_count,
            COUNT(CASE WHEN priority_score >= 70 THEN 1 END) AS urgent_collections
        FROM traffic_aware_collection_recommendation;
    """, one=True)

    # Active fleet availability
    available_fleet = query_db("""
        SELECT vehicle_id, vehicle_number, vehicle_type, capacity, status
        FROM collection_vehicles
        WHERE status = 'Available'
        ORDER BY capacity DESC;
    """)

    areas = query_db("SELECT area_id, area_name FROM areas ORDER BY area_name")

    return render_template(
        'collection_recommendations.html',
        recommendations=recommendations,
        stats=summary_stats,
        available_fleet=available_fleet,
        areas=areas,
        current_filters={
            'area_id': area_filter,
            'priority_level': priority_filter,
            'traffic_congestion': traffic_filter,
            'action': action_filter,
            'vehicle_id': vehicle_filter
        }
    )

@recommendations_bp.route('/api/collection-recommendations', methods=['GET'])
@login_required
def api_recommendations():
    recs = query_db("""
        SELECT 
            recommended_sequence, bin_id, area_name, bin_location,
            fill_percentage, traffic_congestion, vehicle_count,
            last_collection_status, priority_score, priority_level,
            vehicle_number, vehicle_type, recommended_action, recommendation_reason
        FROM traffic_aware_collection_recommendation
        ORDER BY recommended_sequence ASC;
    """)

    priority_counts = query_db("""
        SELECT 
            priority_level, COUNT(*) AS count
        FROM traffic_aware_collection_recommendation
        GROUP BY priority_level;
    """)

    traffic_dist = query_db("""
        SELECT 
            traffic_congestion, COUNT(*) AS count
        FROM traffic_aware_collection_recommendation
        GROUP BY traffic_congestion;
    """)

    return jsonify({
        'status': 'success',
        'recommendations': recs,
        'priority_counts': {row['priority_level']: row['count'] for row in priority_counts},
        'traffic_dist': {row['traffic_congestion']: row['count'] for row in traffic_dist}
    })

@recommendations_bp.route('/api/collection-recommendations/<int:bin_id>', methods=['GET'])
@login_required
def api_recommendation_detail(bin_id):
    rec = query_db("""
        SELECT 
            bin_id, area_id, area_name, zone, bin_location,
            capacity, current_level, fill_percentage, bin_status,
            last_collected, traffic_congestion, vehicle_count,
            traffic_recorded_time, last_collection_status,
            last_failure_reason, last_driver_name, priority_score,
            priority_level, recommended_action, recommendation_reason,
            recommended_sequence, vehicle_id, vehicle_number,
            vehicle_type, vehicle_capacity
        FROM traffic_aware_collection_recommendation
        WHERE bin_id = %s;
    """, (bin_id,), one=True)

    if not rec:
        return jsonify({'status': 'error', 'message': f'Recommendation for Bin #{bin_id} not found'}), 404

    data = dict(rec)
    if data.get('traffic_recorded_time'):
        data['traffic_recorded_time'] = str(data['traffic_recorded_time'])
    if data.get('last_collected'):
        data['last_collected'] = str(data['last_collected'])

    return jsonify({'status': 'success', 'data': data})

@recommendations_bp.route('/collection-recommendations/export/csv', methods=['GET'])
@login_required
def export_csv():
    recs = query_db("""
        SELECT 
            recommended_sequence AS "Sequence_Order",
            bin_id AS "Bin_ID",
            area_name AS "Area_Name",
            bin_location AS "Location",
            capacity AS "Capacity_L",
            current_level AS "Current_Waste_L",
            fill_percentage AS "Fill_Percentage",
            bin_status AS "Bin_Status",
            traffic_congestion AS "Corridor_Traffic",
            vehicle_count AS "Latest_Vehicle_Count",
            last_collection_status AS "Last_Trip_Status",
            COALESCE(last_driver_name, 'None') AS "Reporting_Driver",
            COALESCE(last_failure_reason, 'None') AS "Driver_Failure_Notes",
            priority_score AS "Priority_Score",
            priority_level AS "Priority_Classification",
            COALESCE(vehicle_number, 'None Assigned') AS "Recommended_Vehicle",
            COALESCE(vehicle_type, 'N/A') AS "Vehicle_Type",
            recommended_action AS "Action_Directive",
            recommendation_reason AS "Decision_Support_Reason"
        FROM traffic_aware_collection_recommendation
        ORDER BY recommended_sequence ASC;
    """)

    if not recs:
        flash('No recommendation records found to export.', 'warning')
        return redirect(url_for('recommendations.index'))

    output = StringIO()
    writer = csv.DictWriter(output, fieldnames=recs[0].keys())
    writer.writeheader()
    writer.writerows(recs)

    return Response(
        output.getvalue(),
        mimetype='text/csv',
        headers={'Content-Disposition': 'attachment; filename=traffic_aware_waste_collection_recommendations.csv'}
    )
