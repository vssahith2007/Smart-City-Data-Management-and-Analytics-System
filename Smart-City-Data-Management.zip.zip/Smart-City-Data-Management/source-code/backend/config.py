import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'smartcity-dbms-secret-key-2026-btech')
    DB_HOST = os.environ.get('DB_HOST', '127.0.0.1')
    DB_PORT = int(os.environ.get('DB_PORT', 5432))
    DB_NAME = os.environ.get('DB_NAME', 'smartcity_db')
    DB_USER = os.environ.get('DB_USER', 'postgres')
    DB_PASSWORD = os.environ.get('DB_PASSWORD', 'postgres')
    DEBUG = os.environ.get('DEBUG', 'True').lower() in ('true', '1', 't')
