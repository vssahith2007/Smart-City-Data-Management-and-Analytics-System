import os
import psycopg2
from config import Config

def init_database():
    """Initializes PostgreSQL schema, triggers, and sample data."""
    base_dir = os.path.dirname(os.path.abspath(__file__))
    db_dir = os.path.join(os.path.dirname(base_dir), 'database')

    schema_path = os.path.join(db_dir, 'schema.sql')
    triggers_path = os.path.join(db_dir, 'triggers.sql')
    data_path = os.path.join(db_dir, 'data.sql')

    print(f"Connecting to PostgreSQL at {Config.DB_HOST}:{Config.DB_PORT} as {Config.DB_USER}...")
    conn = psycopg2.connect(
        host=Config.DB_HOST,
        port=Config.DB_PORT,
        dbname=Config.DB_NAME,
        user=Config.DB_USER,
        password=Config.DB_PASSWORD
    )
    cur = conn.cursor()

    print("Executing schema.sql...")
    with open(schema_path, 'r', encoding='utf-8') as f:
        cur.execute(f.read())
    conn.commit()

    print("Executing triggers.sql...")
    with open(triggers_path, 'r', encoding='utf-8') as f:
        cur.execute(f.read())
    conn.commit()

    print("Executing data.sql...")
    with open(data_path, 'r', encoding='utf-8') as f:
        cur.execute(f.read())
    conn.commit()

    cur.close()
    conn.close()
    print("Database initialized successfully with 3NF schema, triggers, and sample datasets!")

if __name__ == '__main__':
    init_database()
