from flask import Blueprint, render_template, request, redirect, url_for, flash
from auth import login_required, admin_required
from db import query_db, execute_db

areas_bp = Blueprint('areas', __name__)

@areas_bp.route('/areas', methods=['GET'])
@login_required
def index():
    areas_list = query_db("""
        SELECT 
            a.area_id, a.area_name, a.zone, a.population, a.description,
            COUNT(DISTINCT ts.signal_id) AS total_signals,
            COUNT(DISTINCT wb.bin_id) AS total_bins,
            COUNT(DISTINCT tr.traffic_id) AS total_traffic_logs,
            COALESCE(SUM(tr.vehicle_count), 0) AS total_vehicles
        FROM areas a
        LEFT JOIN traffic_signals ts ON a.area_id = ts.area_id
        LEFT JOIN waste_bins wb ON a.area_id = wb.area_id
        LEFT JOIN traffic_records tr ON a.area_id = tr.area_id
        GROUP BY a.area_id, a.area_name, a.zone, a.population, a.description
        ORDER BY a.area_id ASC;
    """)

    # Distinct zones for filtering/form
    zones = ['Zone-1 (Central)', 'Zone-2 (North)', 'Zone-3 (East)', 'Zone-4 (South)', 'Zone-5 (West)']

    return render_template('areas.html', areas=areas_list, zones=zones)

@areas_bp.route('/areas/add', methods=['POST'])
@admin_required
def add_area():
    try:
        area_name = request.form.get('area_name', '').strip()
        zone = request.form.get('zone', '').strip()
        population = int(request.form.get('population', 0))
        description = request.form.get('description', '').strip()

        if not area_name or not zone:
            flash('Area name and zone are required.', 'danger')
            return redirect(url_for('areas.index'))

        if population < 0:
            flash('Population must be a non-negative integer.', 'danger')
            return redirect(url_for('areas.index'))

        execute_db("""
            INSERT INTO areas (area_name, zone, population, description)
            VALUES (%s, %s, %s, %s)
        """, (area_name, zone, population, description))

        # Ensure default junction signal is created for the new area
        cur_area = query_db("SELECT area_id FROM areas WHERE area_name = %s ORDER BY area_id DESC LIMIT 1", (area_name,), one=True)
        if cur_area:
            execute_db("""
                INSERT INTO traffic_signals (area_id, signal_name, location, status)
                VALUES (%s, %s, %s, 'Active')
            """, (cur_area['area_id'], f"{area_name} Main Junction Signal", f"{area_name} Central Intersection"))

        flash(f'Area "{area_name}" registered successfully!', 'success')
    except Exception as e:
        flash(f'Error adding area: {str(e)}', 'danger')

    return redirect(url_for('areas.index'))

@areas_bp.route('/areas/edit/<int:area_id>', methods=['POST'])
@admin_required
def edit_area(area_id):
    try:
        area_name = request.form.get('area_name', '').strip()
        zone = request.form.get('zone', '').strip()
        population = int(request.form.get('population', 0))
        description = request.form.get('description', '').strip()

        execute_db("""
            UPDATE areas
            SET area_name = %s, zone = %s, population = %s, description = %s
            WHERE area_id = %s
        """, (area_name, zone, population, description, area_id))

        flash(f'Area #{area_id} updated successfully!', 'success')
    except Exception as e:
        flash(f'Error updating area: {str(e)}', 'danger')

    return redirect(url_for('areas.index'))
