from flask import Blueprint, render_template, request, redirect, url_for, flash
from auth import login_required
from db import query_db, execute_db, get_db_cursor

waste_bp = Blueprint('waste', __name__)

@waste_bp.route('/waste', methods=['GET'])
@login_required
def index():
    area_filter = request.args.get('area_id', '')
    status_filter = request.args.get('status', '')

    # Waste bins query with area join
    bin_query = """
        SELECT wb.bin_id, wb.area_id, wb.bin_location, wb.capacity, wb.current_level,
               wb.status, wb.last_collected, a.area_name,
               ROUND((wb.current_level / NULLIF(wb.capacity, 0)) * 100, 1) AS fill_percentage
        FROM waste_bins wb
        JOIN areas a ON wb.area_id = a.area_id
        WHERE 1=1
    """
    params = []
    if area_filter:
        bin_query += " AND wb.area_id = %s"
        params.append(area_filter)
    if status_filter:
        bin_query += " AND wb.status = %s"
        params.append(status_filter)

    bin_query += " ORDER BY fill_percentage DESC, wb.bin_id ASC"
    bins = query_db(bin_query, params)

    # Master lists for forms with Fleet Load calculations
    areas = query_db("SELECT area_id, area_name FROM areas ORDER BY area_name")
    vehicles = query_db("""
        SELECT vehicle_id, vehicle_number, vehicle_type, capacity, current_load, status,
               ROUND(capacity - current_load, 1) AS remaining_capacity,
               ROUND((current_load / NULLIF(capacity, 0)) * 100, 1) AS load_percentage
        FROM collection_vehicles
        ORDER BY vehicle_number
    """)

    # Recent Disposal Operations
    disposals = query_db("""
        SELECT wd.disposal_id, wd.vehicle_id, wd.disposed_quantity, wd.facility_name,
               wd.disposal_date, wd.disposal_time, wd.operator_notes,
               cv.vehicle_number, cv.vehicle_type
        FROM waste_disposals wd
        JOIN collection_vehicles cv ON wd.vehicle_id = cv.vehicle_id
        ORDER BY wd.disposal_date DESC, wd.disposal_time DESC, wd.disposal_id DESC
        LIMIT 15;
    """)

    # Collection Records
    collections = query_db("""
        SELECT cr.collection_id, cr.bin_id, cr.vehicle_id, cr.driver_name, cr.collected_quantity,
               cr.collection_date, cr.collection_status, cr.failure_reason, wb.bin_location,
               a.area_name, cv.vehicle_number
        FROM collection_records cr
        JOIN waste_bins wb ON cr.bin_id = wb.bin_id
        JOIN areas a ON wb.area_id = a.area_id
        JOIN collection_vehicles cv ON cr.vehicle_id = cv.vehicle_id
        ORDER BY cr.collection_date DESC, cr.collection_id DESC
        LIMIT 50;
    """)

    # Waste KPIs
    waste_stats = query_db("""
        SELECT 
            COUNT(*) AS total_bins,
            COUNT(CASE WHEN status IN ('Full', 'Overflow Risk') OR (capacity > 0 AND current_level/capacity >= 0.80) THEN 1 END) AS overflow_bins,
            COALESCE(ROUND(AVG(current_level / NULLIF(capacity, 0) * 100), 1), 0) AS avg_fill_rate,
            COALESCE(SUM(current_level), 0) AS total_current_waste
        FROM waste_bins;
    """, one=True)

    collection_kpi = query_db("""
        SELECT 
            COUNT(*) AS total_trips,
            COUNT(CASE WHEN collection_status = 'Completed' THEN 1 END) AS completed_trips,
            COUNT(CASE WHEN collection_status IN ('Pending', 'Failed') THEN 1 END) AS pending_trips
        FROM collection_records;
    """, one=True)

    # Fleet Load KPIs
    fleet_kpi = query_db("""
        SELECT 
            COALESCE(SUM(capacity), 0) AS total_fleet_capacity,
            COALESCE(SUM(current_load), 0) AS total_fleet_load,
            COUNT(CASE WHEN status = 'Available' THEN 1 END) AS available_trucks,
            COUNT(CASE WHEN current_load >= capacity THEN 1 END) AS full_trucks
        FROM collection_vehicles;
    """, one=True)

    coll_eff = round((collection_kpi['completed_trips'] / collection_kpi['total_trips'] * 100), 1) if collection_kpi['total_trips'] > 0 else 100.0

    highest_waste_area = query_db("""
        SELECT a.area_name, SUM(wb.current_level) AS total_waste
        FROM areas a
        JOIN waste_bins wb ON a.area_id = wb.area_id
        GROUP BY a.area_id, a.area_name
        ORDER BY total_waste DESC
        LIMIT 1;
    """, one=True)

    return render_template(
        'waste.html',
        bins=bins,
        areas=areas,
        vehicles=vehicles,
        collections=collections,
        disposals=disposals,
        stats=waste_stats,
        fleet_kpi=fleet_kpi,
        pending_trips=collection_kpi['pending_trips'],
        coll_eff=coll_eff,
        highest_area=highest_waste_area['area_name'] if highest_waste_area else 'N/A',
        area_filter=area_filter,
        status_filter=status_filter
    )

@waste_bp.route('/waste/bin/add', methods=['POST'])
@login_required
def add_bin():
    try:
        area_id = int(request.form.get('area_id'))
        bin_location = request.form.get('bin_location', '').strip()
        capacity = float(request.form.get('capacity', 1000))
        current_level = float(request.form.get('current_level', 0))
        status = request.form.get('status', 'Normal')

        if capacity <= 0:
            flash('Bin capacity must be greater than 0.', 'danger')
            return redirect(url_for('waste.index'))

        if current_level < 0 or current_level > capacity:
            flash('Current level must be between 0 and total capacity.', 'danger')
            return redirect(url_for('waste.index'))

        execute_db("""
            INSERT INTO waste_bins (area_id, bin_location, capacity, current_level, status)
            VALUES (%s, %s, %s, %s, %s)
        """, (area_id, bin_location, capacity, current_level, status))

        flash('Waste bin registered successfully!', 'success')
    except Exception as e:
        flash(f'Error adding waste bin: {str(e)}', 'danger')

    return redirect(url_for('waste.index'))

@waste_bp.route('/waste/bin/update-level/<int:bin_id>', methods=['POST'])
@login_required
def update_bin_level(bin_id):
    try:
        current_level = float(request.form.get('current_level'))
        bin_info = query_db("SELECT capacity FROM waste_bins WHERE bin_id = %s", (bin_id,), one=True)
        if not bin_info:
            flash('Waste bin not found.', 'danger')
            return redirect(url_for('waste.index'))

        if current_level < 0 or current_level > float(bin_info['capacity']):
            flash(f'Current level must be between 0 and capacity ({bin_info["capacity"]} L).', 'danger')
            return redirect(url_for('waste.index'))

        # Triggers will automatically synchronize status based on fill level
        execute_db("UPDATE waste_bins SET current_level = %s WHERE bin_id = %s", (current_level, bin_id))
        flash(f'Bin #{bin_id} fill level updated to {current_level} L. Status synchronized.', 'success')
    except Exception as e:
        flash(f'Error updating waste level: {str(e)}', 'danger')

    return redirect(url_for('waste.index'))

@waste_bp.route('/waste/bin/delete/<int:bin_id>', methods=['POST'])
@login_required
def delete_bin(bin_id):
    try:
        execute_db("DELETE FROM waste_bins WHERE bin_id = %s", (bin_id,))
        flash(f'Waste bin #{bin_id} deleted successfully.', 'success')
    except Exception as e:
        flash(f'Error deleting waste bin: {str(e)}', 'danger')
    return redirect(url_for('waste.index'))

@waste_bp.route('/waste/collection/add', methods=['POST'])
@login_required
def add_collection():
    try:
        bin_id = int(request.form.get('bin_id'))
        vehicle_id = int(request.form.get('vehicle_id'))
        driver_name = request.form.get('driver_name', '').strip() or 'Municipal Fleet Driver'
        collected_quantity = float(request.form.get('collected_quantity', 0))
        collection_date = request.form.get('collection_date')
        collection_status = request.form.get('collection_status', 'Completed')
        failure_reason = request.form.get('failure_reason', '').strip() or None

        if collected_quantity < 0:
            flash('Collected quantity cannot be negative.', 'danger')
            return redirect(url_for('waste.index'))

        if collection_status == 'Failed' and not failure_reason:
            flash(f'Driver {driver_name} must provide a brief 2-line reason explaining why the collection failed.', 'warning')

        # Capacity & Bin Validation when status is Completed
        if collection_status == 'Completed':
            if collected_quantity <= 0:
                flash('Collected quantity must be greater than 0 for a Completed collection.', 'danger')
                return redirect(url_for('waste.index'))

            # Check Vehicle
            vehicle = query_db("""
                SELECT vehicle_id, vehicle_number, vehicle_type, capacity, current_load, status
                FROM collection_vehicles
                WHERE vehicle_id = %s
            """, (vehicle_id,), one=True)
            if not vehicle:
                flash('Selected vehicle not found.', 'danger')
                return redirect(url_for('waste.index'))

            if vehicle['status'] == 'Maintenance':
                flash(f'Cannot assign Vehicle {vehicle["vehicle_number"]}: Vehicle is currently under Maintenance.', 'danger')
                return redirect(url_for('waste.index'))

            remaining_capacity = float(vehicle['capacity']) - float(vehicle['current_load'])
            if collected_quantity > remaining_capacity:
                flash(
                    f'Collection rejected: Exceeds vehicle capacity! '
                    f'Vehicle {vehicle["vehicle_number"]} has only {remaining_capacity:.1f} kg remaining capacity '
                    f'(attempted {collected_quantity:.1f} kg, current load: {float(vehicle["current_load"]):.1f}/{float(vehicle["capacity"]):.1f} kg). '
                    f'Please dump the truck load or assign an available vehicle with adequate capacity.',
                    'danger'
                )
                return redirect(url_for('waste.index'))

            # Check Bin
            bin_data = query_db("SELECT bin_id, current_level, capacity, bin_location FROM waste_bins WHERE bin_id = %s", (bin_id,), one=True)
            if not bin_data:
                flash('Selected waste bin not found.', 'danger')
                return redirect(url_for('waste.index'))

            if float(bin_data['current_level']) <= 0:
                flash(f'Collection rejected: Bin #{bin_id} at {bin_data["bin_location"]} is already empty (0 L). No waste to collect.', 'warning')
                return redirect(url_for('waste.index'))

            if collected_quantity > float(bin_data['current_level']):
                collected_quantity = float(bin_data['current_level'])

            # Duplicate submission protection (within 60 seconds)
            recent_duplicate = query_db("""
                SELECT collection_id FROM collection_records
                WHERE bin_id = %s AND vehicle_id = %s AND collected_quantity = %s
                  AND collection_status = 'Completed'
                  AND created_at >= NOW() - INTERVAL '60 seconds'
            """, (bin_id, vehicle_id, collected_quantity), one=True)
            if recent_duplicate:
                flash(f'Duplicate collection ignored: An identical collection for Bin #{bin_id} was already submitted within the last 60 seconds.', 'warning')
                return redirect(url_for('waste.index'))

        # Insert collection record - PostgreSQL trigger will automatically update bin level and vehicle load
        execute_db("""
            INSERT INTO collection_records (bin_id, vehicle_id, driver_name, collected_quantity, collection_date, collection_status, failure_reason)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, (bin_id, vehicle_id, driver_name, collected_quantity, collection_date, collection_status, failure_reason))

        if collection_status == 'Completed':
            flash(f'Collection logged successfully! Collected {collected_quantity:.1f} kg. Bin #{bin_id} level reduced and assigned vehicle load updated.', 'success')
        elif collection_status == 'Failed':
            flash(f'Collection marked as Failed. Reason logged directly from Driver {driver_name}: "{failure_reason}".', 'warning')
        else:
            flash(f'Collection operation logged as {collection_status}.', 'info')

    except Exception as e:
        flash(f'Error logging collection: {str(e)}', 'danger')

    return redirect(url_for('waste.index'))

@waste_bp.route('/waste/collection/update-status/<int:collection_id>', methods=['POST'])
@login_required
def update_collection_status(collection_id):
    try:
        new_status = request.form.get('collection_status')
        driver_name = request.form.get('driver_name', '').strip() or None
        failure_reason = request.form.get('failure_reason', '').strip() or None

        current_record = query_db("SELECT * FROM collection_records WHERE collection_id = %s", (collection_id,), one=True)
        if not current_record:
            flash('Collection record not found.', 'danger')
            return redirect(url_for('waste.index'))

        # If transitioning to Completed from a non-Completed status, check vehicle capacity
        if new_status == 'Completed' and current_record['collection_status'] != 'Completed':
            vehicle = query_db("SELECT capacity, current_load, vehicle_number FROM collection_vehicles WHERE vehicle_id = %s", (current_record['vehicle_id'],), one=True)
            if vehicle:
                rem = float(vehicle['capacity']) - float(vehicle['current_load'])
                qty = float(current_record['collected_quantity'])
                if qty > rem:
                    flash(f'Cannot mark trip as Completed: Exceeds vehicle {vehicle["vehicle_number"]} capacity! Remaining capacity: {rem:.1f} kg, trip requires: {qty:.1f} kg.', 'danger')
                    return redirect(url_for('waste.index'))

        if driver_name and failure_reason:
            execute_db("""
                UPDATE collection_records 
                SET collection_status = %s, driver_name = %s, failure_reason = %s 
                WHERE collection_id = %s
            """, (new_status, driver_name, failure_reason, collection_id))
            flash(f'Trip #{collection_id} updated. Driver {driver_name}\'s report recorded.', 'warning' if new_status == 'Failed' else 'success')
        elif failure_reason:
            execute_db("""
                UPDATE collection_records 
                SET collection_status = %s, failure_reason = %s 
                WHERE collection_id = %s
            """, (new_status, failure_reason, collection_id))
            flash(f'Trip #{collection_id} updated with driver reason.', 'warning' if new_status == 'Failed' else 'success')
        else:
            execute_db("""
                UPDATE collection_records 
                SET collection_status = %s 
                WHERE collection_id = %s
            """, (new_status, collection_id))
            flash(f'Collection record #{collection_id} updated to {new_status}.', 'success')
    except Exception as e:
        flash(f'Error updating collection status: {str(e)}', 'danger')
    return redirect(url_for('waste.index'))

@waste_bp.route('/waste/vehicle/dump/<int:vehicle_id>', methods=['POST'])
@login_required
def dump_vehicle(vehicle_id):
    try:
        facility_name = request.form.get('facility_name', '').strip() or 'Central Waste Processing & Recycling Facility'
        operator_notes = request.form.get('operator_notes', '').strip() or None

        vehicle = query_db("""
            SELECT vehicle_id, vehicle_number, vehicle_type, capacity, current_load, status
            FROM collection_vehicles
            WHERE vehicle_id = %s
        """, (vehicle_id,), one=True)

        if not vehicle:
            flash('Vehicle not found.', 'danger')
            return redirect(url_for('waste.index'))

        current_load = float(vehicle['current_load'])
        if current_load <= 0:
            flash(f'Vehicle {vehicle["vehicle_number"]} is already empty (0 kg load). No waste to unload.', 'info')
            return redirect(url_for('waste.index'))

        # Record disposal and reset truck load atomically in a transaction
        with get_db_cursor(commit=True) as cur:
            # 1. Record in waste_disposals table
            cur.execute("""
                INSERT INTO waste_disposals (vehicle_id, disposed_quantity, facility_name, disposal_date, disposal_time, operator_notes)
                VALUES (%s, %s, %s, CURRENT_DATE, CURRENT_TIME, %s)
            """, (vehicle_id, current_load, facility_name, operator_notes))

            # 2. Reset truck load to zero and mark as Available if not under Maintenance
            new_status = 'Maintenance' if vehicle['status'] == 'Maintenance' else 'Available'
            cur.execute("""
                UPDATE collection_vehicles
                SET current_load = 0.00,
                    status = %s
                WHERE vehicle_id = %s
            """, (new_status, vehicle_id))

        flash(
            f'Disposal logged successfully! Dumped {current_load:.1f} kg from Vehicle {vehicle["vehicle_number"]} '
            f'at "{facility_name}". Current load reset to 0 kg. Vehicle status is now "{new_status}".',
            'success'
        )
    except Exception as e:
        flash(f'Error dumping truck load: {str(e)}', 'danger')

    return redirect(url_for('waste.index'))

