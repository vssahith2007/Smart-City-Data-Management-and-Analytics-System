import sys
import os
import unittest

# Add backend directory to sys.path
backend_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if backend_dir not in sys.path:
    sys.path.insert(0, backend_dir)

from app import create_app
from db import query_db, execute_db

class SmartCitySystemTestCase(unittest.TestCase):
    def setUp(self):
        self.app = create_app()
        self.app.config['TESTING'] = True
        self.client = self.app.test_client()

    def test_01_database_connection_and_areas(self):
        """Test PostgreSQL connection and master areas count."""
        areas = query_db("SELECT COUNT(*) AS count FROM areas")
        self.assertTrue(len(areas) > 0)
        self.assertGreaterEqual(areas[0]['count'], 8, "Expected at least 8 city areas in the database.")

    def test_02_relational_integrity_and_records(self):
        """Test traffic and waste tables have sample rows."""
        traffic_count = query_db("SELECT COUNT(*) AS count FROM traffic_records", one=True)['count']
        waste_count = query_db("SELECT COUNT(*) AS count FROM waste_bins", one=True)['count']
        vehicles_count = query_db("SELECT COUNT(*) AS count FROM collection_vehicles", one=True)['count']
        collections_count = query_db("SELECT COUNT(*) AS count FROM collection_records", one=True)['count']

        self.assertGreaterEqual(traffic_count, 40, "Expected at least 40 traffic records.")
        self.assertGreaterEqual(waste_count, 20, "Expected at least 20 waste bins.")
        self.assertGreaterEqual(vehicles_count, 5, "Expected at least 5 collection vehicles.")
        self.assertGreaterEqual(collections_count, 30, "Expected at least 30 collection records.")

    def test_03_trigger_update_bin_after_collection(self):
        """Verify trigger automatically resets bin level upon completed collection."""
        # 1. Create a test bin
        test_bin_id = execute_db("""
            INSERT INTO waste_bins (area_id, bin_location, capacity, current_level, status)
            VALUES (1, 'Test Trigger Bin Location', 1000.0, 900.0, 'Overflow Risk')
            RETURNING bin_id;
        """, return_id=True)

        bin_before = query_db("SELECT current_level, status FROM waste_bins WHERE bin_id = %s", (test_bin_id,), one=True)
        self.assertEqual(float(bin_before['current_level']), 900.0)

        # 2. Insert Completed collection record
        execute_db("""
            INSERT INTO collection_records (bin_id, vehicle_id, collected_quantity, collection_date, collection_status)
            VALUES (%s, 1, 900.0, CURRENT_DATE, 'Completed');
        """, (test_bin_id,))

        # 3. Check that trigger emptied the bin
        bin_after = query_db("SELECT current_level, status, last_collected FROM waste_bins WHERE bin_id = %s", (test_bin_id,), one=True)
        self.assertEqual(float(bin_after['current_level']), 0.0, "Trigger failed to empty bin current_level.")
        self.assertEqual(bin_after['status'], 'Normal', "Trigger failed to reset bin status to Normal.")
        self.assertIsNotNone(bin_after['last_collected'], "Trigger failed to set last_collected timestamp.")

        # Cleanup test bin
        execute_db("DELETE FROM waste_bins WHERE bin_id = %s", (test_bin_id,))

    def test_04_views_and_efficiency_calculation(self):
        """Test analytical SQL views and Area Efficiency Score ranges."""
        eff_rows = query_db("SELECT * FROM area_efficiency_view")
        self.assertTrue(len(eff_rows) >= 8)

        for row in eff_rows:
            overall = row['overall_score']
            traffic_score = row['traffic_score']
            waste_score = row['waste_score']

            self.assertTrue(0 <= overall <= 100, f"Overall score {overall} out of range [0, 100]")
            self.assertTrue(0 <= traffic_score <= 100, f"Traffic score {traffic_score} out of range [0, 100]")
            self.assertTrue(0 <= waste_score <= 100, f"Waste score {waste_score} out of range [0, 100]")
            self.assertIn(row['efficiency_category'], ['Excellent', 'Good', 'Needs Attention', 'Critical'])

    def test_05_authentication_flow(self):
        """Test login with Admin and Operator credentials."""
        # 1. Invalid login
        res_fail = self.client.post('/login', data={'username': 'admin', 'password': 'wrongpassword'}, follow_redirects=True)
        self.assertIn(b'Invalid username or password', res_fail.data)

        # 2. Valid Admin login
        with self.client:
            res_admin = self.client.post('/login', data={'username': 'admin', 'password': 'admin123'}, follow_redirects=True)
            self.assertIn(b'Executive Analytics Dashboard', res_admin.data)
            self.assertEqual(res_admin.status_code, 200)

    def test_06_endpoints_access_and_crud(self):
        """Test accessing all modules and performing CRUD."""
        # Log in as Admin
        self.client.post('/login', data={'username': 'admin', 'password': 'admin123'}, follow_redirects=True)

        # 1. Dashboard
        res_dash = self.client.get('/dashboard')
        self.assertEqual(res_dash.status_code, 200)
        self.assertIn(b'Monitored Areas', res_dash.data)

        # 2. API Chart endpoint
        res_api = self.client.get('/api/dashboard-charts')
        self.assertEqual(res_api.status_code, 200)
        json_data = res_api.get_json()
        self.assertIn('traffic_by_area', json_data)
        self.assertIn('congestion_dist', json_data)
        self.assertIn('waste_by_area', json_data)

        # 3. Traffic Module
        res_traffic = self.client.get('/traffic')
        self.assertEqual(res_traffic.status_code, 200)

        # 4. Waste Module
        res_waste = self.client.get('/waste')
        self.assertEqual(res_waste.status_code, 200)

        # 5. Analytics Module
        res_analytics = self.client.get('/analytics')
        self.assertEqual(res_analytics.status_code, 200)
        self.assertIn(b'Priority Area Identification', res_analytics.data)

        # 6. Areas Module
        res_areas = self.client.get('/areas')
        self.assertEqual(res_areas.status_code, 200)

    def test_07_collection_failure_reason(self):
        """Test logging a failed collection record with driver's 2-line failure reason and driver attribution."""
        self.client.post('/login', data={'username': 'operator', 'password': 'operator123'}, follow_redirects=True)
        
        driver_name = "Rajesh Kumar (Driver)"
        reason_text = "Narrow lane blocked by delivery tempo. Truck unable to reach bin clearance point."
        res = self.client.post('/waste/collection/add', data={
            'bin_id': 1,
            'vehicle_id': 1,
            'driver_name': driver_name,
            'collected_quantity': 0,
            'collection_date': '2026-10-06',
            'collection_status': 'Failed',
            'failure_reason': reason_text
        }, follow_redirects=True)
        
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Collection marked as Failed', res.data)
        
        # Verify in database
        latest_rec = query_db("""
            SELECT collection_id, driver_name, collection_status, failure_reason 
            FROM collection_records 
            WHERE failure_reason = %s
        """, (reason_text,), one=True)
        
        self.assertIsNotNone(latest_rec)
        self.assertEqual(latest_rec['driver_name'], driver_name)
        self.assertEqual(latest_rec['collection_status'], 'Failed')
        self.assertEqual(latest_rec['failure_reason'], reason_text)

        # Cleanup test record
        execute_db("DELETE FROM collection_records WHERE collection_id = %s", (latest_rec['collection_id'],))

    # ====================================================================
    # NEW FEATURE TESTS: TRAFFIC-AWARE WASTE COLLECTION RECOMMENDATION
    # ====================================================================

    def test_08_priority_score_calculation(self):
        """1. Test that all priority scores are bounded within [0, 100]."""
        recs = query_db("SELECT priority_score FROM traffic_aware_collection_recommendation")
        self.assertTrue(len(recs) >= 20, "Expected at least 20 bins in recommendation view.")
        for r in recs:
            score = float(r['priority_score'])
            self.assertTrue(0 <= score <= 100, f"Priority score {score} out of bounds [0, 100].")

    def test_09_priority_classification(self):
        """2. Test that priority levels conform strictly to 4-tier classification."""
        recs = query_db("SELECT priority_score, priority_level FROM traffic_aware_collection_recommendation")
        for r in recs:
            score = float(r['priority_score'])
            level = r['priority_level']
            self.assertIn(level, ['Critical', 'High', 'Medium', 'Low'])
            if score >= 90:
                self.assertEqual(level, 'Critical')
            elif score >= 70:
                self.assertEqual(level, 'High')
            elif score >= 40:
                self.assertEqual(level, 'Medium')
            else:
                self.assertEqual(level, 'Low')

    def test_10_high_waste_low_traffic_case(self):
        """3. Test high waste + low traffic condition recommends immediate collection."""
        # Insert a temporary test bin with 95% fill in Green Park (which has Low traffic, area_id 9)
        test_bin_id = execute_db("""
            INSERT INTO waste_bins (area_id, bin_location, capacity, current_level, status)
            VALUES (9, 'Test High Waste Low Traffic Bin', 1000.0, 950.0, 'Overflow Risk')
            RETURNING bin_id;
        """, return_id=True)
        
        rec = query_db("SELECT * FROM traffic_aware_collection_recommendation WHERE bin_id = %s", (test_bin_id,), one=True)
        self.assertIsNotNone(rec)
        self.assertEqual(rec['traffic_congestion'], 'Low')
        self.assertEqual(float(rec['fill_percentage']), 95.0)
        self.assertIn('Collect Immediately', rec['recommended_action'])

        # Cleanup
        execute_db("DELETE FROM waste_bins WHERE bin_id = %s", (test_bin_id,))

    def test_11_high_waste_high_traffic_case(self):
        """4. Test high waste + high/critical traffic recommends off-peak window."""
        # Insert a test bin in Market Area (area_id 2, which has Critical traffic)
        test_bin_id = execute_db("""
            INSERT INTO waste_bins (area_id, bin_location, capacity, current_level, status)
            VALUES (2, 'Test High Waste Critical Traffic Bin', 1000.0, 950.0, 'Overflow Risk')
            RETURNING bin_id;
        """, return_id=True)

        rec = query_db("SELECT * FROM traffic_aware_collection_recommendation WHERE bin_id = %s", (test_bin_id,), one=True)
        self.assertIsNotNone(rec)
        self.assertEqual(rec['traffic_congestion'], 'Critical')
        self.assertIn('Off-Peak Window', rec['recommended_action'])

        # Cleanup
        execute_db("DELETE FROM waste_bins WHERE bin_id = %s", (test_bin_id,))

    def test_12_low_waste_high_traffic_case(self):
        """5. Test low waste + critical traffic recommends deferring route."""
        # Insert a test bin with 40% fill in Central Zone (area_id 1, Critical traffic)
        test_bin_id = execute_db("""
            INSERT INTO waste_bins (area_id, bin_location, capacity, current_level, status)
            VALUES (1, 'Test Low Waste Critical Traffic Bin', 1000.0, 400.0, 'Normal')
            RETURNING bin_id;
        """, return_id=True)

        rec = query_db("SELECT * FROM traffic_aware_collection_recommendation WHERE bin_id = %s", (test_bin_id,), one=True)
        self.assertIsNotNone(rec)
        self.assertEqual(rec['traffic_congestion'], 'Critical')
        self.assertIn('Defer Route', rec['recommended_action'])

        # Cleanup
        execute_db("DELETE FROM waste_bins WHERE bin_id = %s", (test_bin_id,))

    def test_13_unavailable_vehicle_not_recommended(self):
        """6. Test that vehicles with status != 'Available' are NEVER recommended."""
        # Vehicles 2, 4 are 'On Route', Vehicle 6 is 'Maintenance'
        unavailable_vehicles = query_db("SELECT vehicle_number FROM collection_vehicles WHERE status != 'Available'")
        unavailable_plates = [v['vehicle_number'] for v in unavailable_vehicles]

        recs = query_db("SELECT vehicle_number FROM traffic_aware_collection_recommendation WHERE vehicle_number IS NOT NULL")
        for r in recs:
            self.assertNotIn(r['vehicle_number'], unavailable_plates, 
                             f"Vehicle {r['vehicle_number']} is not available but was recommended.")

    def test_14_completed_collection_updates_recommendation(self):
        """7. Test that logging a Completed collection updates trigger state and lowers priority."""
        test_bin_id = execute_db("""
            INSERT INTO waste_bins (area_id, bin_location, capacity, current_level, status)
            VALUES (2, 'Test Priority Reset Bin', 1000.0, 950.0, 'Overflow Risk')
            RETURNING bin_id;
        """, return_id=True)

        # Before collection: priority should be High or Critical
        before = query_db("SELECT priority_score, priority_level FROM traffic_aware_collection_recommendation WHERE bin_id = %s", (test_bin_id,), one=True)
        self.assertTrue(float(before['priority_score']) >= 70)

        # Log Completed collection
        execute_db("""
            INSERT INTO collection_records (bin_id, vehicle_id, collected_quantity, collection_date, collection_status)
            VALUES (%s, 1, 950.0, CURRENT_DATE, 'Completed')
        """, (test_bin_id,))

        # After collection: trigger empties bin, priority should plunge to Low
        after = query_db("SELECT priority_score, priority_level, fill_percentage FROM traffic_aware_collection_recommendation WHERE bin_id = %s", (test_bin_id,), one=True)
        self.assertEqual(float(after['fill_percentage']), 0.0)
        self.assertEqual(after['priority_level'], 'Low')

        # Cleanup
        execute_db("DELETE FROM waste_bins WHERE bin_id = %s", (test_bin_id,))

    def test_15_invalid_bin_values_rejected(self):
        """8. Test database check constraints reject invalid container metrics."""
        # Attempt to insert current_level > capacity
        with self.assertRaises(Exception):
            execute_db("""
                INSERT INTO waste_bins (area_id, bin_location, capacity, current_level, status)
                VALUES (1, 'Invalid Overflow Bin', 1000.0, 1500.0, 'Normal');
            """)

        # Attempt to insert negative capacity
        with self.assertRaises(Exception):
            execute_db("""
                INSERT INTO waste_bins (area_id, bin_location, capacity, current_level, status)
                VALUES (1, 'Invalid Negative Bin', -500.0, 0.0, 'Normal');
            """)

    def test_16_authentication_recommendation_routes(self):
        """9. Test authentication requirements on new recommendation endpoints."""
        # Unauthenticated access should redirect to login
        res = self.client.get('/collection-recommendations')
        self.assertEqual(res.status_code, 302)
        self.assertIn('/login', res.headers.get('Location', ''))

        res_api = self.client.get('/api/collection-recommendations')
        self.assertEqual(res_api.status_code, 302)

        # Authenticated access
        self.client.post('/login', data={'username': 'admin', 'password': 'admin123'}, follow_redirects=True)
        res_auth = self.client.get('/collection-recommendations')
        self.assertEqual(res_auth.status_code, 200)
        self.assertIn(b'Traffic-Aware Waste Collection Recommendations', res_auth.data)

    def test_17_api_response_structure(self):
        """10. Test API endpoints return required JSON schema and single bin inspector data."""
        self.client.post('/login', data={'username': 'admin', 'password': 'admin123'}, follow_redirects=True)
        
        # 1. Collection list API
        res = self.client.get('/api/collection-recommendations')
        self.assertEqual(res.status_code, 200)
        json_data = res.get_json()
        self.assertEqual(json_data['status'], 'success')
        self.assertIn('recommendations', json_data)
        self.assertIn('priority_counts', json_data)
        self.assertIn('traffic_dist', json_data)

        first_rec = json_data['recommendations'][0]
        self.assertIn('recommended_sequence', first_rec)
        self.assertIn('priority_score', first_rec)
        self.assertIn('priority_level', first_rec)
        self.assertIn('recommended_action', first_rec)
        self.assertIn('vehicle_number', first_rec)

        # 2. Detail API for Bin #1
        res_detail = self.client.get(f"/api/collection-recommendations/{first_rec['bin_id']}")
        self.assertEqual(res_detail.status_code, 200)
        detail_json = res_detail.get_json()
        self.assertEqual(detail_json['status'], 'success')
        self.assertIn('recommendation_reason', detail_json['data'])
        self.assertIn('traffic_congestion', detail_json['data'])

    # ====================================================================
    # NEW FEATURE TESTS: SMART WASTE COLLECTION SCHEDULING
    # ====================================================================

    def test_18_smart_collection_scheduler_rules(self):
        """11. Test the 4 core scheduling logic rules for Smart Waste Collection Scheduling."""
        rows = query_db("SELECT * FROM smart_collection_schedule_view")
        self.assertTrue(len(rows) >= 20, "Expected at least 20 bins in smart_collection_schedule_view.")

        for r in rows:
            fill = float(r['fill_percentage'])
            traffic = r['traffic_congestion']
            rec_time = r['recommended_time']
            reason = r['recommendation_reason']

            # Check that each row has valid fields
            self.assertIsNotNone(r['bin_code'])
            self.assertIsNotNone(r['area_name'])
            self.assertIsNotNone(r['priority_level'])
            self.assertIsNotNone(rec_time)
            self.assertIsNotNone(reason)

            # Rule 1: High waste + low traffic -> "Collect Now"
            if (fill >= 70.0 or r['bin_status'] in ('Full', 'Overflow Risk')) and traffic in ('Low', 'Medium'):
                self.assertEqual(rec_time, 'Collect Now')
                self.assertIn('Immediate collection', reason)

            # Rule 2: High waste + high/critical traffic -> Next lower-traffic period
            elif (fill >= 70.0 or r['bin_status'] in ('Full', 'Overflow Risk')) and traffic in ('High', 'Critical'):
                self.assertNotIn(rec_time, ['Collect Now', 'Schedule Soon', 'Regular Collection'])
                self.assertIn('next lower-traffic period', reason)

            # Rule 3: Medium waste -> "Schedule Soon"
            elif fill >= 40.0:
                self.assertEqual(rec_time, 'Schedule Soon')
                self.assertIn('Schedule', reason)

            # Rule 4: Low waste -> "Regular Collection"
            else:
                self.assertEqual(rec_time, 'Regular Collection')
                self.assertIn('regular collection', reason)

    def test_19_smart_collection_scheduler_dashboard_and_api(self):
        """12. Test Smart Collection Scheduler dashboard integration, modal data, and REST APIs."""
        self.client.post('/login', data={'username': 'admin', 'password': 'admin123'}, follow_redirects=True)

        # 1. Dashboard section check
        res_dash = self.client.get('/dashboard')
        self.assertEqual(res_dash.status_code, 200)
        self.assertIn(b'Smart Collection Scheduler', res_dash.data)
        self.assertIn(b'Recommended Time', res_dash.data)
        self.assertIn(b'smartScheduleModal', res_dash.data)

        # 2. REST API: /api/smart-scheduler
        res_api = self.client.get('/api/smart-scheduler')
        self.assertEqual(res_api.status_code, 200)
        api_data = res_api.get_json()
        self.assertEqual(api_data['status'], 'success')
        self.assertGreaterEqual(api_data['count'], 20)
        first_bin = api_data['data'][0]
        self.assertIn('bin_code', first_bin)
        self.assertIn('area_name', first_bin)
        self.assertIn('fill_percentage', first_bin)
        self.assertIn('traffic_congestion', first_bin)
        self.assertIn('priority_level', first_bin)
        self.assertIn('recommended_time', first_bin)
        self.assertIn('recommendation_reason', first_bin)

        # 3. Single Bin API: /api/smart-scheduler/<bin_id>
        res_single = self.client.get(f"/api/smart-scheduler/{first_bin['bin_id']}")
        self.assertEqual(res_single.status_code, 200)
        single_data = res_single.get_json()
        self.assertEqual(single_data['status'], 'success')
        self.assertEqual(single_data['bin']['bin_id'], first_bin['bin_id'])
        self.assertIn('recommendation_reason', single_data['bin'])

        # 4. Dedicated page: /smart-scheduler
        res_page = self.client.get('/smart-scheduler')
        self.assertEqual(res_page.status_code, 200)
        self.assertIn(b'Smart Collection Scheduler', res_page.data)

    def test_13_traffic_signal_junction_selection_and_record_addition(self):
        """13. Test Traffic Signal Junction dropdown rendering, signal filtering, and adding records."""
        self.client.post('/login', data={'username': 'admin', 'password': 'admin123'}, follow_redirects=True)

        # 1. Check /traffic page contains ALL signals including Maintenance and Inactive junctions
        res = self.client.get('/traffic')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'ALL_TRAFFIC_SIGNALS', res.data)
        self.assertIn(b'Industrial Bypass Signal', res.data)
        self.assertIn(b'Heritage Gate Signal', res.data)
        self.assertIn(b'Central Square Junction Signal', res.data)

        # 2. Add traffic record specifying area and signal junction
        res_add1 = self.client.post('/traffic/add', data={
            'area_id': 5,
            'signal_id': 6,  # Industrial Bypass Signal
            'vehicle_count': 520,
            'congestion_level': 'Medium',
            'recorded_date': '2026-10-08',
            'recorded_time': '11:15:00'
        }, follow_redirects=True)
        self.assertEqual(res_add1.status_code, 200)
        self.assertIn(b'Traffic record added successfully!', res_add1.data)

        # Verify in DB
        db_rec1 = query_db("""
            SELECT traffic_id, area_id, signal_id, vehicle_count 
            FROM traffic_records 
            WHERE signal_id = 6 AND vehicle_count = 520
            ORDER BY traffic_id DESC LIMIT 1
        """, one=True)
        self.assertIsNotNone(db_rec1)
        self.assertEqual(db_rec1['area_id'], 5)

        # 3. Add traffic record with signal_id auto-syncing area_id
        res_add2 = self.client.post('/traffic/add', data={
            'signal_id': 1,  # Central Square Junction Signal in Area 1
            'vehicle_count': 780,
            'congestion_level': 'High',
            'recorded_date': '2026-10-08',
            'recorded_time': '12:00:00'
        }, follow_redirects=True)
        self.assertEqual(res_add2.status_code, 200)
        self.assertIn(b'Traffic record added successfully!', res_add2.data)

        # Verify area_id was properly derived
        db_rec2 = query_db("""
            SELECT traffic_id, area_id, signal_id 
            FROM traffic_records 
            WHERE signal_id = 1 AND vehicle_count = 780
            ORDER BY traffic_id DESC LIMIT 1
        """, one=True)
        self.assertIsNotNone(db_rec2)
        self.assertEqual(db_rec2['area_id'], 1)

        # Clean up test traffic records
        execute_db("DELETE FROM traffic_records WHERE traffic_id IN (%s, %s)", (db_rec1['traffic_id'], db_rec2['traffic_id']))

    def test_14_waste_bin_and_truck_load_management(self):
        """14. Test full collection, partial collection, truck capacity limits, dumping load, and duplicate prevention."""
        self.client.post('/login', data={'username': 'admin', 'password': 'admin123'}, follow_redirects=True)

        # 1. Setup test vehicle with 2000 kg capacity and 0 initial load
        test_veh_id = execute_db("""
            INSERT INTO collection_vehicles (vehicle_number, vehicle_type, capacity, current_load, status)
            VALUES ('TEST-TRK-999', 'Tipper Truck', 2000.0, 0.0, 'Available')
            RETURNING vehicle_id;
        """, return_id=True)

        # Setup test bin with 1000 kg capacity and 800 kg level
        test_bin_id = execute_db("""
            INSERT INTO waste_bins (area_id, bin_location, capacity, current_level, status)
            VALUES (1, 'Test Bin Load Mgmt Point', 1000.0, 800.0, 'Overflow Risk')
            RETURNING bin_id;
        """, return_id=True)

        try:
            # --- TEST A: Partial Collection ---
            # Collect 300 kg out of 800 kg
            res_partial = self.client.post('/waste/collection/add', data={
                'bin_id': test_bin_id,
                'vehicle_id': test_veh_id,
                'driver_name': 'Test Driver Alpha',
                'collected_quantity': 300.0,
                'collection_date': '2026-10-09',
                'collection_status': 'Completed'
            }, follow_redirects=True)
            self.assertEqual(res_partial.status_code, 200)
            self.assertIn(b'Collection logged successfully', res_partial.data)

            # Check bin reduced by 300 kg (800 - 300 = 500)
            bin_after_part = query_db("SELECT current_level, status FROM waste_bins WHERE bin_id = %s", (test_bin_id,), one=True)
            self.assertEqual(float(bin_after_part['current_level']), 500.0)

            # Check vehicle load increased by 300 kg (0 + 300 = 300)
            veh_after_part = query_db("SELECT current_load FROM collection_vehicles WHERE vehicle_id = %s", (test_veh_id,), one=True)
            self.assertEqual(float(veh_after_part['current_load']), 300.0)

            # --- TEST B: Duplicate Submission Prevention ---
            # Re-submitting the exact same collection immediately should be rejected
            res_dup = self.client.post('/waste/collection/add', data={
                'bin_id': test_bin_id,
                'vehicle_id': test_veh_id,
                'driver_name': 'Test Driver Alpha',
                'collected_quantity': 300.0,
                'collection_date': '2026-10-09',
                'collection_status': 'Completed'
            }, follow_redirects=True)
            self.assertEqual(res_dup.status_code, 200)
            self.assertIn(b'Duplicate collection ignored', res_dup.data)

            # Confirm vehicle load is STILL 300 (not doubled to 600)
            veh_after_dup = query_db("SELECT current_load FROM collection_vehicles WHERE vehicle_id = %s", (test_veh_id,), one=True)
            self.assertEqual(float(veh_after_dup['current_load']), 300.0)

            # --- TEST C: Capacity Limit Enforcement ---
            # Truck capacity is 2000, current load is 300, remaining is 1700.
            # Attempt to collect 1800 kg into this truck: should be rejected
            test_bin2_id = execute_db("""
                INSERT INTO waste_bins (area_id, bin_location, capacity, current_level, status)
                VALUES (1, 'Test Bin Heavy Point', 3000.0, 2500.0, 'Overflow Risk')
                RETURNING bin_id;
            """, return_id=True)

            res_overflow = self.client.post('/waste/collection/add', data={
                'bin_id': test_bin2_id,
                'vehicle_id': test_veh_id,
                'driver_name': 'Test Driver Beta',
                'collected_quantity': 1800.0,  # 300 + 1800 = 2100 > 2000 max capacity
                'collection_date': '2026-10-09',
                'collection_status': 'Completed'
            }, follow_redirects=True)
            self.assertEqual(res_overflow.status_code, 200)
            self.assertIn(b'Exceeds vehicle capacity', res_overflow.data)

            # Verify bin2 remained untouched at 2500.0
            bin2_check = query_db("SELECT current_level FROM waste_bins WHERE bin_id = %s", (test_bin2_id,), one=True)
            self.assertEqual(float(bin2_check['current_level']), 2500.0)

            # Verify truck load remained untouched at 300.0
            veh_check = query_db("SELECT current_load FROM collection_vehicles WHERE vehicle_id = %s", (test_veh_id,), one=True)
            self.assertEqual(float(veh_check['current_load']), 300.0)
            execute_db("DELETE FROM waste_bins WHERE bin_id = %s", (test_bin2_id,))

            # --- TEST D: Full Collection ---
            # Remaining level in test_bin_id is 500.0. Collect 500.0 (full collection)
            res_full = self.client.post('/waste/collection/add', data={
                'bin_id': test_bin_id,
                'vehicle_id': test_veh_id,
                'driver_name': 'Test Driver Gamma',
                'collected_quantity': 500.0,
                'collection_date': '2026-10-09',
                'collection_status': 'Completed'
            }, follow_redirects=True)
            self.assertEqual(res_full.status_code, 200)

            # Assert bin level becomes 0.0 and status Normal
            bin_after_full = query_db("SELECT current_level, status FROM waste_bins WHERE bin_id = %s", (test_bin_id,), one=True)
            self.assertEqual(float(bin_after_full['current_level']), 0.0)
            self.assertEqual(bin_after_full['status'], 'Normal')

            # Assert vehicle load increased by 500 (300 + 500 = 800)
            veh_after_full = query_db("SELECT current_load FROM collection_vehicles WHERE vehicle_id = %s", (test_veh_id,), one=True)
            self.assertEqual(float(veh_after_full['current_load']), 800.0)

            # --- TEST E: Dump Truck Load (Facility Unload) ---
            # Set truck to 'On Route' first to verify status resets to Available
            execute_db("UPDATE collection_vehicles SET status = 'On Route' WHERE vehicle_id = %s", (test_veh_id,))

            res_dump = self.client.post(f'/waste/vehicle/dump/{test_veh_id}', data={
                'facility_name': 'Central Waste Processing & Recycling Facility',
                'operator_notes': 'Full unloading verification test run'
            }, follow_redirects=True)
            self.assertEqual(res_dump.status_code, 200)
            self.assertIn(b'Disposal logged successfully', res_dump.data)

            # Assert vehicle load is reset to 0.0 and status is Available
            veh_after_dump = query_db("SELECT current_load, status FROM collection_vehicles WHERE vehicle_id = %s", (test_veh_id,), one=True)
            self.assertEqual(float(veh_after_dump['current_load']), 0.0)
            self.assertEqual(veh_after_dump['status'], 'Available')

            # Assert disposal record is logged in waste_disposals
            disp_record = query_db("""
                SELECT disposal_id, disposed_quantity, facility_name 
                FROM waste_disposals 
                WHERE vehicle_id = %s 
                ORDER BY disposal_id DESC LIMIT 1
            """, (test_veh_id,), one=True)
            self.assertIsNotNone(disp_record)
            self.assertEqual(float(disp_record['disposed_quantity']), 800.0)
            self.assertEqual(disp_record['facility_name'], 'Central Waste Processing & Recycling Facility')

        finally:
            # Cleanup test data
            execute_db("DELETE FROM waste_bins WHERE bin_id = %s", (test_bin_id,))
            execute_db("DELETE FROM collection_vehicles WHERE vehicle_id = %s", (test_veh_id,))

if __name__ == '__main__':
    unittest.main()

