import psycopg2
from psycopg2.extras import RealDictCursor
from contextlib import contextmanager
from config import Config

def get_connection():
    """Establish and return a new PostgreSQL connection."""
    return psycopg2.connect(
        host=Config.DB_HOST,
        port=Config.DB_PORT,
        dbname=Config.DB_NAME,
        user=Config.DB_USER,
        password=Config.DB_PASSWORD
    )

@contextmanager
def get_db_cursor(commit=False):
    """
    Context manager for database cursor.
    Ensures safe transaction commit or rollback and connection closing.
    """
    conn = get_connection()
    try:
        cur = conn.cursor(cursor_factory=RealDictCursor)
        yield cur
        if commit:
            conn.commit()
    except Exception as e:
        conn.rollback()
        raise e
    finally:
        cur.close()
        conn.close()

def query_db(query, args=(), one=False):
    """
    Execute a read-only query and return all or one row as dictionaries.
    Uses parameterized queries to prevent SQL injection.
    """
    with get_db_cursor(commit=False) as cur:
        cur.execute(query, args)
        rv = cur.fetchall()
        return (rv[0] if rv else None) if one else rv

def execute_db(query, args=(), return_id=False):
    """
    Execute an INSERT, UPDATE, or DELETE statement.
    Uses parameterized queries and returns the generated ID if requested.
    """
    with get_db_cursor(commit=True) as cur:
        cur.execute(query, args)
        if return_id:
            row = cur.fetchone()
            return row['user_id'] if 'user_id' in row else (list(row.values())[0] if row else None)
        return cur.rowcount
