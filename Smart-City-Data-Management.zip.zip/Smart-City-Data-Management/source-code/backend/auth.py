from functools import wraps
from flask import session, redirect, url_for, flash, request
from werkzeug.security import check_password_hash, generate_password_hash
from db import query_db

def hash_password(password):
    """Hash a plaintext password using Werkzeug security."""
    return generate_password_hash(password)

def verify_password(password_hash, password):
    """Verify password against stored hash."""
    return check_password_hash(password_hash, password)

def authenticate_user(username, password):
    """Authenticate user against PostgreSQL database."""
    user = query_db("SELECT user_id, name, username, password_hash, role FROM users WHERE username = %s", (username,), one=True)
    if user and verify_password(user['password_hash'], password):
        return user
    return None

def login_required(f):
    """Decorator to require authenticated session."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('auth.login', next=request.url))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    """Decorator to require Admin role."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in first.', 'warning')
            return redirect(url_for('auth.login', next=request.url))
        if session.get('role') != 'Admin':
            flash('Access restricted. Admin privileges required.', 'danger')
            return redirect(url_for('dashboard.index'))
        return f(*args, **kwargs)
    return decorated_function
