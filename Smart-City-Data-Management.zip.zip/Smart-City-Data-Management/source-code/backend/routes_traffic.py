from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from auth import login_required, admin_required
from db import query_db, execute_db

traffic_bp = Blueprint('traffic', __name__)

@traffic_bp.route('/traffic', methods=['GET'])
@login_required
def index():
    # Filter parameters
    area_filter = request.args.get('area_id', '')
    congestion_filter = request.args.get('congestion_level', '')
    date_filter = request.args.get('date', '')

    # Base query for traffic records with JOINs
    query = """
        SELECT tr.traffic_id, tr.area_id, tr.signal_id, tr.vehicle_count, tr.congestion_level,
               tr.recorded_date, tr.recorded_time, a.area_name, ts.signal_name
        FROM traffic_records tr
        JOIN areas a ON tr.area_id = a.area_id
        JOIN traffic_signals ts ON tr.signal_id = ts.signal_id
        WHERE 1=1
    """
    params = []

    if area_filter:
        query += " AND tr.area_id = %s"
        params.append(area_filter)
    if congestion_filter:
        query += " AND tr.congestion_level = %s"
        params.append(congestion_filter)
    if date_filter:
        query += " AND tr.recorded_date = %s"
        params.append(date_filter)

    query += " ORDER BY tr.recorded_date DESC, tr.recorded_time DESC LIMIT 100"
    records = query_db(query, params)

    # Master lists for dropdowns
    areas = query_db("SELECT area_id, area_name FROM areas ORDER BY area_name")
    signals = query_db("""
        SELECT ts.signal_id, ts.area_id, ts.signal_name, ts.location, ts.status, a.area_name
        FROM traffic_signals ts
        JOIN areas a ON ts.area_id = a.area_id
        ORDER BY a.area_name, ts.signal_name
    """)

    # Traffic Incidents list
    incidents = query_db("""
        SELECT ti.incident_id, ti.incident_type, ti.severity, ti.description, ti.incident_date, ti.status, a.area_name
        FROM traffic_incidents ti
        JOIN areas a ON ti.area_id = a.area_id
        ORDER BY ti.incident_date DESC, ti.incident_id DESC
    """)

    # Traffic KPIs
    traffic_stats = query_db("""
        SELECT 
            COUNT(*) AS total_records,
            COALESCE(SUM(vehicle_count), 0) AS total_vehicles,
            COALESCE(ROUND(AVG(vehicle_count), 1), 0) AS avg_vehicles
        FROM traffic_records
    """, one=True)

    highest_traffic_area = query_db("""
        SELECT a.area_name, SUM(tr.vehicle_count) AS total_vol
        FROM areas a
        JOIN traffic_records tr ON a.area_id = tr.area_id
        GROUP BY a.area_id, a.area_name
        ORDER BY total_vol DESC
        LIMIT 1;
    """, one=True)

    peak_time = query_db("""
        SELECT EXTRACT(HOUR FROM recorded_time)::INT AS peak_hour, SUM(vehicle_count) AS total_vol
        FROM traffic_records
        GROUP BY peak_hour
        ORDER BY total_vol DESC
        LIMIT 1;
    """, one=True)

    return render_template(
        'traffic.html',
        records=records,
        areas=areas,
        signals=signals,
        incidents=incidents,
        stats=traffic_stats,
        highest_area=highest_traffic_area['area_name'] if highest_traffic_area else 'N/A',
        peak_hour=f"{peak_time['peak_hour']:02d}:00 - {(peak_time['peak_hour']+1):02d}:00" if peak_time else 'N/A',
        area_filter=area_filter,
        congestion_filter=congestion_filter,
        date_filter=date_filter
    )

@traffic_bp.route('/traffic/add', methods=['POST'])
@login_required
def add_record():
    try:
        area_id_val = request.form.get('area_id')
        signal_id_val = request.form.get('signal_id')

        if not signal_id_val:
            flash('Traffic signal junction must be selected.', 'danger')
            return redirect(url_for('traffic.index'))

        signal_id = int(signal_id_val)
        if not area_id_val:
            sig = query_db("SELECT area_id FROM traffic_signals WHERE signal_id = %s", (signal_id,), one=True)
            if sig:
                area_id = sig['area_id']
            else:
                flash('Invalid traffic signal junction selected.', 'danger')
                return redirect(url_for('traffic.index'))
        else:
            area_id = int(area_id_val)

        vehicle_count = int(request.form.get('vehicle_count', 0))
        congestion_level = request.form.get('congestion_level', 'Medium').strip()
        recorded_date = request.form.get('recorded_date')
        recorded_time = request.form.get('recorded_time')

        if vehicle_count < 0:
            flash('Vehicle count must be a non-negative number.', 'danger')
            return redirect(url_for('traffic.index'))

        if congestion_level not in ('Low', 'Medium', 'High', 'Critical'):
            flash('Invalid congestion level specified.', 'danger')
            return redirect(url_for('traffic.index'))

        execute_db("""
            INSERT INTO traffic_records (area_id, signal_id, vehicle_count, congestion_level, recorded_date, recorded_time)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (area_id, signal_id, vehicle_count, congestion_level, recorded_date, recorded_time))

        flash('Traffic record added successfully!', 'success')
    except Exception as e:
        flash(f'Error adding traffic record: {str(e)}', 'danger')

    return redirect(url_for('traffic.index'))

@traffic_bp.route('/traffic/edit/<int:traffic_id>', methods=['POST'])
@login_required
def edit_record(traffic_id):
    try:
        area_id_val = request.form.get('area_id')
        signal_id_val = request.form.get('signal_id')

        if not signal_id_val:
            flash('Traffic signal junction must be selected.', 'danger')
            return redirect(url_for('traffic.index'))

        signal_id = int(signal_id_val)
        if not area_id_val:
            sig = query_db("SELECT area_id FROM traffic_signals WHERE signal_id = %s", (signal_id,), one=True)
            if sig:
                area_id = sig['area_id']
            else:
                flash('Invalid traffic signal junction selected.', 'danger')
                return redirect(url_for('traffic.index'))
        else:
            area_id = int(area_id_val)

        vehicle_count = int(request.form.get('vehicle_count', 0))
        congestion_level = request.form.get('congestion_level', 'Medium').strip()
        recorded_date = request.form.get('recorded_date')
        recorded_time = request.form.get('recorded_time')

        if vehicle_count < 0:
            flash('Vehicle count must be non-negative.', 'danger')
            return redirect(url_for('traffic.index'))

        execute_db("""
            UPDATE traffic_records
            SET area_id = %s, signal_id = %s, vehicle_count = %s, congestion_level = %s,
                recorded_date = %s, recorded_time = %s
            WHERE traffic_id = %s
        """, (area_id, signal_id, vehicle_count, congestion_level, recorded_date, recorded_time, traffic_id))

        flash(f'Traffic record #{traffic_id} updated successfully!', 'success')
    except Exception as e:
        flash(f'Error updating traffic record: {str(e)}', 'danger')

    return redirect(url_for('traffic.index'))

@traffic_bp.route('/traffic/delete/<int:traffic_id>', methods=['POST'])
@login_required
def delete_record(traffic_id):
    try:
        execute_db("DELETE FROM traffic_records WHERE traffic_id = %s", (traffic_id,))
        flash(f'Traffic record #{traffic_id} deleted successfully.', 'success')
    except Exception as e:
        flash(f'Error deleting traffic record: {str(e)}', 'danger')
    return redirect(url_for('traffic.index'))

@traffic_bp.route('/traffic/incident/add', methods=['POST'])
@login_required
def add_incident():
    try:
        area_id = int(request.form.get('area_id'))
        incident_type = request.form.get('incident_type')
        severity = request.form.get('severity')
        description = request.form.get('description')
        incident_date = request.form.get('incident_date')
        status = request.form.get('status', 'Reported')

        execute_db("""
            INSERT INTO traffic_incidents (area_id, incident_type, severity, description, incident_date, status)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (area_id, incident_type, severity, description, incident_date, status))

        flash('Traffic incident reported successfully!', 'success')
    except Exception as e:
        flash(f'Error adding incident: {str(e)}', 'danger')

    return redirect(url_for('traffic.index'))

@traffic_bp.route('/traffic/incident/update-status/<int:incident_id>', methods=['POST'])
@login_required
def update_incident_status(incident_id):
    try:
        status = request.form.get('status')
        execute_db("UPDATE traffic_incidents SET status = %s WHERE incident_id = %s", (status, incident_id))
        flash(f'Incident #{incident_id} status updated to {status}.', 'success')
    except Exception as e:
        flash(f'Error updating incident status: {str(e)}', 'danger')
    return redirect(url_for('traffic.index'))
