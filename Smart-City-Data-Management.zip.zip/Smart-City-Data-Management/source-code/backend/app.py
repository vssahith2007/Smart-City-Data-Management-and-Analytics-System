import os
from flask import Flask, render_template, session
from config import Config
from routes_auth import auth_bp
from routes_dashboard import dashboard_bp
from routes_traffic import traffic_bp
from routes_waste import waste_bp
from routes_analytics import analytics_bp
from routes_areas import areas_bp
from routes_collection_recommendations import recommendations_bp
from routes_smart_scheduler import smart_scheduler_bp

def create_app():
    base_dir = os.path.dirname(os.path.abspath(__file__))
    frontend_dir = os.path.join(os.path.dirname(base_dir), 'frontend')
    template_dir = os.path.join(frontend_dir, 'templates')
    static_dir = os.path.join(frontend_dir, 'static')

    app = Flask(__name__, template_folder=template_dir, static_folder=static_dir)
    app.config.from_object(Config)

    # Register modular route blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(traffic_bp)
    app.register_blueprint(waste_bp)
    app.register_blueprint(analytics_bp)
    app.register_blueprint(areas_bp)
    app.register_blueprint(recommendations_bp)
    app.register_blueprint(smart_scheduler_bp)

    @app.context_processor
    def inject_user():
        return {
            'current_user': {
                'id': session.get('user_id'),
                'username': session.get('username'),
                'name': session.get('name'),
                'role': session.get('role')
            } if 'user_id' in session else None
        }

    @app.errorhandler(404)
    def page_not_found(e):
        return render_template('404.html'), 404

    @app.errorhandler(500)
    def internal_server_error(e):
        return render_template('500.html', error=str(e)), 500

    return app

app = create_app()

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=Config.DEBUG)
