from flask import Blueprint, render_template, jsonify, Response
from auth import login_required
from db import query_db
import csv
import io

analytics_bp = Blueprint('analytics', __name__)

@analytics_bp.route('/analytics')
@login_required
def index():
    # 1. Area Efficiency Scores from Database View
    area_efficiency = query_db("""
        SELECT 
            area_id, area_name, zone, population,
            total_vehicles, avg_vehicle_count, heavy_congestion_count, traffic_score,
            total_bins, avg_fill_percentage, overflow_risk_bins, collection_efficiency, waste_score,
            overall_score, efficiency_category
        FROM area_efficiency_view
        ORDER BY overall_score ASC;
    """)

    # 2. Priority Areas Identification (Multi-criteria decision logic)
    priority_areas = query_db("""
        SELECT 
            e.area_id, e.area_name, e.zone, e.overall_score, e.efficiency_category,
            e.heavy_congestion_count, e.overflow_risk_bins, e.pending_collections,
            CASE 
                WHEN e.heavy_congestion_count >= 3 AND e.overflow_risk_bins >= 2 THEN 'Critical Traffic Bottlenecks + High Waste Overflow'
                WHEN e.heavy_congestion_count >= 3 THEN 'Severe Traffic Congestion'
                WHEN e.overflow_risk_bins >= 2 THEN 'Multiple Waste Bins at Overflow Risk'
                WHEN e.pending_collections > 0 THEN 'Delayed / Missed Waste Collections'
                WHEN e.overall_score < 50 THEN 'Low Multi-Domain Efficiency Score'
                ELSE 'Normal Urban Operations'
            END AS main_issue,
            CASE 
                WHEN e.overall_score < 40 OR (e.heavy_congestion_count >= 3 AND e.overflow_risk_bins >= 2) THEN 'High'
                WHEN e.overall_score < 60 OR e.overflow_risk_bins >= 1 OR e.heavy_congestion_count >= 2 THEN 'Moderate'
                ELSE 'Low'
            END AS priority_level
        FROM area_efficiency_view e
        ORDER BY 
            CASE 
                WHEN e.overall_score < 40 OR (e.heavy_congestion_count >= 3 AND e.overflow_risk_bins >= 2) THEN 1
                WHEN e.overall_score < 60 OR e.overflow_risk_bins >= 1 OR e.heavy_congestion_count >= 2 THEN 2
                ELSE 3
            END,
            e.overall_score ASC;
    """)

    # 3. Peak Traffic Analysis
    peak_traffic_hours = query_db("""
        SELECT 
            EXTRACT(HOUR FROM tr.recorded_time)::INT AS hour_of_day,
            COUNT(tr.traffic_id) AS total_records,
            SUM(tr.vehicle_count) AS total_vehicles,
            ROUND(AVG(tr.vehicle_count), 1) AS avg_vehicles,
            COUNT(CASE WHEN tr.congestion_level = 'Critical' THEN 1 END) AS critical_events
        FROM traffic_records tr
        GROUP BY EXTRACT(HOUR FROM tr.recorded_time)
        ORDER BY total_vehicles DESC;
    """)

    # 4. Fleet Performance & Collection Efficiency
    fleet_metrics = query_db("""
        SELECT 
            cv.vehicle_number, cv.vehicle_type, cv.status,
            COUNT(cr.collection_id) AS total_trips,
            COUNT(CASE WHEN cr.collection_status = 'Completed' THEN 1 END) AS completed_trips,
            COALESCE(SUM(CASE WHEN cr.collection_status = 'Completed' THEN cr.collected_quantity ELSE 0 END), 0) AS total_collected_qty,
            ROUND((COUNT(CASE WHEN cr.collection_status = 'Completed' THEN 1 END)::NUMERIC / NULLIF(COUNT(cr.collection_id), 0)) * 100, 1) AS efficiency_rate
        FROM collection_vehicles cv
        LEFT JOIN collection_records cr ON cv.vehicle_id = cr.vehicle_id
        GROUP BY cv.vehicle_id, cv.vehicle_number, cv.vehicle_type, cv.status
        ORDER BY total_collected_qty DESC;
    """)

    return render_template(
        'analytics.html',
        area_efficiency=area_efficiency,
        priority_areas=priority_areas,
        peak_traffic_hours=peak_traffic_hours,
        fleet_metrics=fleet_metrics
    )

@analytics_bp.route('/analytics/export/area-efficiency')
@login_required
def export_efficiency_csv():
    rows = query_db("SELECT * FROM area_efficiency_view ORDER BY overall_score ASC;")
    if not rows:
        return "No data", 404

    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=rows[0].keys())
    writer.writeheader()
    writer.writerows(rows)

    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment;filename=area_efficiency_report.csv"}
    )
