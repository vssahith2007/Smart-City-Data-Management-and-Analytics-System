from flask import Blueprint, render_template, jsonify
from auth import login_required
from db import query_db

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/')
@dashboard_bp.route('/dashboard')
@login_required
def index():
    # Fetch KPI Statistics from database
    total_areas = query_db("SELECT COUNT(*) AS count FROM areas", one=True)['count']
    total_traffic_records = query_db("SELECT COUNT(*) AS count FROM traffic_records", one=True)['count']
    total_vehicles = query_db("SELECT COALESCE(SUM(vehicle_count), 0) AS total FROM traffic_records", one=True)['total']
    high_congestion_areas = query_db("""
        SELECT COUNT(DISTINCT area_id) AS count 
        FROM traffic_records 
        WHERE congestion_level IN ('High', 'Critical')
    """, one=True)['count']
    
    total_bins = query_db("SELECT COUNT(*) AS count FROM waste_bins", one=True)['count']
    overflow_bins = query_db("""
        SELECT COUNT(*) AS count 
        FROM waste_bins 
        WHERE status IN ('Full', 'Overflow Risk') OR (capacity > 0 AND (current_level / capacity) >= 0.80)
    """, one=True)['count']
    
    collection_stats = query_db("""
        SELECT 
            COUNT(*) AS total,
            COUNT(CASE WHEN collection_status = 'Completed' THEN 1 END) AS completed
        FROM collection_records
    """, one=True)
    collection_eff = round((collection_stats['completed'] / collection_stats['total'] * 100), 1) if collection_stats['total'] > 0 else 100.0
    
    avg_efficiency = query_db("SELECT COALESCE(ROUND(AVG(overall_score), 1), 0) AS avg_score FROM area_efficiency_view", one=True)['avg_score']

    # Priority Areas snapshot for quick alerts
    priority_alerts = query_db("""
        SELECT area_name, zone, overall_score, efficiency_category,
               heavy_congestion_count, overflow_risk_bins
        FROM area_efficiency_view
        WHERE overall_score < 60 OR overflow_risk_bins > 0
        ORDER BY overall_score ASC
        LIMIT 5;
    """)

    # Recent traffic incidents
    recent_incidents = query_db("""
        SELECT ti.incident_type, ti.severity, ti.description, ti.status, ti.incident_date, a.area_name
        FROM traffic_incidents ti
        JOIN areas a ON ti.area_id = a.area_id
        ORDER BY ti.incident_date DESC, ti.incident_id DESC
        LIMIT 5;
    """)

    # Traffic-Aware Collection Recommendations snapshot (Top 6)
    collection_recommendations = query_db("""
        SELECT 
            recommended_sequence, bin_id, area_name, bin_location,
            fill_percentage, traffic_congestion, priority_score,
            priority_level, vehicle_number, vehicle_type, recommended_action
        FROM traffic_aware_collection_recommendation
        ORDER BY priority_score DESC
        LIMIT 6;
    """)

    rec_kpis = query_db("""
        SELECT 
            COUNT(*) AS total_bins,
            COUNT(CASE WHEN priority_level = 'Critical' THEN 1 END) AS critical_bins,
            COUNT(CASE WHEN priority_level = 'High' THEN 1 END) AS high_bins,
            COUNT(CASE WHEN priority_score >= 70 THEN 1 END) AS urgent_collections
        FROM traffic_aware_collection_recommendation;
    """, one=True)

    # Smart Waste Collection Scheduler data
    smart_schedules = query_db("""
        SELECT 
            bin_id, bin_code, bin_location, area_id, area_name, zone,
            capacity, current_level, fill_percentage, bin_status,
            traffic_congestion, traffic_vehicle_count, traffic_recorded_time,
            priority_score, priority_level, lower_traffic_time,
            recommended_time, recommendation_reason, recommended_sequence
        FROM smart_collection_schedule_view
        ORDER BY recommended_sequence ASC, bin_id ASC;
    """)

    kpis = {
        'total_areas': total_areas,
        'total_traffic_records': total_traffic_records,
        'total_vehicles': f"{total_vehicles:,}",
        'high_congestion_areas': high_congestion_areas,
        'total_bins': total_bins,
        'overflow_bins': overflow_bins,
        'collection_eff': collection_eff,
        'avg_efficiency': avg_efficiency
    }

    return render_template(
        'dashboard.html',
        kpis=kpis,
        priority_alerts=priority_alerts,
        recent_incidents=recent_incidents,
        collection_recommendations=collection_recommendations,
        rec_kpis=rec_kpis,
        smart_schedules=smart_schedules
    )

@dashboard_bp.route('/api/dashboard-charts')
@login_required
def chart_data():
    # 1. Traffic by Area
    traffic_by_area = query_db("""
        SELECT a.area_name, COALESCE(SUM(tr.vehicle_count), 0) AS total_vehicles
        FROM areas a
        LEFT JOIN traffic_records tr ON a.area_id = tr.area_id
        GROUP BY a.area_id, a.area_name
        ORDER BY total_vehicles DESC;
    """)

    # 2. Congestion Distribution
    congestion_dist = query_db("""
        SELECT congestion_level, COUNT(*) AS count
        FROM traffic_records
        GROUP BY congestion_level
        ORDER BY CASE congestion_level
            WHEN 'Low' THEN 1
            WHEN 'Medium' THEN 2
            WHEN 'High' THEN 3
            WHEN 'Critical' THEN 4
        END;
    """)

    # 3. Waste Level & Capacity by Area
    waste_by_area = query_db("""
        SELECT a.area_name, 
               COALESCE(SUM(wb.current_level), 0) AS current_waste,
               COALESCE(SUM(wb.capacity), 0) AS total_capacity,
               CASE WHEN COALESCE(SUM(wb.capacity), 0) > 0 
                    THEN ROUND((SUM(wb.current_level) / SUM(wb.capacity)) * 100, 1)
                    ELSE 0 END AS fill_percentage
        FROM areas a
        LEFT JOIN waste_bins wb ON a.area_id = wb.area_id
        GROUP BY a.area_id, a.area_name
        ORDER BY current_waste DESC;
    """)

    # 4. Collection Status Breakdown
    collection_status = query_db("""
        SELECT collection_status, COUNT(*) AS count
        FROM collection_records
        GROUP BY collection_status
        ORDER BY count DESC;
    """)

    # 5. Area Efficiency Scores
    area_efficiency = query_db("""
        SELECT area_name, traffic_score, waste_score, overall_score, efficiency_category
        FROM area_efficiency_view
        ORDER BY overall_score DESC;
    """)

    return jsonify({
        'traffic_by_area': traffic_by_area,
        'congestion_dist': congestion_dist,
        'waste_by_area': waste_by_area,
        'collection_status': collection_status,
        'area_efficiency': area_efficiency
    })
