# Gap Analysis: Smart City Data Management & Analytics

## 1. Context and Problem Statement

Urban administrations in growing cities face severe challenges in monitoring and managing municipal operations effectively. While substantial research has explored automated sensing for traffic signaling and municipal solid waste collection independently, existing urban information systems remain fragmented into domain-specific silos.

Managing traffic and waste data separately leads to:
1. **Data Redundancy & Schema Duplication**: Duplicate storage of geographical boundaries, ward hierarchies, and administrative identifiers across multiple isolated databases.
2. **Inconsistent Operational Records**: Inability to correlate missed waste collections with arterial traffic congestion occurring at the same time and in the same sector.
3. **Absence of Unified Prioritization**: Inability of municipal administrators to view a composite operational efficiency score for a given ward or identify multi-issue crisis zones in real time.
4. **Application-Layer Logic Bloat**: Over-reliance on application-level code to maintain state synchronization rather than leveraging native DBMS capabilities such as Foreign Key Constraints, Cascading, Triggers, and Analytical Views.

---

## 2. Structured Comparison: Existing Systems vs. Proposed DBMS

| Evaluation Dimension | Existing Siloed Approaches | Over-Engineered Big Data/AI Platforms | Proposed Smart City Relational DBMS |
|---|---|---|---|
| **Database Architecture** | Disparate, non-interoperable MySQL/PostgreSQL databases per department. | Distributed NoSQL (MongoDB/Cassandra) with high operational overhead and no strict schema. | **Centralized PostgreSQL 18 Relational Schema normalized up to 3NF.** |
| **Geographical Integration** | Duplicated area names and zone descriptions with no referential link. | Complex spatial GIS layers with heavy licensing requirements. | **Unified `AREA` master entity with Foreign Key relationships linking all traffic and waste records.** |
| **Data Integrity & Automation** | Manual database updates; high risk of orphaned logs upon deletion. | Heavy background microservices polling databases periodically. | **Native PL/pgSQL Triggers (`AFTER INSERT`, `BEFORE UPDATE`) and CHECK constraints.** |
| **Decision-Support Model** | Separate single-metric dashboards (traffic queue length OR bin fill level). | Black-box Machine Learning models lacking operational explainability. | **Deterministic, explainable Area Efficiency Score (0–100) computed via SQL views.** |
| **Query Performance & Analytics** | Raw un-indexed table scans and complex cross-database scripts. | Distributed query engines requiring significant compute clusters. | **B-Tree Indexed relational queries and database views (`area_traffic_summary`, `area_waste_summary`, `area_efficiency_view`).** |
| **Operational Feasibility** | High maintenance due to synchronization scripts between departments. | Prohibitive hardware cost and complex setup unsuitable for municipal tier-2/3 cities. | **Lightweight, cost-effective Python Flask backend with direct connection pooling.** |

---

## 3. Detailed Gaps Identified in Reviewed Literature

### Gap 1: Domain Siloing vs. Shared Geographic Hierarchy
- **Existing Limitation**: Existing literature (e.g., Sundar et al., 2015; Hannan et al., 2014) develops specialized databases for either traffic signals or waste bins. Consequently, ward-level administrators cannot compare cross-service resource allocation.
- **Proposed Solution**: Implementation of a normalized master `AREAS` entity serving as the primary foreign key parent for both `traffic_signals`, `traffic_records`, `traffic_incidents`, `waste_bins`, and `collection_records`.

### Gap 2: Application-Layer Overhead vs. DBMS-Layer Triggers
- **Existing Limitation**: In many existing smart city implementations (e.g., Kodali & Sahu, 2016), collection logging requires multiple manual updates across application screens to reflect that a container has been emptied.
- **Proposed Solution**: Implementation of the `trg_update_bin_after_collection` trigger that automatically executes at the database engine level whenever a collection log with `collection_status = 'Completed'` is inserted or updated.

### Gap 3: Lack of an Explainable Composite Metric
- **Existing Limitation**: Most analytics systems present individual statistics without synthesizing them into an actionable priority index. Complex ML scoring algorithms proposed in advanced literature often lack explainability for municipal officers.
- **Proposed Solution**: A transparent, mathematically grounded Area Efficiency Score (0–100) combining normalized traffic congestion and waste collection metrics, clearly categorized into *Excellent*, *Good*, *Needs Attention*, and *Critical*.

### Gap 4: Performance Bottlenecks on Unindexed Joins
- **Existing Limitation**: Time-series sensor logs rapidly grow in volume, causing multi-table JOINs and aggregations across areas to degrade in query response time.
- **Proposed Solution**: Strategic B-Tree indexes on high-cardinality foreign keys and filter columns (`area_id`, `recorded_date`, `congestion_level`, `status`, `collection_date`), reducing average analytical query latency to under 5ms.

---

## 4. Academic Contribution Summary

The contribution of this project is not an algorithmic AI claim, but rather an **integrated, lightweight relational database solution focused on traffic and waste data with cross-domain area-wise analytics**. 

It demonstrates rigorous DBMS engineering principles: ER modeling, 3NF normalization, constraint enforcement, automated triggers, database views, and SQL aggregation to solve real-world municipal operational challenges.
